"""
UNILM + FHMM hybrid load disaggregation (rebuild).

Rebuilt from unilm_progress_report.md after the original unilm.py was lost
in an environment reset. Two genuinely different mechanisms, combined:

  FHMM  (fhmm_v2.py, batch, offline): fitted once on the TRAINING portion
        of the series. Its fitted appliance levels are used to SEED the
        UNILM appliance database -- UNILM's cold-start weakness (with an
        empty database, the first events of every appliance are
        unexplainable).

  UNILM (Rodriguez-Silva & Makonin 2019, Algorithm 1; online): detect
        step events in the aggregate, keep one Gaussian model per
        discovered appliance -- here over the joint (P, Q) step vector, not
        scalar P, which is what separates resistive defrost heaters
        (Q/P~0.14) from inductive compressors (Q/P~0.55-0.62) -- and explain
        every event as the most probable combination of appliance
        transitions (the multiple-choice knapsack: each appliance picks one
        option from {no change, switch}, subject to the chosen transitions
        summing to the observed step).

Carried over from the report: duration tracking (on/off duration models
used as a prior inside the knapsack score), two-stage validation (shortlist
by edge likelihood, then check the aggregate LEVEL at transition points),
continuous-load tracker (causal EMA of what the on/off model can't
represent: VFD + base), held-out evaluation (models FROZEN at the same 75%
split FHMM uses), auto-terminate for resistive appliances.

Composite resolution (structure_search, see structure_search()): after an
online discovery pass over the TRAINING period, the appliance dictionary is
refined by a penalised-likelihood search. A "composite" appliance -- two
transitions that coincide, e.g. compressor on + its defrost heater off --
is replaced by its missing part plus a coupling between the two, when the
part is physically plausible, the composite is rare relative to its parts,
and the part is seen switching on its own (identifiability). Validated on a
fresh-seed stress set; several alternatives tried on the way (tighter
multi-transition gate, cancellation penalty, retire-only refinement, a
"new appliance competes on score" rule) are kept as off-by-default flags.

Temperature-dependent magnitudes (temperature_magnitude): a compressor's
electrical draw rises with condensing temperature, i.e. roughly with
ambient. Each appliance's step is modelled as mu0 + beta*(T - T_ref), with
beta fitted by ridge regression on its matched training steps and frozen
at the split; T is the ambient at the event (CONFIG
"magnitude_covariate_col", e.g. SMHI data interpolated to the meter's
resolution). Without a covariate column the tracker falls back exactly to
fixed magnitudes. Tested against a model-free tracking mean (did not
generalise) and on a lagged, head-pressure-floored plant it does not
match exactly (still helps). See drift_results.md.

Multi-hypothesis tracking (mht_beam > 1, final pass only): instead of
committing to the best explanation at every event, up to mht_beam
complete tracker states are kept and branched on near-tied explanations;
the path with the best summed explanation likelihood wins. See
_track_mht() and mht_results.md.

Edge detection (detect_edges): a step must pass a robust significance test
against its own before/after windows (persistence, not magnitude), applied
iteratively so clustered noise excursions stop clipping each other's
windows; and transitions are measured outside soft-starter / drive ramps.
Appliances may have different start and stop steps with a lagging "tail"
(asymmetric_steps; a fan stopping after its compressor), and the
structure search starts from an MHT discovery pass (search_mht_discovery).
Rated power per compressor is reported (rated_power()). See
steps4to8_results.md.

Compressor racks: a VFD lead compressor on a common suction header
compensates every fixed-stage start/stop within tens of seconds, so the
aggregate step decays and step sizes read 15-20 % low. The site's
compensation is detected (estimate_compensation(); c_median >= 0.10) and
rated power is then taken from the step AT the switch (instantaneous_step(),
an exponential fit of the post-switch window). A signal-level correction
(correct_compensation()) is available but off: tested neutral. See
rack_results.md.

Everything added in the logic review sits behind CONFIG["improvements"]
so each change can be switched off for ablation (ablate.py). With every
flag False (and resistive_qp_ratio 0.30) the tracker behaves like the
report-faithful baseline. The defaults are the configuration that scored
best on the duplicate-aware metric.

Usage
-----
Real meter data (no ground truth -> real-data mode, nothing is scored):

Humidity (CONFIG "humidity_path" / "humidity_col", CLI --humidity): relative
humidity, e.g. the SMHI export "Relativ Luftfuktighet", interpolated like the
temperature. It enters in three ways, all reported:
  1. "magnitude_covariate": "dry_bulb" (default, unchanged), "wet_bulb" or
     "enthalpy". With an evaporative or adiabatic condenser the condensing
     temperature follows the WET-bulb temperature, so the step size should
     too; "enthalpy" (kJ/kg dry air) is the total heat content of the air.
     The chosen covariate replaces the dry-bulb T in mu0 + beta(T - T_ref).
  2. humidity_check.csv: per appliance, do the matched steps still depend on
     humidity once the covariate is accounted for? OLS of |step P| on
     [start/stop, covariate, humidity measure] over the single-appliance
     switches of the final tracker; slope, p-value, effect over the
     humidity's interquartile range in % of the step.
  3. duty_vs_weather.csv: the bigger expected effect of humid air is on RUN
     TIME, not on step size (latent load from infiltration and door
     openings, frosting -> more defrost). Per compressor, daily running share
     regressed on daily outdoor T alone and on T + humidity; the gain in R2
     and the humidity coefficient are reported. compressor_hourly.csv also
     gets the hourly outdoor T, RH and humidity ratio.
Psychrometrics at CONFIG "air_pressure_hpa" (1013.25): Magnus saturation
pressure, Stull (2011) wet-bulb (valid for RH 5-99 %, T -20..50 degC).

    python3 unilm_fhmm.py METER.csv --out results/ [--weather SMHI.csv]
        [--humidity SMHI_RH.csv] [--covariate dry_bulb|wet_bulb|enthalpy]
        [--time COL --p COL --q COL --ambient COL --tz Europe/Stockholm --unit auto|kW|W]

  Input: 1 s active power P and reactive power Q (required), outdoor
  temperature as a column or a separate file (SMHI open-data export works
  as downloaded). Column names are matched case-insensitively; ';'-separated
  files with decimal commas, W/var units and local-time timestamps (DST
  handled) are read as-is.
  Output in --out:
    appliances.csv   one row per discovered appliance: rated kW / kvar, power
                     factor, type, tail (lagging fan), temperature slope,
                     duty cycle, starts per day, on/off duration percentiles,
                     energy per day, and a reliability band for its timing
    switches.csv     every on/off switch with UTC and local time
    timeseries_<r>s.csv  aggregate, ambient, each appliance's estimated power,
                     continuous remainder (default 60 s resolution)
    summary.json     input diagnostics/warnings, rack detection, run stats

Synthetic evaluation (built-in CONFIG, ground truth present):

    python3 unilm_fhmm.py
"""
import copy
import json
import re
import math
import os
import pickle
import time
from itertools import combinations

import numpy as np
import pandas as pd

CONFIG = {
    # ---------------------------------------------------------------- data
    "csv_path": "/mnt/user-data/outputs/cold_storage_synthetic_1s_with_reactive_power.csv",
    "cache_pickle": "data.pkl",          # optional fast-load cache of the CSV
    # Column names. Each may be a name or a list of candidates; matching
    # ignores case, spaces, '_' and '-' (so "Aggregate_kvar" also finds
    # "Aggregate kVAR"). The first candidate present in the file is used.
    "timestamp_col": ["Time", "Timestamp", "Tid", "Tidpunkt", "Datetime", "Date time"],
    "p_col": ["Aggregate_kW", "P_kW", "P", "Active power", "Aktiv effekt"],
    "q_col": ["Aggregate_kvar", "Q_kvar", "Q", "Reactive power", "Reaktiv effekt"],
    "magnitude_covariate_col": ["Ambient_C", "Ambient", "Outdoor temperature", "Utetemperatur", "T_out"],
    "timestamp_timezone": "Europe/Stockholm",  # for timestamps WITHOUT a zone (numbers are unix seconds/ms, UTC)
    "power_unit": "auto",                # "kW", "W" or "auto" (median |P| > 5000 -> W)
    "weather_path": None,                # optional separate ambient file (SMHI export or time,temp CSV)
    "weather_timezone": "UTC",           # SMHI exports are UTC
    # humidity (see the module docstring)
    "humidity_path": None,               # separate RH file (SMHI export "Relativ Luftfuktighet" or time,rh CSV);
                                         # None: look for an RH column in the weather file, then in the meter file
    "humidity_col": ["RH", "RH_pct", "Relative humidity", "Relativ luftfuktighet", "Luftfuktighet", "Humidity"],
    "magnitude_covariate": "dry_bulb",   # "dry_bulb" | "wet_bulb" | "enthalpy" (the last two need humidity)
    "humidity_measure": "humidity_ratio",  # in the checks: "humidity_ratio" (g/kg) | "rh" (%) | "dew_point" (degC)
    "humidity_check": True,              # humidity_check.csv and duty_vs_weather.csv when humidity is available
    "humidity_check_min_switches": 40,   # single-appliance switches needed per appliance
    "duty_weather_min_days": 20,         # days with a running share needed per compressor
    "air_pressure_hpa": 1013.25,
    "train_frac": 0.75,                  # evaluation (ground truth present): freeze point, same split as FHMM
    "train_frac_real": 1.0,              # real data (no ground truth): learn on the whole series
    # long recordings (see run_tracker_long()): learn the appliance structure on
    # a sample of the recording, then track the whole of it with what was learned
    "long_mode": "auto",                 # "auto": when the series is longer than long_min_days
    "long_min_days": 14,
    "long_learn_days": 21,               # days of data the structure search learns from ...
    "long_learn_blocks": 3,              # ... in this many blocks spread over the learning period
    "csv_chunk_rows": 2_000_000,         # big CSV files are read in chunks of this many rows
    "csv_chunk_min_mb": 200,             # ... when larger than this
    # outputs (real-data mode, or whenever output_dir is set)
    "output_dir": None,
    "output_resolution_s": 60,           # resolution of the exported time series (1 = full 1 s)
    "site_code": None,                   # anonymised site code written in compressor_hourly.csv /
                                         # compressor_list.csv (None = the output folder's name)
    "hourly_min_observed": 0.9,          # an hour's running share needs >= 90 % of its seconds observed
    # variable-speed guard (see start_dynamics())
    "vsd_decay_window_s": 600,
    "vsd_early_s": 120,
    "vsd_min_decay": 0.15,               # level falls by >= 15 % of the start step within 10 min ...
    "vsd_min_late_share": 0.40,          # ... and >= 40 % of that fall comes after the first 2 min
    "vsd_min_pf": 0.95,                  # ... and near-unity power factor (drive front end; a directly or
                                         #     soft-started induction motor runs at ~0.8-0.9)
    # schedule-driven loads (see classify_schedule()): unity-PF appliances that
    # never start in a long stretch of clock hours are not refrigeration;
    # charger-like ones get a second pass that learns nothing inside their sessions
    "schedule_classification": True,
    "sched_min_pf": 0.95,
    "sched_min_dead_hours": 8,           # longest run of clock hours (all days pooled) with no start
    "sched_dead_tolerance": 0.03,        # share of starts allowed inside the idle span
    "sched_max_passes": 3,
    # timer-driven loads (see classify_timer()): defrost on a clock or a fixed
    # interval -- electric heaters, hot-gas mode, fans stopped during defrost
    "timer_classification": True,
    "timer_cluster_min": 20,             # starts within 20 min of each other = same clock time
    "timer_min_day_share": 0.6,          # a clock time must recur on >= 60 % of days
    "timer_min_event_share": 0.5,        # ... and hold >= 50 % of the appliance's events
    "timer_interval_tol": 0.2,           # or: >= 60 % of intervals within 20 % of their median
    "timer_interval_h": (3.0, 25.0),     # median interval of a defrost timer
    "timer_duration_min": (5.0, 90.0),   # minutes on (or off) per event
    "timer_duration_cv": 0.4,            # >= 60 % of runs within 40 % of the median duration
    # capacity stages (see capacity_stages()): a step that is only ever on
    # while another appliance is on, and is off when that one stops
    # lagging parts found after tracking (see detect_lagging_parts()): an
    # evaporator fan that starts with its compressor but stops after it
    "lag_detection": True,
    "lag_min_kw": 2.0,                   # start minus stop at least this ...
    "lag_min_share": 0.04,               # ... and this share of the start step
    "lag_min_pairs": 10,                 # start/stop pairs needed
    "lag_min_followup": 0.4,             # share of stops followed by the lagging part's own stop
    "lag_followup_s": (20, 300),         # ... this many seconds after the compressor stops
    # the same compressor learned twice (see duplicate_identities())
    "dup_rel_kw": 0.03,                  # steps within 3 % (P) ...
    "dup_rel_kvar": 0.06,                # ... and 6 % (Q) ...
    "dup_max_second_start": 0.15,        # ... and a start of that size while one of that size already
                                         # runs is rare (two real compressors: ~their duty cycle)
    # near-identical compressors (see twin_compressors()): two real machines
    # whose steps are too close to tell apart event by event
    "twin_detection": True,
    "twin_rel_kw": 0.08,                 # steps within 8 % (P) and Q/P within twin_rel_qp
    "twin_rel_qp": 0.10,
    "twin_rel_kw_rack": 0.11,            # on a compensated rack: rated sizes within 11 %
    "twin_min_separation": 3.0,          # below this many standard deviations apart (two-Gaussian
                                         # fit of the temperature-corrected step sizes) the two are
                                         # "not separable": sizes reliable, per-unit timing not
    "stage_classification": True,
    "stage_window_s": 600,               # a load step follows the start within 10 min
    "stage_min_follow": 0.5,             # ... after at least half of the starts
    "stage_min_lift": 2.0,               # ... and 2x more often than by chance
    "stage_max_rel_qp": 0.7,             # load step Q/P <= 0.7 x the start step's Q/P
    "stage_min_period_share": 0.15,      # step count = most steps loaded in >= 15 % of runs
    "stage_max_rel_size": 1.1,           # a load step is no bigger than the start step               # extra passes while new charger-like loads keep appearing
    # PV cloud passages (see classify_pv()): a unity-PF "appliance" made of
    # cloud edges switches in daylight only, and much more on broken-cloud
    # days than on clear or overcast ones
    # always-on units (see hidden_units()): a unit that never stops is part of
    # the base level; how many of a compressor's size fit inside it
    "hidden_unit_check": True,
    "hidden_block_s": 900,               # base level = median of each 15 min ...
    "hidden_floor_pct": 20,              # ... and the floor = 20th percentile of those: a level present
                                         # >= 80 % of the time (lower blocks are mostly tracking offsets)
    "hidden_tol": 0.05,
    "hidden_always_on_duty": 0.9,        # an inductive appliance on >= 90 % of the time is base level                  # a unit counts when >= 95 % of it fits in BOTH P and Q
    # defrost heaters rebuilt from the unity level (see rebuild_defrost())
    # capacity-modulated screws (see start_rise()): the level rises after
    # the start -- full load = start step + the largest sustained rise
    "mod_detection": True,
    "mod_window_s": 600,
    "mod_min_rise_share": 0.4,           # p90 rise >= 40 % of the start step ...
    "mod_min_rise_kw": 5.0,              # ... and >= 5 kW
    "mod_min_start_qp": 0.75,            # start step at minimum load: Q/P near 1
    "mod_max_rise_qp": 0.6,              # the loading adds mostly real power ...
    "mod_min_rise_qp": 0.1,              # ... and some reactive power (a capacitor bank switching in does not)
    "defrost_rebuild": True,
    "defrost_step_kw": 3.0,              # unity-level step threshold
    "defrost_dur_min": (3, 90),          # a heater run lasts 3-90 min
    "defrost_max_per_day": 6,            # defrost: a few times a day
    "defrost_max_dur_cv": 0.35,          # ... for a consistent time
    "defrost_min_runs": 4,
    "defrost_min_per_day": 1.2,          # an evaporator defrosts at least about once a day
    "defrost_max_median_min": 50,        # electric defrost: typically 15-45 min
    "defrost_min_step": 4.0,             # in the unity level (a 5 kW unity-PF heater gives ~4)
    "pv_classification": True,
    "pv_window_h": 12,                   # the busiest 12 clock hours (circular) ...
    "pv_min_day_share": 0.8,             # ... hold >= 80 % of its starts (heaters, fans: 0.60-0.68),
    "pv_center_hours": (9.0, 17.0),      # ... centred around midday (local time),
    "pv_min_day_cv": 0.3,                # and its starts per day vary a lot between days (others <= 0.1)
    "sched_min_starts": 15,              # fewer starts: a dead span of 8 h is too likely by chance (p > 0.03)
    "sched_daylight_min_starts_per_day": 15,   # many short unity steps in daytime only: PV cloud passages
    "sched_window_margin_s": 120,
    "sched_window_max_ext_s": 4 * 3600,  # a session's tail (taper) is followed at most this long

    # ------------------------------------------------------ edge detection
    "edge_detect_window_s": 6,           # half-width of the mean-difference detector
    "edge_detect_threshold_kw": 3.5,     # |mean(after) - mean(before)| to be a candidate
    "edge_refine_window_s": 30,          # max width of pre/post median windows
    "edge_refine_guard_s": 2,            # samples skipped either side of the step
    "edge_min_step_kw": 4.0,             # refined |dP| needed to keep an event
    # reactive-only steps (capacitor-bank stages): detected on Q, reported,
    # and used as window boundaries so they do not leak into the Q of a
    # nearby compressor step
    "qstep_detection": True,
    "qstep_detect_threshold_kvar": 4.0,
    "qstep_min_kvar": 5.0,
    "qstep_max_p_ratio": 0.2,            # |dP| <= this x |dQ| (and <= 2 kW): no real power moves
    "long_gap_s": 30,                    # data gaps longer than this trigger a state resync
    "edge_significance": True,           # keep a step only if it stands out from its own windows' noise
    "edge_min_t": 6.0,                   # robust t-statistic of the step (P channel)
    "edge_ramp_aware": True,             # measure steps outside soft-start / drive ramps
    "edge_ramp_frac": 0.5,               # ramp = where the detector stays above this share of its peak
    "edge_max_ramp_s": 30,

    # ---------------------------------------------------- appliance models
    "meas_sigma": [0.9, 0.9],            # step-measurement noise floor, kW / kvar
    "new_cov_sigma": [2.5, 2.0],         # initial std of a newly discovered appliance
    "min_cov_sigma": [0.6, 0.5],         # appliance model std can't shrink below this
    "cov_prior_weight": 3.0,             # pseudo-count of the initial covariance
    "update_max_m2": 9.0,                # only update a model from well-matched events
    "resistive_qp_ratio": 0.40,          # Q/P below this = resistive (heater ~0, motors 0.5-0.75)

    # ------------------------------------------------------------ knapsack
    "max_simultaneous": 2,               # transitions per event
    "multi_log_penalty": 4.0,            # prior cost per extra simultaneous transition
    "new_appliance_m2": 16.0,            # worse than this = unexplained / new appliance
    "shortlist_k": 6,                    # two-stage validation shortlist size
    "duration_weight": 1.0,
    "duration_min_obs": 3,
    "duration_log_sigma_floor": 0.15,
    "level_weight": 1.0,
    "level_sigma_kw": 3.0,

    # ---------------------------------------------------------- auto-terminate
    "auto_terminate_default_s": 1650,    # the report's zone-agnostic bound

    # ------------------------------------------------------ continuous load
    "continuous_ema_tau_s": 60,

    # ---------------------------------------- compressor-rack compensation
    "rack_compensation": False,          # undo a VFD lead compressor's compensation in the signal (tested: neutral)
    "rack_min_c": 0.10,                  # median compensation share below this = no rack effect, do nothing
    "rack_min_kw": 15.0,                 # switches big enough to be fixed compressor stages
    "rack_horizon_s": 300,
    "rack_detrend_s": 10800,             # remove the correction's slow drift (unequal start/stop fits add up)

    # ------------------------------------------- rated power (post-hoc)
    "rated_instantaneous": "auto",       # rated power from the step AT the switch: True / False / "auto" =
                                         # only when rack compensation is detected (it is noisier per switch)
    "rated_fit_s": 60,                   # post-switch window for the exponential fit
    "rated_pre_s": 30,

    # ------------------------------------------------------------ FHMM seed
    "fhmm_seed": False,                  # see README/summary: neutral-to-negative here once tracking is fixed
    "fhmm_params_path": "fhmm_blind_fit.pkl",  # fhmm_v2 fit on the training 75% (run_staged.py, blind)
    "seed_min_step_kw": 4.0,
    "seed_merge_kw": 2.5,                # near-duplicate seed steps are merged
    "seed_composite_tol_kw": 3.0,        # a seed within this of the sum of two others is a composite
    "seed_cov_sigma": [5.0, 4.0],        # FHMM seeds start wide: they are provisional

    # ------------------------------------------------- improvements (review)
    "improvements": {
        "fix_seed_composite_filter": True,   # tolerance in kW instead of seed-cov units
        "unknown_initial_state": False,      # start/after-gap states unknown -> either transition allowed
        "missed_transition_repair": True,    # on-edge for an 'on' appliance = its off-edge was missed
        "reassert_log_penalty": 3.0,
        # identical units (a compressor rack): structure-search moves "add a unit"
        # and "merge identical appliances", accepted only if the penalised
        # likelihood of the training events improves by one appliance cost.
        "multi_unit": True,
        "unit_min_reasserts": 3,
        "unit_twin_rel": 0.10,               # ... and no other appliance is within 10 % of its step             # propose "add unit" if the tracker re-asserted its start this often
        # online variant (tested, off): "one more unit" as an event-level option
        # competing with "missed stop"; it added units to single compressors
        "unit_online": False,
        "unit_log_cost": 6.0,
        "unit_min_n": 10,                    # the appliance's step must be well established
        "unit_level_margin": 0.5,
        "unit_max_m2": 2.0,            # remainder may be at most this many units below typical
        "unit_merge_rel": 0.04,              # appliances within 4 % in P and Q are units of one rack
        "unit_top_min_share": 0.01,          # the top unit count must be held >= 1 % of the time ...
        "unit_top_min_episodes": 5,          # ... in >= 5 separate episodes, else a unit is dropped
        "level_check_physical": True,        # discrete sum may never exceed the aggregate
        "level_repair": True,                # fix stuck states from level drift before each event
        "triple_transitions": True,          # allow 3 simultaneous transitions (defrost starts)
        "learned_terminate_bound": True, 
        "prune_unsupported_at_freeze": True, 
        "prune_min_matches": 3,
        "merge_duplicates_at_freeze": False,
        "merge_m2": 4.0,
        "seed_confirmation": True,           # seeds unconfirmed until matched in data; pruned otherwise
        "seed_reanchor": True,               # first match re-centres an unconfirmed seed on the measured step
        "new_cov_sigma": None,               # override new-appliance initial std, e.g. [1.5, 1.2]
        "robust_model_update": True,         # tighter update gate + covariance cap (no catch-all models)
        "robust_update_max_m2": 4.0,
        "max_cov_sigma": [2.0, 1.5],
        # --- composite resolution
        "new_hypothesis_competition": False, # "new/unknown appliance" competes on score, not only as a fallback
        "new_appliance_log_cost": 12.0,      # its fixed log-likelihood cost
        "multi_gate": False,                 # tighter Mahalanobis gate for 2-3 transition explanations
        "multi_max_m2": 9.0,                 # ~99 % chi-square, 2 dof
        "cancel_penalty": False,             # reject opposite transitions that nearly cancel
        "cancel_ratio": 0.35,                # |net step| / largest component below this = "cancelling"
        "composite_refinement": False,       # retire appliances that are sums/differences of others, re-track
        "composite_m2": 6.0,
        "composite_min_consistency": 0.7,    # parts' tracked states must fit at >= this share of its switch-ons
        "refine_max_passes": 3,
        "unexplained_log_cost": 12.0,        # objective cost of an event no known combination explains
        "structure_search": True,            # penalised-likelihood search over the appliance dictionary
        "structure_max_passes": 4,
        "search_mht_discovery": True,        # discovery pass uses MHT; the search then cleans what MHT created
        "appliance_log_cost": None,          # per-appliance cost; None = BIC-like 0.5*5*ln(n_train_events)
        "max_qp_ratio": 1.0,                 # physical plausibility of a decomposed part: Q/P <= 1 (PF >= 0.7)
        "composite_max_rel_freq": 0.5,       # a composite is rarer than its parts: n(C) <= this * n(part)
        "part_min_solo_events": 3,           # a decomposed part must be seen switching ON ITS OWN this often
        "decompose_adds_coupling": True,     # record that the composite's parts switch together
        "asymmetric_signatures": False,      # structure-search pair merge (tried; superseded by asymmetric_steps)
        "asymmetric_steps": True,            # per-appliance start step != stop step, with a lagging tail
        "asym_merge_move": False,            # structure-search merge of a start/stop appliance pair (tried, never accepted)
        "asym_min_each": 8,                  # matched starts AND stops needed before testing asymmetry
        "asym_min_kw": 2.0,                  # smallest start-stop difference treated as a tail
        "asym_min_t": 4.0,                   # ... and it must exceed this many standard errors
        "tail_max_s": 900,                   # a tail not seen switching off within this is dropped
        "asym_min_events": 10,
        "asym_min_frac": 0.75,
        # --- magnitude drift
        "temperature_magnitude": True,       # step = mu0 + beta * (covariate - reference), beta learned in training
        "temp_min_obs": 8,                   # matched steps before a slope is fitted
        "temp_min_spread": 1.5,              # ... and covariate spread (std) needed to fit it
        "temp_ridge": 50.0,                  # shrinkage of the slope towards 0 (added to sum of squares)
        "temp_data_gate_m2": 9.0,            # looser gate for collecting regression data (see update())
        "temp_window": 300,                  # most recent matched steps used for the fit
        # --- multi-hypothesis tracking (final pass only)
        "mht_beam": 4,                       # hypotheses kept; 1 = greedy tracker
        "mht_branch": 3,                     # max explanations a hypothesis branches into per event
        "mht_margin": 5.0,                   # branch only on options within this log-likelihood of the best
        "mht_weak_fit_m2": 9.0,              # best fit worse than this: "new appliance" also competes
        "mht_new_appliance_cost": 16.0,      # path-score cost of creating an appliance (~BIC, 5 params)
        "temp_slope_inductive_only": False,  # beta = 0 for resistive loads (tested: worse, see drift_results.md)
        "temp_slope_bic": False,             # keep a slope only if BIC prefers it (tested: no gain, see drift_results.md)
        "magnitude_forgetting": 0.0,         # >0: tracking mean, lr = max(1/(n+1), this)
        "adapt_after_freeze": False,         # keep tracking magnitudes after the freeze (structure stays frozen)
        "search_state_consistency": False,   # behavioural test on tracked states (see _joint_consistency)
    },

    # ------------------------------------------------------------- scoring
    "ground_truth_cols": ["gt_Z1_power_kW", "gt_Z2_power_kW", "gt_Z3_power_kW",
                          "gt_Z1_defrost_kW", "gt_Z2_defrost_kW", "gt_Z3_defrost_kW"],
    "ground_truth_on_threshold_kw": 3.0,
    "continuous_truth_cols": ["gt_base_kW", "gt_vfd_kW"],
}


# =========================================================================
# Data
# =========================================================================
def _as_list(x):
    return [x] if isinstance(x, str) else list(x or [])


def _norm(name):
    return re.sub(r"[\s_\-]", "", str(name)).lower()


def _resolve_col(df, spec, what, required=True):
    """First candidate in `spec` present in df (case/space/underscore-insensitive)."""
    cands = [spec] if isinstance(spec, str) else list(spec or [])
    lookup = {_norm(c): c for c in df.columns}
    for c in cands:
        if c in df.columns:
            return c
        if _norm(c) in lookup:
            return lookup[_norm(c)]
    if required:
        raise ValueError(f"No {what} column found. Tried {cands}; file has {list(df.columns)[:20]}. "
                         f"Set it with the matching config key / command-line option.")
    return None


def _read_table(path):
    """CSV (',' or ';' separated, '.' or ',' decimals), Excel or pickle."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".pkl", ".pickle"):
        return pd.read_pickle(path)
    if ext in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(path)
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        head = [fh.readline() for _ in range(5)]
    sep = ";" if sum(l.count(";") for l in head) > sum(l.count(",") for l in head) else ","
    decimal = "," if sep == ";" and re.search(r"\d,\d", "".join(head[1:])) else "."
    return pd.read_csv(path, sep=sep, decimal=decimal, encoding="utf-8-sig")


def _to_epoch_seconds(col, tz):
    """Timestamps -> integer unix seconds (UTC). Numbers are unix seconds
    (or milliseconds); strings are parsed, and zone-less ones are taken as
    local time in `tz` (DST handled: the repeated autumn hour is inferred
    from order, the missing spring hour shifted)."""
    if pd.api.types.is_numeric_dtype(col):
        v = col.to_numpy(dtype=float)
        if np.nanmedian(v) > 1e11:
            v = v / 1000.0
        return np.round(v).astype(np.int64)
    ts = pd.to_datetime(col, errors="coerce")
    if ts.dt.tz is None:
        try:
            ts = ts.dt.tz_localize(tz, ambiguous="infer", nonexistent="shift_forward")
        except Exception:
            ts = ts.dt.tz_localize(tz, ambiguous="NaT", nonexistent="shift_forward")
    ts = ts.dt.tz_convert("UTC")
    ok = ts.notna().to_numpy()
    out = np.full(len(ts), np.iinfo(np.int64).min, dtype=np.int64)
    # resolution-independent (pandas may store s, ms, us or ns)
    out[ok] = ((ts[ok] - pd.Timestamp("1970-01-01", tz="UTC")) // pd.Timedelta(seconds=1)).to_numpy()
    return out


def add_production(data, path, cfg):
    """
    Solar behind the meter: the meter sees load - production, so every
    compressor step on a sunny day sits on a smooth negative signal and
    the self-consumed part is invisible. With the inverter's (or the
    production meter's) series, P_load = P_meter + production is rebuilt
    on the 1 s grid (linear between production samples; a production gap
    longer than 3 samples is a gap in the result -- never "no production").
    Q is left as it is (inverters run at ~unity power factor). Values are
    kW, or kWh per interval when the column name says kWh.
    """
    w = _read_table(path)
    tcol = _resolve_col(w, _as_list(cfg["timestamp_col"]) + ["time", "date", "tid", "tidpunkt", "tidspunkt"],
                        "production time")
    vcols = [c for c in w.columns if c != tcol and pd.to_numeric(w[c], errors="coerce").notna().mean() > 0.9]
    if not vcols:
        raise ValueError(f"{path}: no numeric production column")
    vcol = vcols[0]
    val = pd.to_numeric(w[vcol], errors="coerce")
    ep = _to_epoch_seconds(w[tcol], cfg.get("timestamp_timezone", "Europe/Stockholm")) \
        if not pd.api.types.is_numeric_dtype(w[tcol]) else _to_epoch_seconds(w[tcol], "UTC")
    ok = (ep != np.iinfo(np.int64).min) & val.notna().to_numpy()
    ep, val = ep[ok], val.to_numpy()[ok]
    order = np.argsort(ep)
    ep, val = ep[order], val[order]
    if len(ep) < 3:
        raise ValueError(f"{path}: fewer than 3 production values")
    step = float(np.median(np.diff(ep)))
    if "kwh" in str(vcol).lower():
        val = val / (step / 3600.0)
    grid = data["t0"] + np.arange(data["T"])
    prod = np.interp(grid, ep + step / 2.0, val)          # value of an interval sits at its middle
    j = np.searchsorted(ep, grid)
    gap = np.zeros(data["T"], bool)
    inside = (j > 0) & (j < len(ep))
    gap[inside] = (ep[j[inside]] - ep[j[inside] - 1]) > 3 * step
    gap |= (grid < ep[0]) | (grid > ep[-1] + step)
    prod[gap] = np.nan
    data["P"] = data["P"] + prod
    data["info"].setdefault("warnings", [])
    data["info"]["production"] = {"file": os.path.basename(path), "column": str(vcol), "step_s": step,
                                  "mean_kW": round(float(np.nanmean(prod)), 2),
                                  "seconds_without_production": int(gap.sum())}
    return data


def dark_only(data, cfg, margin_deg=2.0):
    """
    Without production data: keep only the seconds when the panels produce
    nothing (sun more than margin_deg below the horizon at
    cfg['site_lat'], cfg['site_lon']); everything else becomes a gap. In
    winter at this latitude that keeps ~16 h a day, in summer ~5 h.
    """
    lat, lon = np.radians(cfg.get("site_lat", 56.05)), cfg.get("site_lon", 12.7)
    t = pd.to_datetime(data["t0"] + np.arange(data["T"]), unit="s", utc=True)
    doy = t.dayofyear.to_numpy()
    hour_utc = (t.hour + t.minute / 60.0 + t.second / 3600.0).to_numpy()
    decl = np.radians(23.44) * np.sin(2 * np.pi * (284 + doy) / 365.0)
    ha = np.radians(15.0 * (hour_utc + lon / 15.0 - 12.0))
    elev = np.degrees(np.arcsin(np.sin(lat) * np.sin(decl) + np.cos(lat) * np.cos(decl) * np.cos(ha)))
    sun = elev > -margin_deg
    data["P"] = np.where(sun, np.nan, data["P"])
    data["Q"] = np.where(sun, np.nan, data["Q"])
    data["info"]["dark_only"] = {"share_kept": round(float((~sun).mean()), 3), "lat": cfg.get("site_lat", 56.05),
                                 "lon": cfg.get("site_lon", 12.7)}
    return data


def load_weather(path, t0, T, cfg, kind="temperature", required=True):
    """Ambient temperature (kind "temperature") or relative humidity (kind
    "humidity") from a separate file, interpolated to the 1 s grid.
    Understands SMHI open-data exports (header blocks, 'Datum;Tid (UTC)')
    and plain (time, value) files. Returns None if the value column is
    missing and required is False."""
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        lines = fh.readlines()
    smhi = next((k for k, l in enumerate(lines) if l.lstrip("\ufeff").startswith("Datum;Tid")), None)
    if smhi is not None:
        w = pd.read_csv(path, sep=";", skiprows=smhi, encoding="utf-8-sig")
        tcol = next(c for c in w.columns if c.startswith("Tid"))
        times = pd.to_datetime(w["Datum"].astype(str) + " " + w[tcol].astype(str), errors="coerce")
        names = ["Lufttemperatur"] if kind == "temperature" else ["Relativ Luftfuktighet", "Relativ luftfuktighet"]
        vcol = next((c for c in w.columns if c in names), None)
        if vcol is None:
            if required:
                raise ValueError(f"{path}: no column {names[0]} (is it an SMHI {kind} export?)")
            return None
        temp = pd.to_numeric(w[vcol], errors="coerce")
        tz = "UTC"
    else:
        w = _read_table(path)
        times = w[_resolve_col(w, _as_list(cfg["timestamp_col"]) + ["time", "date"], "weather time")]
        cands = (_as_list(cfg["magnitude_covariate_col"]) + ["temp", "temperature", "lufttemperatur"]) \
            if kind == "temperature" else _as_list(cfg.get("humidity_col") or [])
        vcol = _resolve_col(w, cands, f"weather {kind}", required=required)
        if vcol is None:
            return None
        temp = pd.to_numeric(w[vcol], errors="coerce")
        tz = cfg.get("weather_timezone", "UTC")
    ep = _to_epoch_seconds(pd.Series(times), tz) if not pd.api.types.is_numeric_dtype(times) \
        else _to_epoch_seconds(times, tz)
    ok = (ep != np.iinfo(np.int64).min) & temp.notna().to_numpy()
    ep, temp = ep[ok], temp.to_numpy()[ok]
    order = np.argsort(ep)
    grid = t0 + np.arange(T)
    if len(ep) < 2 or ep[order][-1] < grid[0] or ep[order][0] > grid[-1]:
        raise ValueError(f"Weather file {path} does not overlap the meter data.")
    return np.interp(grid, ep[order], temp[order])


def _read_csv_columns_chunked(path, cfg):
    """
    Read only the needed columns of a big CSV in chunks and convert each
    chunk to epoch seconds / floats straight away: a year at 1 s is ~31
    million rows, and holding every timestamp as a text object at once
    would need many GB. Returns a DataFrame with the parsed columns
    (time as int64 epoch seconds).
    """
    with open(path, encoding="utf-8-sig", errors="replace") as fh:
        head = [fh.readline() for _ in range(5)]
    sep = ";" if sum(l.count(";") for l in head) > sum(l.count(",") for l in head) else ","
    decimal = "," if sep == ";" and re.search(r"\d,\d", "".join(head[1:])) else "."
    hdr = pd.read_csv(path, sep=sep, decimal=decimal, encoding="utf-8-sig", nrows=5)
    tcol = _resolve_col(hdr, cfg["timestamp_col"], "timestamp")
    pcol = _resolve_col(hdr, cfg["p_col"], "active power (P)")
    qcol = _resolve_col(hdr, cfg["q_col"], "reactive power (Q)")
    acol = None if cfg.get("weather_path") else \
        _resolve_col(hdr, cfg.get("magnitude_covariate_col") or [], "ambient", required=False)
    cols = [c for c in (tcol, pcol, qcol, acol) if c]
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    parts = []
    reader = pd.read_csv(path, sep=sep, decimal=decimal, encoding="utf-8-sig", usecols=cols,
                         chunksize=int(cfg.get("csv_chunk_rows", 2_000_000)))
    for k, ch in enumerate(reader):
        part = pd.DataFrame({tcol: _to_epoch_seconds(ch[tcol], tz),
                             pcol: pd.to_numeric(ch[pcol], errors="coerce").to_numpy(np.float64),
                             qcol: pd.to_numeric(ch[qcol], errors="coerce").to_numpy(np.float64)})
        if acol:
            part[acol] = pd.to_numeric(ch[acol], errors="coerce").to_numpy(np.float64)
        parts.append(part)
        print(f"  [read] chunk {k + 1}: {sum(len(x) for x in parts):,} rows", flush=True)
    return pd.concat(parts, ignore_index=True), True


def load_grid(cfg):
    """
    Aggregate P/Q (kW, kvar) on a regular 1-second grid (NaN in gaps),
    the ambient temperature on the same grid (from a column or a separate
    weather file), and -- only if present -- ground-truth columns, which are
    used for scoring and nothing else. Real customer files have none; the
    pipeline then runs in real-data mode.
    """
    pre_parsed = False
    if cfg.get("cache_pickle") and os.path.exists(cfg["cache_pickle"]):
        df = pd.read_pickle(cfg["cache_pickle"])
    elif (os.path.splitext(cfg["csv_path"])[1].lower() not in (".pkl", ".pickle", ".xlsx", ".xlsm", ".xls")
          and os.path.getsize(cfg["csv_path"]) > cfg.get("csv_chunk_min_mb", 200) * 1e6):
        df, pre_parsed = _read_csv_columns_chunked(cfg["csv_path"], cfg)
    else:
        df = _read_table(cfg["csv_path"])
    tcol = _resolve_col(df, cfg["timestamp_col"], "timestamp")
    pcol = _resolve_col(df, cfg["p_col"], "active power (P)")
    qcol = _resolve_col(df, cfg["q_col"], "reactive power (Q)")
    info = {"timestamp_col": tcol, "p_col": pcol, "q_col": qcol, "warnings": []}

    t = df[tcol].to_numpy(np.int64) if pre_parsed else \
        _to_epoch_seconds(df[tcol], cfg.get("timestamp_timezone", "Europe/Stockholm"))
    p = pd.to_numeric(df[pcol], errors="coerce").to_numpy(dtype=float)
    q = pd.to_numeric(df[qcol], errors="coerce").to_numpy(dtype=float)
    ok = t != np.iinfo(np.int64).min
    if (~ok).any():
        info["warnings"].append(f"{(~ok).sum()} rows with unreadable timestamps dropped")
    order = np.argsort(t[ok], kind="stable")
    t, p, q = t[ok][order], p[ok][order], q[ok][order]
    keep = np.r_[True, np.diff(t) > 0]
    if (~keep).any():
        info["warnings"].append(f"{(~keep).sum()} duplicate timestamps dropped (first kept)")
    t, p, q = t[keep], p[keep], q[keep]
    step = float(np.median(np.diff(t))) if len(t) > 1 else 1.0
    if step != 1.0:
        info["warnings"].append(f"median sample interval is {step:g} s; the method is tuned for 1 s data")
    unit = cfg.get("power_unit", "auto")
    if unit == "auto":
        unit = "W" if np.nanmedian(np.abs(p)) > 5000 else "kW"
        info["power_unit_detected"] = unit
    if unit == "W":
        p, q = p / 1000.0, q / 1000.0

    t0 = int(t[0])
    idx = t - t0
    T = int(idx[-1]) + 1
    P = np.full(T, np.nan)
    Q = np.full(T, np.nan)
    P[idx] = p
    Q[idx] = q

    src_idx = np.flatnonzero(ok)[order][keep]
    gt_cols = [c for c in cfg.get("ground_truth_cols", []) + cfg.get("continuous_truth_cols", [])
               if c in df.columns]
    gt = pd.DataFrame(np.nan, index=np.arange(T), columns=gt_cols)
    if gt_cols:
        gt.iloc[idx] = df[gt_cols].to_numpy()[src_idx]
        gt = gt.ffill()

    X = None
    if cfg.get("weather_path"):
        X = load_weather(cfg["weather_path"], t0, T, cfg)
        info["ambient_source"] = cfg["weather_path"]
    else:
        acol = _resolve_col(df, cfg.get("magnitude_covariate_col") or [], "ambient", required=False)
        if acol:
            X = pd.Series(np.nan, index=np.arange(T))
            X.iloc[idx] = pd.to_numeric(df[acol], errors="coerce").to_numpy()[src_idx]
            X = X.interpolate(limit_direction="both").to_numpy()
            info["ambient_source"] = acol
    if X is None:
        info["warnings"].append("no ambient temperature: compressor magnitudes are treated as constant")
    RH = None
    if cfg.get("humidity_path"):
        RH = load_weather(cfg["humidity_path"], t0, T, cfg, kind="humidity")
        info["humidity_source"] = cfg["humidity_path"]
    elif cfg.get("weather_path"):
        RH = load_weather(cfg["weather_path"], t0, T, cfg, kind="humidity", required=False)
        if RH is not None:
            info["humidity_source"] = cfg["weather_path"]
    if RH is None and cfg.get("humidity_col"):
        hcol = _resolve_col(df, _as_list(cfg["humidity_col"]), "humidity", required=False)
        if hcol:
            RH = pd.Series(np.nan, index=np.arange(T))
            RH.iloc[idx] = pd.to_numeric(df[hcol], errors="coerce").to_numpy()[src_idx]
            RH = RH.interpolate(limit_direction="both").to_numpy()
            info["humidity_source"] = hcol
    if RH is not None:
        RH = np.clip(RH, 1.0, 100.0)
    X, info["covariate"] = make_covariate(X, RH, cfg, info)
    return {"t0": t0, "T": T, "P": P, "Q": Q, "gt": gt, "X": X, "X_dry": X if info["covariate"] == "dry-bulb degC"
            else info.pop("_x_dry"), "RH": RH, "info": info}


# =========================================================================
# Psychrometrics (humidity)
# =========================================================================
def sat_pressure_hpa(T):
    """Saturation vapour pressure over water (Magnus, hPa)."""
    return 6.112 * np.exp(17.62 * np.asarray(T, float) / (243.12 + np.asarray(T, float)))


def humidity_ratio_gkg(T, RH, p_hpa=1013.25):
    pv = np.asarray(RH, float) / 100.0 * sat_pressure_hpa(T)
    return 1000.0 * 0.622 * pv / (p_hpa - pv)


def dew_point_c(T, RH):
    T = np.asarray(T, float)
    g = np.log(np.asarray(RH, float) / 100.0) + 17.62 * T / (243.12 + T)
    return 243.12 * g / (17.62 - g)


def wet_bulb_c(T, RH):
    """Stull (2011), J. Appl. Meteor. Climatol. 50, 2267-2269."""
    T, RH = np.asarray(T, float), np.asarray(RH, float)
    return (T * np.arctan(0.151977 * np.sqrt(RH + 8.313659)) + np.arctan(T + RH) - np.arctan(RH - 1.676331)
            + 0.00391838 * RH ** 1.5 * np.arctan(0.023101 * RH) - 4.686035)


def enthalpy_kjkg(T, RH, p_hpa=1013.25):
    T = np.asarray(T, float)
    w = humidity_ratio_gkg(T, RH, p_hpa) / 1000.0
    return 1.006 * T + w * (2501.0 + 1.86 * T)


def humidity_measure(T, RH, cfg):
    """(values, label) of the humidity measure used in the checks."""
    m = cfg.get("humidity_measure", "humidity_ratio")
    if m == "rh":
        return np.asarray(RH, float), "RH %"
    if m == "dew_point":
        return dew_point_c(T, RH), "dew point degC"
    return humidity_ratio_gkg(T, RH, cfg.get("air_pressure_hpa", 1013.25)), "humidity ratio g/kg"


def make_covariate(X, RH, cfg, info):
    """The magnitude covariate on the 1 s grid. Returns (X, label)."""
    mode = cfg.get("magnitude_covariate", "dry_bulb")
    if X is None or mode == "dry_bulb":
        return X, "dry-bulb degC"
    if RH is None:
        info["warnings"].append(f"magnitude_covariate '{mode}' needs humidity, none found: dry-bulb temperature used")
        return X, "dry-bulb degC"
    info["_x_dry"] = X
    if mode == "wet_bulb":
        return wet_bulb_c(X, RH), "wet-bulb degC"
    if mode == "enthalpy":
        return enthalpy_kjkg(X, RH, cfg.get("air_pressure_hpa", 1013.25)), "enthalpy kJ/kg"
    raise ValueError(f"magnitude_covariate must be dry_bulb, wet_bulb or enthalpy, not {mode!r}")


def _nan_runs(x):
    """(start, length) of NaN runs."""
    isn = np.isnan(x).astype(np.int8)
    d = np.diff(np.concatenate([[0], isn, [0]]))
    starts = np.flatnonzero(d == 1)
    ends = np.flatnonzero(d == -1)
    return list(zip(starts, ends - starts))


# =========================================================================
# Edge detection
# =========================================================================
def estimate_compensation(Pi, events, cfg, ch=0):
    """
    Compressor-rack signature. On a common suction header the VFD lead
    compressor offsets a fixed stage's start/stop within tens of seconds, so
    after a large switch the aggregate decays partway back. The median of the
    normalised responses after isolated large switches,
        y(s) = (level(s) - level before) / (level just after - level before),
    is fitted with 1 - c * (1 - exp(-s / tau)). Returns (c, tau, n) or None.
    c is the AVERAGE share compensated (the VFD cannot compensate while it
    sits at its speed limits); tau is the site's response time.
    """
    from scipy.optimize import least_squares
    horizon = cfg["rack_horizon_s"]
    big = [e for e in events if abs(e["delta"][0]) >= cfg["rack_min_kw"]]
    bt = [e["t"] for e in big]
    curves = []
    for k, e in enumerate(big):
        t, te = e["t"], e.get("te", e["t"])
        prev = bt[k - 1] if k > 0 else -10 ** 9
        nxt = bt[k + 1] if k + 1 < len(bt) else len(Pi)
        if nxt - t < horizon or t - prev < 120 or te + horizon + 3 >= len(Pi):
            continue
        pre = np.median(Pi[max(0, t - 32):t - 2])
        inst = np.median(Pi[te + 1:te + 4]) - pre
        if abs(inst) < 1:
            continue
        curves.append((Pi[te + 1:te + 1 + horizon] - pre) / inst)
    if len(curves) < 8:
        return None
    m = np.median(np.array(curves), axis=0)
    s = np.arange(1, horizon + 1)
    r = least_squares(lambda p: (1 - p[0] * (1 - np.exp(-s / p[1]))) - m, [0.3, 40.0],
                      bounds=([-0.5, 3.0], [1.5, 600.0]))
    return float(r.x[0]), float(r.x[1]), len(curves)


def correct_compensation(Pi, Qi, events, tau, cfg):
    """
    Undo the rack's compensation, switch by switch and in time order: fit the
    level after each large switch as L + A * exp(-s / tau) (tau = the site
    constant, so a linear fit; A = how much the VFD gave back this time, ~0
    when it sat at a speed limit) and add A * (1 - exp(-s / tau)) back from
    then on. The result is the signal the meter would show without the VFD
    compensating: no settling ramps to mistake for switches, and steps whose
    size is the stage's own power.
    """
    Pc, Qc = Pi.copy(), Qi.copy()
    T = len(Pi)
    big = [e for e in events if abs(e["delta"][0]) >= cfg["rack_min_kw"]]
    bt = [e["t"] for e in big]
    n_corr = 0
    for k, e in enumerate(big):
        te = e.get("te", e["t"])
        nxt = bt[k + 1] if k + 1 < len(bt) else T
        end = min(nxt - 2, te + 1 + int(4 * tau), T)
        if end - (te + 1) < 10:
            continue
        s = np.arange(1, end - te, dtype=float)
        B = np.column_stack([np.ones_like(s), np.exp(-s / tau)])
        A_p = np.linalg.lstsq(B, Pc[te + 1:end], rcond=None)[0][1]
        A_q = np.linalg.lstsq(B, Qc[te + 1:end], rcond=None)[0][1]
        if np.sign(A_p) == np.sign(e["delta"][0]) and abs(A_p) < abs(e["delta"][0]):
            g = 1 - np.exp(-np.arange(1, T - te, dtype=float) / tau)
            Pc[te + 1:] += A_p * g
            Qc[te + 1:] += A_q * g
            n_corr += 1
    # The VFD gives back what it took when the stage stops, but the fitted
    # start and stop amplitudes are never exactly equal (it clips at its
    # speed limits on one side more than the other), so the summed
    # correction random-walks -- by hundreds of kW over days, which breaks
    # every level check downstream. Only its local shape matters (detection
    # and step measurement look at +-1 min), so remove its slow component.
    w = cfg["rack_detrend_s"]
    for X, X0 in ((Pc, Pi), (Qc, Qi)):
        corr = pd.Series(X - X0)
        X -= corr.rolling(w, center=True, min_periods=1).median().to_numpy()
    return Pc, Qc, n_corr


def tstat_ok(t, cfg):
    return t is None or t >= cfg["edge_min_t"]


def _q_steps(Pi, Qi, T, w, gaps, p_spans, cfg):
    """
    Reactive-only steps: candidates of the same mean-difference filter run
    on Q, away from every P transition, kept if the measured step has
    |dQ| >= qstep_min_kvar, (almost) no dP, and a robust t-statistic on Q of
    at least edge_min_t. Returns [(t, dP, dQ)].
    """
    cq = np.concatenate([[0.0], np.cumsum(Qi)])
    tt = np.arange(w, T - w)
    dq = np.zeros(T)
    dq[tt] = (cq[tt + w] - cq[tt]) / w - (cq[tt] - cq[tt - w]) / w
    aq = np.abs(dq)
    for s, n in gaps:
        aq[max(0, s - w - 1): min(T, s + n + w + 1)] = 0.0
    for _, ts, te in p_spans:                       # a P step moves Q too
        aq[max(0, ts - w - 1): min(T, te + w + 2)] = 0.0
    cand = np.flatnonzero(aq > cfg["qstep_detect_threshold_kvar"])
    peaks = []
    for c in cand:
        lo, hi = max(0, c - w), min(T, c + w + 1)
        if aq[c] == aq[lo:hi].max() and (not peaks or c - peaks[-1] > w):
            peaks.append(int(c))
    bounds = sorted([ts for _, ts, _ in p_spans] + [te for _, _, te in p_spans]
                    + [s for s, _ in gaps] + [s + n for s, n in gaps])
    bounds = np.asarray(bounds, int)
    W, g = cfg["edge_refine_window_s"], cfg["edge_refine_guard_s"]
    out = []
    mad_se = lambda x: 1.253 * 1.4826 * np.median(np.abs(x - np.median(x))) / np.sqrt(len(x))
    for k, p in enumerate(peaks):
        prev_b = max([0] + [b for b in bounds[bounds <= p]][-1:] + ([peaks[k - 1]] if k else []))
        nxt = bounds[bounds > p]
        next_b = min([T] + ([int(nxt[0])] if len(nxt) else []) + ([peaks[k + 1]] if k + 1 < len(peaks) else []))
        pre_lo, pre_hi = max(prev_b + g, p - g - W), p - g
        post_lo, post_hi = p + g, min(next_b - g, p + g + W)
        if pre_hi - pre_lo < 5 or post_hi - post_lo < 5:
            continue
        dQ = np.median(Qi[post_lo:post_hi]) - np.median(Qi[pre_lo:pre_hi])
        dP = np.median(Pi[post_lo:post_hi]) - np.median(Pi[pre_lo:pre_hi])
        err = np.hypot(mad_se(Qi[pre_lo:pre_hi]), mad_se(Qi[post_lo:post_hi])) + 1e-6
        if (abs(dQ) >= cfg["qstep_min_kvar"] and abs(dQ) / err >= cfg["edge_min_t"]
                and abs(dP) <= min(2.0, cfg["qstep_max_p_ratio"] * abs(dQ))):
            out.append((p, float(dP), float(dQ)))
    return out


def detect_edges(P, Q, cfg, return_qsteps=False):
    """
    Step events in the aggregate. Detection uses a mean-difference filter
    (mean of the next w samples minus mean of the previous w), which cuts
    1-second noise by ~sqrt(w) compared with a raw first difference, then
    non-maximum suppression. The step VECTOR is re-measured as the
    difference of medians of wider pre/post windows, clipped so they never
    reach into a neighbouring event or across a data gap -- this is the
    measurement fed to the knapsack, so it is robust to single spikes.
    """
    T = len(P)
    gaps = [(int(s), int(n)) for s, n in _nan_runs(P) if n > cfg["long_gap_s"]]
    Pi = pd.Series(P).interpolate(limit_direction="both").to_numpy()
    Qi = pd.Series(Q).interpolate(limit_direction="both").to_numpy()

    w = cfg["edge_detect_window_s"]
    cs = np.concatenate([[0.0], np.cumsum(Pi)])
    tt = np.arange(w, T - w)
    d = np.zeros(T)
    d[tt] = (cs[tt + w] - cs[tt]) / w - (cs[tt] - cs[tt - w]) / w
    ad = np.abs(d)
    for s, n in gaps:
        ad[max(0, s - w - 1): min(T, s + n + w + 1)] = 0.0

    cand = np.flatnonzero(ad > cfg["edge_detect_threshold_kw"])
    peaks = []
    for c in cand:
        lo, hi = max(0, c - w), min(T, c + w + 1)
        if ad[c] == ad[lo:hi].max() and (not peaks or c - peaks[-1] > w):
            peaks.append(int(c))

    # transition extent: for an instantaneous step at s the detector peaks
    # at s and stays above half its peak over [s - w/2, s + w/2]; a ramp of
    # length R widens that to [s - w/2, s + R + w/2]. So the transition is
    # the half-height region shrunk by w/2 at both ends. Peaks of the same
    # sign whose regions touch are one ramp, not two steps.
    spans = [(p, p, p) for p in peaks]               # (peak, start, end)
    if cfg.get("edge_ramp_aware"):
        frac, maxr, h = cfg["edge_ramp_frac"], cfg["edge_max_ramp_s"], w // 2
        spans = []
        for p in peaks:
            sg, lvl = np.sign(d[p]), frac * ad[p]
            a = p
            while a - 1 >= 0 and p - a < maxr + w and np.sign(d[a - 1]) == sg and ad[a - 1] >= lvl:
                a -= 1
            b = p
            while b + 1 < T and b - p < maxr + w and np.sign(d[b + 1]) == sg and ad[b + 1] >= lvl:
                b += 1
            ts, te = min(a + h, p), max(b - h, p)
            if spans and np.sign(d[spans[-1][0]]) == sg and ts <= spans[-1][2] + 1:
                q, s0, _ = spans[-1]
                spans[-1] = (q if ad[q] >= ad[p] else p, s0, max(te, spans[-1][2]))
            else:
                spans.append((p, ts, te))

    W, g = cfg["edge_refine_window_s"], cfg["edge_refine_guard_s"]
    gap_edges = sorted([s for s, _ in gaps] + [s + n for s, n in gaps])
    qsteps = _q_steps(Pi, Qi, T, w, gaps, spans, cfg) if cfg.get("qstep_detection") else []
    q_times = np.asarray([q[0] for q in qsteps], int)

    def se(x):
        return 1.253 * 1.4826 * np.median(np.abs(x - np.median(x))) / np.sqrt(len(x))

    def measure(spans):
        """Step vector of every span, from median windows bounded by the
        neighbouring spans and by data gaps; plus its robust t-statistic."""
        out = []
        for k, (p, ts, te) in enumerate(spans):
            prev_b = spans[k - 1][2] if k > 0 else 0
            next_b = spans[k + 1][1] if k + 1 < len(spans) else T
            for ge in gap_edges:
                if ge <= p:
                    prev_b = max(prev_b, ge)
                else:
                    next_b = min(next_b, ge)
                    break
            if len(q_times):
                # a capacitor stage switching inside a window would leak its
                # -15 kvar into this step's Q: stop the window at it
                i_ = np.searchsorted(q_times, ts)
                if i_ > 0:
                    prev_b = max(prev_b, int(q_times[i_ - 1]) + w // 2)
                j_ = np.searchsorted(q_times, te, side="right")
                if j_ < len(q_times):
                    next_b = min(next_b, int(q_times[j_]) - w // 2)
            pre_lo, pre_hi = max(prev_b + g, ts - g - W), ts - g
            post_lo, post_hi = te + g, min(next_b - g, te + g + W)
            if pre_hi - pre_lo < 3 or post_hi - post_lo < 3:
                pre_lo, pre_hi = max(0, ts - w), ts
                post_lo, post_hi = te, min(T, te + w)
            pre = np.array([np.median(Pi[pre_lo:pre_hi]), np.median(Qi[pre_lo:pre_hi])])
            post = np.array([np.median(Pi[post_lo:post_hi]), np.median(Qi[post_lo:post_hi])])
            tstat = None
            if pre_hi - pre_lo >= 5 and post_hi - post_lo >= 5:
                err = np.hypot(se(Pi[pre_lo:pre_hi]), se(Pi[post_lo:post_hi])) + 1e-6
                tstat = abs(post[0] - pre[0]) / err
            out.append((p, ts, te, pre, post, tstat))
        return out

    # persistence / significance: a step must stand out from the scatter of
    # its own before/after windows (robust standard error of the medians).
    # A noise excursion that passes the magnitude threshold does not; a real
    # step, even a small heater, does. Spurious steps cluster and clip each
    # other's windows, so failing spans are removed and the rest re-measured
    # with their now wider windows until nothing changes.
    for _ in range(6 if cfg.get("edge_significance") else 1):
        meas = measure(spans)
        keep = [m for m in meas
                if abs(m[4][0] - m[3][0]) >= cfg["edge_min_step_kw"]
                and (not cfg.get("edge_significance") or m[5] is None or m[5] >= cfg["edge_min_t"])]
        if len(keep) == len(meas):
            break
        spans = [(m[0], m[1], m[2]) for m in keep]
    events = [{"t": ts, "te": te, "delta": post - pre, "pre": pre, "post": post}
              for p, ts, te, pre, post, _ in meas
              if abs(post[0] - pre[0]) >= cfg["edge_min_step_kw"]
              and (not cfg.get("edge_significance") or tstat_ok(_ , cfg))]
    if return_qsteps:
        return events, gaps, qsteps
    return events, gaps


# =========================================================================
# Appliance model
# =========================================================================
class AppendLog:
    """
    An append-only list that is cheap to copy. The multi-hypothesis tracker
    copies whole tracker states; with plain lists every copy duplicated the
    full history (decisions, switch times, past events), so the cost grew
    with the length of the recording -- quadratic over a long file. Here
    the history is kept as frozen chunks (tuples, shared between copies)
    plus a short open list; a copy shares the chunks. `maxlen` drops the
    oldest chunks (for histories only the recent part of which is used).
    """
    __slots__ = ("_chunks", "_cur", "_n", "_maxlen")
    CHUNK = 256

    def __init__(self, items=(), maxlen=None):
        self._chunks, self._cur, self._n, self._maxlen = [], [], 0, maxlen
        for x in items:
            self.append(x)

    def append(self, x):
        self._cur.append(x)
        self._n += 1
        if len(self._cur) >= self.CHUNK:
            self._chunks.append(tuple(self._cur))
            self._cur = []
            if self._maxlen is not None:
                while self._chunks and self._n - len(self._chunks[0]) >= self._maxlen:
                    self._n -= len(self._chunks.pop(0))

    def extend(self, items):
        for x in items:
            self.append(x)

    def __iter__(self):
        for c in self._chunks:
            yield from c
        yield from self._cur

    def __reversed__(self):
        yield from reversed(self._cur)
        for c in reversed(self._chunks):
            yield from reversed(c)

    def __len__(self):
        return self._n

    def __getitem__(self, i):
        return list(self)[i]

    def __deepcopy__(self, memo):
        new = AppendLog.__new__(AppendLog)
        new._chunks, new._cur, new._n, new._maxlen = list(self._chunks), list(self._cur), self._n, self._maxlen
        return new

    __copy__ = __deepcopy__


def _capped_append(lst, x, keep):
    """Append and, once the list is twice `keep`, drop all but the last
    `keep` (amortised O(1); only the recent part is ever used)."""
    lst.append(x)
    if len(lst) > 2 * keep:
        del lst[:-keep]


class Appliance:
    def __init__(self, uid, mu, cov, cfg, source="online", t_created=0):
        self.id = uid
        self.mu = np.asarray(mu, float).copy()      # magnitude at the current covariate value
        self.mu0 = self.mu.copy()                   # magnitude at the reference covariate value
        self.beta = np.zeros(2)                     # d(step)/d(covariate), per channel
        self.xs, self.ys = [], []                   # matched (covariate, step) pairs for the slope fit
        self.cov = np.asarray(cov, float).copy()
        self.cov0 = self.cov.copy()
        # asymmetric start/stop: a part that starts with the appliance but
        # stops later on its own (evaporator fan after a compressor)
        self.mu_tail = np.zeros(2)
        self.asym = False
        self.tail_on = 0
        self.t_tail = 0
        self.signed = []                            # (sign, observed magnitude) of single matches
        self.n = 0                       # events used for parameter updates
        self.n_matched = 0               # all events attributed to it
        self.state = 0                   # 0 off, 1 on (any unit running)
        self.units = 1                   # identical units (rack); n_on of them are running
        self.n_on = 0
        self.state_known = True
        self.t_switch = t_created
        self.on_durations, self.off_durations = [], []
        self.source = source
        self.confirmed = True
        self.cfg = cfg
        self.switch_log = AppendLog()    # (t, new_state)
        self.merged_into = None

    @property
    def resistive(self):
        return self.mu[0] > 0 and self.mu[1] / self.mu[0] < self.cfg["resistive_qp_ratio"]

    def step(self, sgn, kind="normal"):
        """Predicted signed step vector of one transition of this appliance."""
        if kind == "tail":
            return -self.mu_tail
        if sgn > 0:
            return self.mu - (self.mu_tail if self.tail_on else 0.0)
        return -(self.mu - self.mu_tail)

    def check_asymmetry(self, imp):
        """Starts and stops of one appliance should mirror each other. If the
        start step is significantly larger than the stop step, the
        difference is a part that keeps running after the stop (a fan
        stopping a minute after its compressor): model it as a tail."""
        ons = np.array([y for s_, y in self.signed if s_ > 0][-100:])
        offs = np.array([y for s_, y in self.signed if s_ < 0][-100:])
        if len(ons) < imp["asym_min_each"] or len(offs) < imp["asym_min_each"]:
            return
        d = np.median(ons, axis=0) - np.median(offs, axis=0)
        mad = lambda z: 1.4826 * np.median(np.abs(z - np.median(z)))
        se = 1.253 * math.hypot(mad(ons[:, 0]) / math.sqrt(len(ons)), mad(offs[:, 0]) / math.sqrt(len(offs))) + 1e-6
        if d[0] >= max(imp["asym_min_kw"], imp["asym_min_t"] * se) and -0.15 * d[0] <= d[1] <= imp["max_qp_ratio"] * d[0]:
            self.mu_tail, self.asym = d, True
        elif self.asym and d[0] < 0.5 * imp["asym_min_kw"]:
            self.mu_tail, self.asym, self.tail_on = np.zeros(2), False, 0

    def set_x(self, xv):
        """Evaluate the magnitude at covariate value xv (None = reference)."""
        if xv is None:
            self.mu = self.mu0.copy()
        else:
            self.mu = self.mu0 + self.beta * (xv - self.cfg.get("_x_ref", 0.0))

    def update(self, x, cap=None, xv=None, forget=0.0, m2=None, robust_gate=None):
        """Online Gaussian update; the initial covariance acts as a prior
        worth `cov_prior_weight` observations, the initial mean as one.
        `cap` (std per channel) stops the covariance from creeping wider
        with every borderline match until one model swallows several
        appliances.

        With a covariate value `xv` (temperature_magnitude on), the step is
        modelled as mu0 + beta * (xv - x_ref): beta and mu0 are refitted by
        ridge regression on the most recent matched steps, and the
        covariance is the scatter AROUND that line -- so a compressor whose
        draw rises with ambient keeps a tight model instead of either
        widening (and swallowing neighbours) or rejecting its own hot-day
        steps. `forget` > 0 turns the plain mean into a tracking mean."""
        imp = self.cfg["improvements"]
        if xv is not None:
            self.xs.append(float(xv)); self.ys.append(np.asarray(x, float))
            self.xs, self.ys = self.xs[-imp["temp_window"]:], self.ys[-imp["temp_window"]:]
            fit = self._fit_slope()
            if fit is not None:
                self.n += 1
                self.mu0, self.beta, r = fit
                n0 = self.cfg["cov_prior_weight"]
                self.cov = (n0 * self.cov0 + r.T @ r) / (n0 + len(r))
                self._floor_cap(cap)
                self.set_x(xv)
                return
            # no significant slope: behave exactly like the plain model,
            # including its (stricter) update gate
            if robust_gate is not None and m2 is not None and m2 > robust_gate:
                return
        self.n += 1
        n0 = self.cfg["cov_prior_weight"]
        lr = max(1.0 / (self.n + 1), forget)
        diff = x - self.mu
        self.mu = self.mu + lr * diff
        self.cov = ((n0 + self.n - 1) * self.cov + np.outer(diff, diff) * (1 - lr)) / (n0 + self.n)
        self.mu0 = self.mu - self.beta * ((xv - self.cfg.get("_x_ref", 0.0)) if xv is not None else 0.0)
        self._floor_cap(cap)

    def _fit_slope(self):
        """Robust ridge fit of step ~ mu0 + beta * (x - x_ref), per channel.
        A channel's slope is kept only if BIC prefers it over a constant
        (one extra parameter: N ln(RSS0/RSS1) > ln N), so data without a
        real covariate effect keeps beta = 0 instead of fitting a chance
        correlation with the daily temperature cycle. One refit after
        dropping matches beyond 3 robust sigma (mismatched events).
        Returns (mu0, beta, residuals) or None if no slope is significant."""
        imp = self.cfg["improvements"]
        if imp.get("temp_slope_inductive_only", False) and self.resistive:
            return None        # a heater's draw does not depend on ambient; any fitted slope is spurious
        xs, ys = np.asarray(self.xs), np.asarray(self.ys)
        if len(xs) < imp["temp_min_obs"] or xs.std() < imp["temp_min_spread"]:
            return None
        x_ref = self.cfg.get("_x_ref", 0.0)
        keep = np.ones(len(xs), bool)
        for _ in range(2):
            xk, yk = xs[keep], ys[keep]
            xc = xk - xk.mean()
            beta = (xc @ (yk - yk.mean(axis=0))) / (xc @ xc + imp["temp_ridge"])
            mu0 = yk.mean(axis=0) - beta * (xk.mean() - x_ref)
            r_all = ys - (mu0 + np.outer(xs - x_ref, beta))
            mad = 1.4826 * np.median(np.abs(r_all - np.median(r_all, axis=0)), axis=0) + 1e-6
            keep = np.all(np.abs(r_all) <= 3 * mad + 0.5, axis=1)
            if keep.sum() < imp["temp_min_obs"]:
                return None
        xk, yk = xs[keep], ys[keep]
        N = len(xk)
        rss0 = ((yk - yk.mean(axis=0)) ** 2).sum(axis=0) + 1e-9
        r1 = yk - (mu0 + np.outer(xk - x_ref, beta))
        rss1 = (r1 ** 2).sum(axis=0) + 1e-9
        sig = (N * np.log(rss0 / rss1) > np.log(N)) if imp["temp_slope_bic"] else np.ones(2, bool)
        if not sig.any():
            return None
        beta = np.where(sig, beta, 0.0)
        mu0 = yk.mean(axis=0) - beta * (xk.mean() - x_ref)
        return mu0, beta, yk - (mu0 + np.outer(xk - x_ref, beta))

    def _floor_cap(self, cap):
        floor = np.square(self.cfg["min_cov_sigma"])
        self.cov[0, 0] = max(self.cov[0, 0], floor[0])
        self.cov[1, 1] = max(self.cov[1, 1], floor[1])
        if cap is not None:
            c = np.square(cap)
            sd = np.sqrt(np.diag(self.cov))
            scale = np.minimum(1.0, np.sqrt(c) / sd)
            self.cov = self.cov * np.outer(scale, scale)

    def switch(self, t, new_state, record_duration=True):
        """new_state = number of units running afterwards (0/1 for a
        single-unit appliance). Durations are kept for single units only:
        which unit of a rack stops is not observable."""
        new_state = int(min(max(new_state, 0), self.units))
        if record_duration and self.state_known and self.units == 1:
            _capped_append(self.on_durations if self.state == 1 else self.off_durations,
                           t - self.t_switch, 1000)
        self.n_on = new_state
        self.state = int(new_state > 0)
        self.state_known = True
        self.t_switch = t
        self.switch_log.append((int(t), new_state))


_DUR_CACHE = {}


def _duration_stats(durs, cfg):
    """(mean, std) of log durations, cached by CONTENT. (An earlier key on
    the list's id() was unsafe: the multi-hypothesis tracker creates and
    frees many lists, a freed list's id is reused, and a stale entry then
    changed results depending on memory layout -- the same input could give
    different results in different processes.)"""
    key = (len(durs), hash(tuple(durs)))
    hit = _DUR_CACHE.get(key)
    if hit is not None:
        return hit
    pos = [x for x in durs if x > 0]      # a back-dated switch can leave a zero-length interval;
    if len(pos) < cfg["duration_min_obs"]:  # log(0) would turn the score into NaN
        out = None
    else:
        ld = np.log(np.asarray(pos, float))
        out = (float(ld.mean()), max(float(ld.std()), cfg["duration_log_sigma_floor"]))
    if len(_DUR_CACHE) > 200000:
        _DUR_CACHE.clear()
    _DUR_CACHE[key] = out
    return out


def _duration_logp(durs, d, cfg):
    """Log-normal duration plausibility; 0 until enough observations."""
    st = _duration_stats(durs, cfg)
    if st is None or d <= 0:
        return 0.0
    z = (math.log(d) - st[0]) / st[1]
    return -0.5 * min(z * z, 16.0)


_COMBO_CACHE = {}


def _combo_index(n, k):
    key = (n, k)
    if key not in _COMBO_CACHE:
        _COMBO_CACHE[key] = np.array(list(combinations(range(n), k)), dtype=np.int32).reshape(-1, k)
    return _COMBO_CACHE[key]


# =========================================================================
# FHMM seeding
# =========================================================================
def fhmm_seeds(params, cfg):
    """
    Candidate (P,Q) step vectors from a fitted FHMM: every non-zero level of
    each chain, and every difference between two non-zero levels of the
    same chain. Tiny steps are dropped, near-duplicates merged, and seeds
    that are themselves the sum of two other seeds are dropped (FHMM chains
    often absorb two real appliances switching together into one level).
    """
    steps = []
    for lv in params["levels"]:
        nz = [np.asarray(l)[:2] for l in np.asarray(lv)[1:]]
        steps += nz
        for a, b in combinations(nz, 2):
            steps.append(b - a if b[0] > a[0] else a - b)
    steps = sorted([s for s in steps if s[0] >= cfg["seed_min_step_kw"]], key=lambda s: s[0])
    merged = []
    for s in steps:
        if merged and np.linalg.norm(s - merged[-1]) < cfg["seed_merge_kw"]:
            merged[-1] = (merged[-1] + s) / 2
        else:
            merged.append(s)
    fixed = cfg["improvements"]["fix_seed_composite_filter"]
    cov = np.diag(np.square(cfg["seed_cov_sigma"]))
    keep = []
    for i, s in enumerate(merged):
        others = [o for j, o in enumerate(merged) if j != i]
        comp = False
        for a, b in combinations(others, 2):
            r = s - (a + b)
            if fixed:
                comp = np.linalg.norm(r) < cfg["seed_composite_tol_kw"]
            else:
                # original: tolerance in (wide) seed-covariance units -- so
                # loose that nearly every seed counts as a composite
                comp = r @ np.linalg.solve(2 * cov, r) < 6.0
            if comp:
                break
        if not comp:
            keep.append(s)
    return keep


# =========================================================================
# UNILM tracker
# =========================================================================
class UNILMTracker:
    def __init__(self, cfg, seeds=None, dictionary=None, couplings=None):
        self.cfg = cfg
        self.imp = cfg["improvements"]
        self.apps = []
        self.frozen = False
        self.stats = {"events": 0, "single": 0, "multi": 0, "new": 0, "unexplained": 0,
                      "auto_terminated": 0, "reasserts": 0, "level_repairs": 0,
                      "pruned": 0, "merged": 0, "seeds": 0}
        self.meas_cov = np.diag(np.square(cfg["meas_sigma"]))
        self.c_history = []      # continuous remainder at accepted events (last 600 used)
        self.c_times = []        # ... and their times
        self._c_count = 0        # appends to c_history (level-bound cache key)
        self._lb = None
        self.past = AppendLog(maxlen=5000)   # (t, delta) of recent processed events
        self.log = AppendLog()   # (t, delta, decision) for diagnostics
        self.event_scores = AppendLog()      # per-event explanation log-likelihood (structure objective)
        self.no_create = False   # learn parameters but never add appliances
        self._busy = False
        self.new_cov = np.diag(np.square(self.imp.get("new_cov_sigma") or cfg["new_cov_sigma"]))
        for s in (seeds or []):
            a = self._new_app(s, np.diag(np.square(cfg["seed_cov_sigma"])), "fhmm_seed", 0)
            a.confirmed = not self.imp["seed_confirmation"]
            a.state_known = not self.imp["unknown_initial_state"]
            self.stats["seeds"] += 1
        for d in (dictionary or []):
            # appliances kept from a refinement pass over the TRAINING period
            a = self._new_app(d["mu"], d["cov"], "refined", 0)
            a.beta = np.asarray(d.get("beta", np.zeros(2)), float).copy()
            a.xs, a.ys = list(d.get("xs", [])), list(d.get("ys", []))
            a.mu_tail = np.asarray(d.get("mu_tail", np.zeros(2)), float).copy()
            a.asym = bool(d.get("asym", False))
            a.signed = list(d.get("signed", []))
            a.n = min(d["n"], 20)
            a.units = int(d.get("units", 1))
            a.on_durations = list(d["on_durations"])
            a.off_durations = list(d["off_durations"])
        # learned couplings: pairs of transitions that happen together as one
        # physical event (defrost start forces its compressor off), given as
        # (i, si, j, sj) indices into `dictionary`. Matching either
        # orientation of a coupling carries no multi-transition penalty.
        self.couplings = set()
        for i, si, j, sj, *directional in (couplings or []):
            A, X = self.apps[len(seeds or []) + i], self.apps[len(seeds or []) + j]
            self.couplings.add(frozenset({(A.id, si), (X.id, sj)}))
            if not (directional and directional[0]):
                # symmetric coupling (defrost start / end); a directional one
                # only couples one transition (a fan that starts with its
                # compressor but stops later on its own)
                self.couplings.add(frozenset({(A.id, -si), (X.id, -sj)}))

    def _new_app(self, mu, cov, source, t):
        a = Appliance(len(self.apps), mu, cov, self.cfg, source, t)
        self.apps.append(a)
        return a

    @property
    def live(self):
        return [a for a in self.apps if a.merged_into is None]

    # ------------------------------------------------------------ helpers
    def _on_power(self):
        return sum(a.mu[0] * a.n_on if a.state == 1 else (a.mu_tail[0] if a.tail_on else 0.0)
                   for a in self.live if a.state == 1 or a.tail_on)

    def _level_bounds(self):
        if len(self.c_history) < 30:
            return (0.0, np.inf) if self.imp["level_check_physical"] else (None, None)
        if self._lb is not None and self._lb[0] == self._c_count:
            return self._lb[1]                 # unchanged since the last call
        self._lb = (self._c_count, self._level_bounds_calc())
        return self._lb[1]

    def _level_bounds_calc(self):
        h = np.asarray(self.c_history[-600:])
        lo = float(np.percentile(h, 2)) - self.cfg["level_sigma_kw"]
        hi = float(np.percentile(h, 98)) + self.cfg["level_sigma_kw"]
        if self.imp["level_check_physical"]:
            lo = max(lo, 0.0)
        return lo, hi

    def _terminate_bound(self, a):
        if self.imp["learned_terminate_bound"] and len(a.on_durations) >= self.cfg["duration_min_obs"]:
            return 1.15 * max(a.on_durations)
        return self.cfg["auto_terminate_default_s"]

    def _auto_terminate(self, t_now):
        for a in self.live:
            if a.state == 1 and a.state_known and a.resistive:
                bound = self._terminate_bound(a)
                if t_now - a.t_switch > bound:
                    a.switch(int(a.t_switch + bound), 0, record_duration=False)
                    self.stats["auto_terminated"] += 1

    def _backdate(self, a, missing_state, t_now):
        """Insert a missed transition of `a` between its last switch and now.
        Look for evidence first: the past event whose step best matches the
        missed transition. Otherwise use the typical duration."""
        expected = a.mu if missing_state > a.n_on else -a.mu
        S = self.meas_cov + a.cov
        best_t, best_m2 = None, self.cfg["new_appliance_m2"]
        for t, d in reversed(self.past):
            if t <= a.t_switch:
                break
            r = d - expected
            m2 = float(r @ np.linalg.solve(S, r))
            if m2 < best_m2:
                best_t, best_m2 = t, m2
        if best_t is None:
            durs = a.on_durations if a.state == 1 else a.off_durations
            span = t_now - a.t_switch
            typ = float(np.median(durs)) if durs else span / 2
            best_t = int(a.t_switch + min(max(typ, 1), max(span - 1, 1)))
        a.switch(best_t, missing_state, record_duration=False)

    def _candidates(self):
        """(appliance, sign, kind). Normally each appliance has exactly one
        available transition. kind='reassert' = the same-direction step,
        which implies the opposite transition was missed earlier."""
        out = []
        for a in self.live:
            if not a.confirmed and self.frozen:
                continue
            if not a.state_known:
                out += [(a, +1, "unknown"), (a, -1, "unknown")]
                continue
            if a.units == 1:
                out.append((a, +1 if a.state == 0 else -1, "normal"))
            else:
                if a.n_on < a.units:
                    out.append((a, +1, "normal"))
                if a.n_on > 0:
                    out.append((a, -1, "normal"))
            if a.tail_on and a.state == 0:
                out.append((a, -1, "tail"))
            if self.imp["missed_transition_repair"] and a.n >= 3 and a.n_on in (0, a.units):
                out.append((a, +1 if a.n_on == a.units else -1, "reassert"))
            if (self.imp.get("unit_online") and a.n_on == a.units and not self.frozen and not self._busy
                    and a.n >= self.imp["unit_min_n"] and not a.resistive and not a.asym):
                out.append((a, +1, "unit"))
        return out

    def _score_all(self, ev, cands, max_k):
        """
        Score every combination of up to max_k candidate transitions -- the
        same quantity as _score(), vectorised over all combinations (the
        per-combination loop was O(candidates^3) Python calls and dominated
        runtime once a site has many appliances). Returns [(ll, m2, combo)]
        sorted best first, ties in generation order (as before).
        """
        n = len(cands)
        if n == 0:
            return []
        imp, cfg = self.imp, self.cfg
        V = np.array([a.step(sg, kd) for a, sg, kd in cands])                  # (n, 2)
        C = np.array([[a.cov[0, 0], a.cov[0, 1], a.cov[1, 1]] for a, _, _ in cands])
        E = np.empty(n)
        for i, (a, sg, kd) in enumerate(cands):
            if kd == "unknown":
                E[i] = -1.0
            elif kd == "reassert":
                E[i] = -imp["reassert_log_penalty"]
            elif kd == "tail":
                E[i] = 0.0
            elif kd == "unit":
                E[i] = -imp["unit_log_cost"] if self._unit_admissible(a, ev) else -1e9
            elif a.units > 1:
                E[i] = 0.0                 # rack: per-unit durations are not observable
            else:
                durs = a.on_durations if sg < 0 else a.off_durations
                E[i] = cfg["duration_weight"] * _duration_logp(durs, ev["t"] - a.t_switch, cfg)
        app = np.array([id(a) for a, _, _ in cands])
        unconf = np.array([not a.confirmed for a, _, _ in cands])
        normal = np.array([kd == "normal" for _, _, kd in cands])
        isunit = np.array([kd == "unit" for _, _, kd in cands])
        mag = np.array([abs(a.mu[0]) for a, _, _ in cands])
        M = self.meas_cov
        d = ev["delta"]
        out = []
        for k in range(1, max_k + 1):
            if k > n:
                break
            I = _combo_index(n, k)
            ok = np.ones(len(I), bool)
            for x in range(k):
                for y in range(x + 1, k):
                    ok &= app[I[:, x]] != app[I[:, y]]
            if k > 1 and imp["seed_reanchor"]:
                ok &= ~unconf[I].any(axis=1)     # a provisional seed must first be seen on its own
            if k > 1:
                ok &= ~isunit[I].any(axis=1)     # one more rack unit: only as the sole explanation
            I = I[ok]
            if not len(I):
                continue
            pred = V[I].sum(axis=1)
            Cs = C[I].sum(axis=1)
            s00, s01, s11 = Cs[:, 0] + M[0, 0], Cs[:, 1] + M[0, 1], Cs[:, 2] + M[1, 1]
            det = s00 * s11 - s01 * s01
            r0, r1 = d[0] - pred[:, 0], d[1] - pred[:, 1]
            m2 = (r0 * r0 * s11 - 2 * r0 * r1 * s01 + r1 * r1 * s00) / det
            ll = -0.5 * m2 - 0.5 * np.log(det) - cfg["multi_log_penalty"] * (k - 1) + E[I].sum(axis=1)
            if k == 2 and self.couplings:
                for row, (i, j) in enumerate(I):
                    if normal[i] and normal[j] and frozenset(
                            {(cands[i][0].id, cands[i][1]), (cands[j][0].id, cands[j][1])}) in self.couplings:
                        ll[row] += cfg["multi_log_penalty"]   # a known joint event, not a coincidence
            if k > 1 and imp.get("cancel_penalty"):
                bad = np.abs(pred[:, 0]) < imp["cancel_ratio"] * mag[I].max(axis=1)
                ll[bad], m2[bad] = -1e9, 1e9
            out.extend(zip(ll.tolist(), m2.tolist(), (tuple(cands[i] for i in row) for row in I)))
        out.sort(key=lambda s: -s[0])
        return out

    def _score(self, ev, combo):
        pred = np.zeros(2)
        S = self.meas_cov.copy()
        for a, sgn, kind in combo:
            pred += a.step(sgn, kind)
            S += a.cov
        r = ev["delta"] - pred
        m2 = float(r @ np.linalg.solve(S, r))
        ll = -0.5 * m2 - 0.5 * math.log(np.linalg.det(S))
        ll -= self.cfg["multi_log_penalty"] * (len(combo) - 1)
        if len(combo) == 2 and self.couplings and all(k == "normal" for _, _, k in combo) \
                and frozenset({(a.id, sg) for a, sg, _ in combo}) in self.couplings:
            ll += self.cfg["multi_log_penalty"]      # a known joint event, not a coincidence
        if len(combo) > 1 and any(k == "unit" for _, _, k in combo):
            return -1e9, 1e9
        if len(combo) > 1 and self.imp.get("cancel_penalty"):
            # Two large loads switching in opposite directions in the same
            # second, netting out to a small step, is a coincidence -- and it
            # is exactly the shape of a bogus explanation built from a
            # composite appliance. A small step should rather be a small
            # appliance.
            biggest = max(abs(a.mu[0]) for a, _, _ in combo)
            if abs(pred[0]) < self.imp["cancel_ratio"] * biggest:
                return -1e9, 1e9
        dur = 0.0
        for a, sgn, kind in combo:
            if kind == "unknown":
                ll -= 1.0
            elif kind == "reassert":
                ll -= self.imp["reassert_log_penalty"]
            elif kind == "tail":
                pass
            elif kind == "unit":
                ll -= self.imp["unit_log_cost"] if self._unit_admissible(a, ev) else 1e9
            elif a.units > 1:
                pass
            else:
                durs = a.on_durations if sgn < 0 else a.off_durations
                dur += _duration_logp(durs, ev["t"] - a.t_switch, self.cfg)
        return ll + self.cfg["duration_weight"] * dur, m2

    def _on_power_after(self, combo):
        on = self._on_power()
        for a, sgn, kind in combo:
            if kind == "reassert":
                continue                 # state ends where it started
            if kind == "tail" or kind == "unit" or (a.units > 1 and kind == "normal"):
                on += a.step(sgn, kind)[0]
            elif sgn > 0 and not (a.state_known and a.state == 1):
                on += a.step(sgn, kind)[0]
            elif sgn < 0 and (a.state == 1 or not a.state_known):
                on += a.step(sgn, kind)[0] if a.state == 1 else 0.0
        return on

    def _level_penalty(self, ev, combo):
        if ev.get("busy"):
            return 0.0
        lo, hi = self._level_bounds()
        if lo is None:
            return 0.0
        c_post = ev["post"][0] - self._on_power_after(combo)
        if c_post < lo:
            z = (lo - c_post) / self.cfg["level_sigma_kw"]
        elif c_post > hi:
            z = (c_post - hi) / self.cfg["level_sigma_kw"]
        else:
            return 0.0
        return -0.5 * z * z

    def _unit_admissible(self, a, ev):
        """'One more unit' vs 'a unit's stop was missed': if a stop had been
        missed, the tracker counts one unit too many, so the continuous
        remainder before this event sits about one unit below its typical
        level. Offer the extra unit only when it does not."""
        if len(self.c_history) < 30:
            return False
        c_pre = ev["pre"][0] - self._on_power()
        lim = self.imp["unit_level_margin"] * a.mu[0]
        # the remainder moves slowly (minutes); compare with its value when
        # this appliance last switched, and look for an unexplained drop of
        # about one unit since then (the signature of a missed stop)
        since = [c for c, tc in zip(self.c_history[-200:], self.c_times[-200:]) if tc >= a.t_switch - 1]
        before = [c for c, tc in zip(self.c_history[-200:], self.c_times[-200:]) if tc < a.t_switch][-3:]
        ref = since[:1] or before[-1:]
        if not ref:
            return False
        ref = ref[0]
        if c_pre < ref - lim:
            return False
        return not since or min(since) >= ref - lim

    def _level_repair(self, ev):
        """Before explaining the event, check the continuous remainder just
        before it. Too low -> something marked on is really off; too high ->
        something marked off is really on. Fix the single most plausible
        appliance, back-dating the missed transition to the best evidence."""
        lo, hi = self._level_bounds()
        if lo is None or len(self.c_history) < 30:
            return
        typical = float(np.median(self.c_history[-600:]))
        for _ in range(2):
            c_pre = ev["pre"][0] - self._on_power()
            if c_pre < lo:
                pool = [a for a in self.live if a.state == 1 and a.state_known]
                key = lambda a: abs(c_pre + a.mu[0] - typical)
                target = -1
            elif c_pre > hi:
                pool = [a for a in self.live if a.n_on < a.units and a.state_known and a.confirmed]
                key = lambda a: abs(c_pre - a.mu[0] - typical)
                target = +1
            else:
                return
            if not pool:
                return
            a = min(pool, key=key)
            new_c = c_pre + a.mu[0] if target < 0 else c_pre - a.mu[0]
            if not (lo <= new_c <= hi) and abs(new_c - typical) >= abs(c_pre - typical):
                return
            self._backdate(a, a.n_on + target, ev["t"])
            self.stats["level_repairs"] += 1

    # --------------------------------------------------------------- main
    def process(self, ev):
        """Greedy step: prepare, rank the options, apply the best one."""
        self.prepare(ev)
        self.apply(ev, self.options(ev)[0])

    def prepare(self, ev):
        """State changes that happen before an event is explained (they do
        not depend on which explanation is chosen)."""
        self.stats["events"] += 1
        self._busy = bool(ev.get("busy"))
        self._xv = ev.get("x") if self.imp["temperature_magnitude"] else None
        if self._xv is not None:
            for a in self.apps:
                a.set_x(self._xv)
        self._auto_terminate(ev["t"])
        for a in self.apps:
            if a.tail_on and ev["t"] - a.t_tail > self.imp["tail_max_s"]:
                a.tail_on = 0
        if self.imp["level_repair"] and not ev.get("busy"):
            # inside a busy window the level is moved by loads the tracker
            # does not model (charger sessions, cloud passages): no repairs
            self._level_repair(ev)

    def options(self, ev, alternatives=False):
        """
        Ranked explanations of the event, best first. Each option is a dict
        with 'score' (the log-likelihood recorded for the structure
        objective), 'path' (the score used to rank multi-hypothesis paths:
        a new appliance additionally pays one appliance cost), 'kind'
        ('explain' / 'new' / 'unexplained'), 'm2' and 'combo' as
        (appliance index, sign, kind) so it can be applied to a copy.
        The first option is exactly the greedy tracker's choice. With
        alternatives=True, "a new appliance" is added as a competing option
        when the step is positive, learning is on, and the best known
        explanation fits poorly.
        """
        cfg = self.cfg
        cands = self._candidates()
        max_k = 3 if self.imp["triple_transitions"] else cfg["max_simultaneous"]
        scored = self._score_all(ev, cands, max_k)

        idx = {id(a): n for n, a in enumerate(self.apps)}
        opts = []
        for ll, m2, combo in scored[:cfg["shortlist_k"]]:
            if m2 > cfg["new_appliance_m2"]:
                continue
            if len(combo) > 1 and self.imp.get("multi_gate") and m2 > self.imp["multi_max_m2"]:
                continue
            if combo[0][2] == "unit" and m2 > self.imp["unit_max_m2"]:
                continue                         # an extra unit must match the known unit closely
            tot = ll + cfg["level_weight"] * self._level_penalty(ev, combo)
            opts.append({"score": tot, "path": tot, "kind": "explain", "m2": m2,
                         "combo": tuple((idx[id(a)], sg, kd) for a, sg, kd in combo)})
        opts.sort(key=lambda o: -o["score"])     # stable: ties keep the greedy order
        if opts and self.imp["new_hypothesis_competition"] \
                and opts[0]["score"] < -self.imp["new_appliance_log_cost"]:
            opts = []
        can_create = ev["delta"][0] > 0 and not self.frozen and not self.no_create and not ev.get("busy")
        u = self.imp["unexplained_log_cost"]
        app_cost = self.imp.get("mht_new_appliance_cost", 16.0)
        fallback = {"score": -u, "path": -u - (app_cost if can_create else 0.0),
                    "kind": "new" if can_create else "unexplained", "m2": None, "combo": None}
        if not opts:
            return [fallback]
        if alternatives and can_create and opts[0]["m2"] > self.imp.get("mht_weak_fit_m2", 9.0):
            opts.append(fallback)
            opts.sort(key=lambda o: -o["path"])
        return opts

    def apply(self, ev, opt):
        cfg, t = self.cfg, ev["t"]
        xv = self._xv
        if opt["kind"] != "explain":
            if opt["kind"] == "new":
                a = self._new_app(ev["delta"], self.new_cov, "online", t)
                a.n = a.n_matched = 1
                a.switch(t, 1, record_duration=False)
                self.stats["new"] += 1
                self.log.append((t, ev["delta"], f"NEW A{a.id}"))
            else:
                self.stats["unexplained"] += 1
                self.log.append((t, ev["delta"], "UNEXPLAINED"))
            self.event_scores.append(opt["score"])
            self.past.append((t, ev["delta"]))
            return
        m2 = opt["m2"]
        combo = [(self.apps[i], sg, kd) for i, sg, kd in opt["combo"]]
        self.stats["single" if len(combo) == 1 else "multi"] += 1
        self.event_scores.append(opt["score"])
        self.log.append((t, ev["delta"], " ".join(
            f"A{a.id}t" if k == "tail" else
            f"A{a.id}{'+' if s > 0 else '-'}{'r' if k == 'reassert' else 'u' if k == 'unit' else ''}"
            for a, s, k in combo)))
        pred_step = {id(a): a.step(sgn, kind) for a, sgn, kind in combo}
        for a, sgn, kind in combo:
            a.n_matched += 1
            if kind == "tail":
                a.tail_on = 0
                continue
            if not a.confirmed and self.imp["seed_reanchor"] and not self.frozen:
                # FHMM said "something switches roughly here"; the event
                # says exactly what. Re-anchor, and track it from now on
                # with a new-appliance covariance.
                a.mu = sgn * ev["delta"]
                a.mu0 = a.mu.copy(); a.beta = np.zeros(2); a.xs, a.ys = [], []
                a.cov = self.new_cov.copy()
                a.n = 1
                m2 = 0.0
            a.confirmed = True
            if kind == "reassert":
                self._backdate(a, a.n_on - sgn, t)
                self.stats["reasserts"] += 1
            if kind == "unit":
                a.units += 1
                self.stats["units_added"] = self.stats.get("units_added", 0) + 1
            if kind == "unknown":
                new = 1 if sgn > 0 else 0
            else:
                new = a.n_on + sgn
            a.switch(t, new, record_duration=(kind == "normal"))
            if sgn > 0:
                a.tail_on = 0
            elif a.asym:
                a.tail_on, a.t_tail = 1, t
        gate = (self.imp["robust_update_max_m2"] if self.imp["robust_model_update"]
                else cfg["update_max_m2"])
        if xv is not None:
            gate = self.imp["temp_data_gate_m2"]   # slope needs the hot/cold steps too
        cap = self.imp["max_cov_sigma"] if self.imp["robust_model_update"] else None
        robust = (self.imp["robust_update_max_m2"] if self.imp["robust_model_update"]
                  else cfg["update_max_m2"])
        busy = bool(ev.get("busy"))
        if not self.frozen and not busy and len(combo) == 1 and m2 <= gate and combo[0][2] != "tail":
            a, sgn, kind = combo[0]
            # the observed step, converted to the full "everything on" magnitude
            # the model stores (a stop of an asymmetric appliance lacks its tail)
            y = sgn * ev["delta"] + (a.mu - sgn * pred_step[id(a)])
            a.update(y, cap=cap, xv=xv, forget=self.imp["magnitude_forgetting"],
                     m2=m2, robust_gate=robust)
            if self.imp.get("asymmetric_steps") and kind == "normal":
                a.signed.append((sgn, sgn * ev["delta"]))
                a.signed = a.signed[-250:]
                a.check_asymmetry(self.imp)
        elif self.frozen and not busy and self.imp["adapt_after_freeze"] and len(combo) == 1 and m2 <= gate:
            # structure stays frozen; only the magnitude keeps tracking
            a, sgn, _ = combo[0]
            a.update(sgn * ev["delta"], cap=cap, xv=xv, forget=self.imp["magnitude_forgetting"])
        c_post = ev["post"][0] - self._on_power()
        if m2 <= cfg["update_max_m2"] and not busy:
            _capped_append(self.c_history, c_post, 600)
            _capped_append(self.c_times, t, 600)
            self._c_count += 1
        self.past.append((t, ev["delta"]))

    def freeze(self):
        """Held-out mode: no new appliances, no model updates."""
        self.frozen = True
        if self.imp["merge_duplicates_at_freeze"]:
            live = sorted(self.live, key=lambda a: -a.n_matched)
            for i, keep in enumerate(live):
                if keep.merged_into is not None:
                    continue
                for other in live[i + 1:]:
                    if other.merged_into is not None:
                        continue
                    r = keep.mu - other.mu
                    if r @ np.linalg.solve(keep.cov + other.cov, r) < self.imp["merge_m2"]:
                        other.merged_into = keep
                        if other.state == 1 and keep.state == 0:
                            keep.switch(other.t_switch, 1, record_duration=False)
                        self.stats["merged"] += 1
        if self.imp["prune_unsupported_at_freeze"]:
            for a in self.live:
                if a.n_matched < self.imp["prune_min_matches"] or not a.confirmed:
                    a.merged_into = "pruned"
                    self.stats["pruned"] += 1

    def merge_identical(self):
        """Two inductive appliances whose steps agree within unit_merge_rel
        in both P and Q are taken as identical units of one rack: one
        appliance, units added, running counts summed."""
        rel = self.imp.get("unit_merge_rel", 0.0)
        if not self.imp.get("multi_unit") or rel <= 0:
            return
        live = sorted([a for a in self.live if a.confirmed and not a.resistive and not a.asym
                       and a.mu0[0] > 0], key=lambda a: -a.n_matched)
        for i, keep in enumerate(live):
            if keep.merged_into is not None:
                continue
            for other in live[i + 1:]:
                if other.merged_into is not None:
                    continue
                if np.all(np.abs(other.mu0 - keep.mu0) <= rel * np.abs(keep.mu0)):
                    other.merged_into = keep
                    other.merge_kind = "units"
                    keep.units += other.units
                    self.stats["units_merged"] = self.stats.get("units_merged", 0) + 1

    def resync(self, t):
        """After a long data gap the on/off states are unknown."""
        for a in self.live:
            a.state_known = False
            a.t_switch = t

    # ------------------------------------------------------------- output
    def state_matrix(self, T):
        """One on/off row per surviving appliance. Merged duplicates are
        OR-ed into the appliance they were merged into; pruned appliances
        are dropped from the output."""
        def row(a):
            s = np.zeros(T, dtype=np.int8)
            cur, t_prev = 0, 0
            for t, st in sorted(a.switch_log):
                s[t_prev:t] = cur
                cur, t_prev = st, t
            s[t_prev:] = cur
            return s
        out = {}
        for a in self.apps:
            if a.merged_into == "pruned":
                continue
            root = a
            while isinstance(root.merged_into, Appliance):
                root = root.merged_into
            if root.merged_into == "pruned":
                continue
            r = row(a)
            if root.id in out:
                prev = out[root.id][1]
                out[root.id] = (root, prev + r if getattr(a, "merge_kind", None) == "units" else prev | r)
            else:
                out[root.id] = (root, r)
        apps = [v[0] for v in out.values()]
        names = [f"A{a.id}({a.mu[0]:.1f},{a.mu[1]:.1f}{',seed' if a.source == 'fhmm_seed' else ''})"
                 for a in apps]
        rows = np.array([v[1] for v in out.values()]) if out else np.zeros((0, T), np.int8)
        return names, rows, apps


def _track(events, gaps, T, cfg, seeds=None, split_t=None, dictionary=None, frozen=False,
           couplings=None, no_create=False, mht=False):
    tr = UNILMTracker(cfg, seeds, dictionary, couplings)
    tr.no_create = no_create
    tr.frozen = frozen          # frozen from the start: pure evaluation of a fixed dictionary
    if mht and cfg["improvements"]["mht_beam"] > 1:
        return _track_mht(tr, events, gaps, T, cfg, split_t)
    gap_ends = sorted(s + n for s, n in gaps)
    gi, frozen = 0, False
    for ev in events:
        while gi < len(gap_ends) and gap_ends[gi] <= ev["t"]:
            if cfg["improvements"]["unknown_initial_state"]:
                tr.resync(gap_ends[gi])
            gi += 1
        if split_t is not None and not frozen and ev["t"] >= split_t:
            tr.freeze()
            frozen = True
        tr.process(ev)
    tr._auto_terminate(T)
    return tr


def _clone(tr):
    """Deep copy of a tracker that shares the (read-only) configuration."""
    memo = {id(tr.cfg): tr.cfg, id(tr.imp): tr.imp}
    return copy.deepcopy(tr, memo)


def _track_mht(tr0, events, gaps, T, cfg, split_t):
    """
    Multi-hypothesis tracking: a beam search over explanation paths.

    The greedy tracker commits to its best explanation at every event; one
    wrong commitment (a composite, a bad first anchor, a heater toggled to
    absorb a drifted compressor step) changes every later decision. Here up
    to `mht_beam` complete tracker states are kept. At each event every
    hypothesis branches into its explanations that score within
    `mht_margin` of its best one (at most `mht_branch`), plus "a new
    appliance" when even the best known explanation fits poorly. Paths are
    ranked by their summed explanation log-likelihood (a new appliance pays
    `mht_new_appliance_cost`), so a choice that looked slightly worse at the
    time wins if it lets later events be explained better. Branching only
    on genuinely close alternatives keeps the beam from filling with
    near-identical copies. The best path at the end is returned.
    """
    imp = cfg["improvements"]
    K, M, D = imp["mht_beam"], imp["mht_branch"], imp["mht_margin"]
    gap_ends = sorted(s + n for s, n in gaps)
    gi, frozen = 0, False
    hyps = [(0.0, tr0)]
    n_branch_events = 0
    for ev in events:
        while gi < len(gap_ends) and gap_ends[gi] <= ev["t"]:
            if imp["unknown_initial_state"]:
                for _, h in hyps:
                    h.resync(gap_ends[gi])
            gi += 1
        if split_t is not None and not frozen and ev["t"] >= split_t:
            for _, h in hyps:
                h.freeze()
            frozen = True
        cand = []
        for hi, (score, h) in enumerate(hyps):
            h.prepare(ev)
            opts = h.options(ev, alternatives=True)
            best = opts[0]["path"]
            for o in opts[:M]:
                if o["path"] >= best - D:
                    cand.append((score + o["path"], hi, o))
        cand.sort(key=lambda c: -c[0])
        cand = cand[:K]
        if len({c[1] for c in cand}) < len(cand) or len(cand) > 1:
            n_branch_events += len(cand) > len(hyps)
        # apply: a parent used by several survivors is cloned for all but one
        by_parent = {}
        for c in cand:
            by_parent.setdefault(c[1], []).append(c)
        new = []
        for hi, cs in by_parent.items():
            parent = hyps[hi][1]
            for c in cs[1:]:
                child = _clone(parent)
                child.apply(ev, c[2])
                new.append((c[0], child))
            parent.apply(ev, cs[0][2])
            new.append((cs[0][0], parent))
        new.sort(key=lambda c: -c[0])
        hyps = new
    best_score, tr = hyps[0]
    tr._auto_terminate(T)
    tr.stats["mht_branch_events"] = n_branch_events
    tr.stats["mht_final_hyps"] = len(hyps)
    return tr


def _state_before(a, t):
    """Tracked state of appliance `a` just before time t (from its switch log)."""
    st = 0
    for ts, s in sorted(a.switch_log):
        if ts >= t:
            break
        st = s
    return int(st > 0)


def _composite_consistency(c, combo, signs):
    """Share of c's switch-on times at which every part was in the state the
    decomposition requires: a '+' part must have been off (it switches on
    with c), a '-' part must have been on (it switches off with c). A real
    composite scores ~1; a numerical coincidence scores roughly the parts'
    duty cycles."""
    ons = [t for t, s in c.switch_log if s == 1]
    if not ons:
        return 0.0
    ok = 0
    for t in ons:
        if all(_state_before(a, t) == (0 if sg > 0 else 1) for sg, a in zip(signs, combo)):
            ok += 1
    return ok / len(ons)


def find_composites(apps, cfg):
    """
    An appliance whose step vector equals the sum or difference of two
    (or the sum of three) OTHER, more frequently matched appliances is a
    composite: several real transitions that happened in the same second
    and got learned as one "appliance" (e.g. compressor on + its defrost
    heater off at defrost end). Composites are rarer than their parts --
    they need a coincidence -- which is what stops a genuine appliance that
    happens to equal A - B numerically from being retired: the rarer one
    goes. Returns {retired_id: description}.
    """
    imp = cfg["improvements"]
    retired = {}
    order = sorted(apps, key=lambda a: a.n_matched)
    for c in order:
        parts = [a for a in apps if a is not c and a.id not in retired
                 and a.n_matched > c.n_matched and a.mu[0] >= cfg["edge_min_step_kw"]]
        best = None
        for k, signs_list in ((2, [(1, 1), (1, -1), (-1, 1)]), (3, [(1, 1, 1)])):
            for combo in combinations(parts, k):
                for signs in signs_list:
                    pred = sum(sg * a.mu for sg, a in zip(signs, combo))
                    S = c.cov + sum(a.cov for a in combo)
                    r = c.mu - pred
                    m2 = float(r @ np.linalg.solve(S, r))
                    if m2 < imp["composite_m2"] and (best is None or m2 < best[0]):
                        cons = _composite_consistency(c, combo, signs)
                        if cons < imp["composite_min_consistency"]:
                            continue
                        best = (m2, " ".join(f"{'+' if sg > 0 else '-'}A{a.id}" for sg, a in zip(signs, combo))
                                + f", state-consistent at {cons:.0%} of its switch-ons")
        if best is not None:
            retired[c.id] = f"A{c.id}({c.mu[0]:.1f},{c.mu[1]:.1f}) = {best[1]} (m2 {best[0]:.1f})"
    return retired


def _dictionary(apps):
    return [{"mu": a.mu0.copy(), "beta": a.beta.copy(), "xs": list(a.xs), "ys": list(a.ys),
             "mu_tail": a.mu_tail.copy(), "asym": a.asym, "signed": list(a.signed),
             "cov": a.cov.copy(), "n": a.n, "units": a.units,
             "on_durations": list(a.on_durations), "off_durations": list(a.off_durations)}
            for a in apps]


def _joint_consistency(c, parts):
    """
    Behavioural test that C is really these parts switching together.
    parts = [(appliance, sign)] with C = sum(sign * part). Then at every
    switch-ON of C each part must have been in the state that lets it make
    its move (sign +1: off -> on; sign -1: on -> off), and at every switch-OFF
    of C the reverse. Returns the lower of the two agreement rates. A genuine
    composite scores ~1 on both; an independent appliance that merely equals
    the sum numerically passes one side only by chance (about the parts'
    duty cycles), so the minimum separates them. None if C has too few
    switches in either direction to judge.

    Off by default: tested, it also rejects the genuine composites, because
    a composite absorbs its parts' transitions and so corrupts exactly the
    tracked part states this test reads (e.g. after "Z1 off + D1 on" is
    explained as one composite switch-off, the tracker still believes Z1 is
    running). Relative frequency is used instead.
    """
    ons = [t for t, s in c.switch_log if s == 1]
    offs = [t for t, s in c.switch_log if s == 0]
    if len(ons) < 3 or len(offs) < 3:
        return None

    def rate(times, flip):
        ok = 0
        for t in times:
            if all(_state_before(a, t) == ((0 if sg > 0 else 1) ^ flip) for a, sg in parts):
                ok += 1
        return ok / len(times)
    return min(rate(ons, 0), rate(offs, 1))


def structure_search(events, gaps, split_t, cfg, seeds=None):
    """
    Penalised-likelihood search over the appliance dictionary, on the
    TRAINING events only (the held-out part is never looked at).

    Objective = sum over training events of the log-likelihood of the
    explanation the tracker chooses (unexplained events get a fixed cost)
    minus a per-appliance cost -- the trade-off BIC makes in the FHMM
    structure search, applied to event explanations. Candidate dictionaries
    are scored FROZEN (no updates, no new appliances): learning during a
    comparison makes the objective path-dependent, with run-to-run noise
    larger than the per-appliance cost.

    Moves:
      retire C          drop an appliance (noise appliance, duplicate)
      decompose C       C = (+-)A (-+) X with A known and X missing: replace C
                        by X, and record that A and X switch together.
                        "Compressor on + defrost heater off" (33, 22.8) with
                        compressor (42, 24) gives the heater (9.4, 1.1).
                        Retiring alone fails: the composite re-forms at the
                        next coincidence unless its missing part exists.
      couple C          C = sA*A + sX*X with both parts known: replace C by a
                        coupling -- the pair is explained jointly, without the
                        coincidence penalty. This is the case where the
                        "composite" is a real physical coupling (defrost start
                        forces the compressor off every time), which a model of
                        independent appliances cannot represent.
    The best move is kept if it beats re-tracking the unchanged dictionary by
    at least one appliance cost; repeat until nothing improves.
    """
    imp = cfg["improvements"]
    train = [e for e in events if e["t"] < split_t]
    tgaps = [g for g in gaps if g[0] < split_t]
    K = imp["appliance_log_cost"] or 0.5 * 5 * math.log(max(len(train), 2))
    gate = np.diag(np.square(cfg["new_cov_sigma"]))

    def evaluate(dictionary, couplings, use_seeds=False, learn=False, mht=False):
        tr = _track(train, tgaps, split_t, cfg, seeds if use_seeds else None, None,
                    dictionary, frozen=not learn, couplings=couplings, mht=mht)
        n_app = len(dictionary) if dictionary is not None else len(
            [a for a in tr.live if a.confirmed and a.n_matched >= 1])
        # an extra identical unit adds a state, not a magnitude: half a cost
        n_app += 0.5 * sum(d.get("units", 1) - 1 for d in (dictionary or []))
        return sum(tr.event_scores) - K * n_app, tr

    def units_supported(a, T_):
        """All units must be seen running together often enough (the same
        test prune_units() applies to the final result)."""
        cnt = np.zeros(T_, np.int16)
        cur, tp = 0, 0
        for ts, st in sorted(a.switch_log):
            ts = min(ts, T_)
            cnt[tp:ts] = cur
            cur, tp = st, ts
        cnt[tp:] = cur
        top = cnt >= a.units
        episodes = int((np.diff(top.astype(np.int8)) == 1).sum() + top[0])
        return top.mean() >= imp["unit_top_min_share"] and episodes >= imp["unit_top_min_episodes"]

    def m2(x, cov):
        return float(x @ np.linalg.solve(cov, x))

    # online discovery. With MHT, the dictionary the search starts from is
    # the one the final (multi-hypothesis) pass would build, so composites
    # that MHT's "new appliance" branches create get cleaned up here instead
    # of surviving into the final result.
    obj, tr = evaluate(None, [], use_seeds=True, learn=True,
                       mht=imp.get("search_mht_discovery", False))
    apps = [a for a in tr.live if a.confirmed and a.n_matched >= imp["prune_min_matches"]]
    coup = []                                  # (A, sA, X, sX) as appliance objects
    log = [{"move": "online discovery", "objective": round(obj, 1),
            "appliances": [f"({a.mu[0]:.1f},{a.mu[1]:.1f}) n={a.n_matched}" for a in apps]}]

    def pack(app_list, coup_list, extra=None):
        dic = _dictionary(app_list) + ([extra] if extra is not None else [])
        idx = {id(a): k for k, a in enumerate(app_list)}
        cp = [(idx[id(A)], sA, idx[id(X)], sX, *dr) for A, sA, X, sX, *dr in coup_list
              if id(A) in idx and id(X) in idx]
        return dic, cp

    for _ in range(imp["structure_max_passes"]):
        for a in apps:
            a.set_x(None)                      # compare magnitudes at the reference covariate
        dic, cp = pack(apps, coup)
        obj, tr_ref = evaluate(dic, cp)
        log.append({"move": "(re-track unchanged)", "objective": round(obj, 1)})
        cands = []
        for c in apps:
            rest = [a for a in apps if a is not c]
            cands.append((f"retire ({c.mu[0]:.1f},{c.mu[1]:.1f})", rest, coup, None, None))
            for A in rest:
                if A.n_matched <= c.n_matched:
                    continue
                x = c.mu - A.mu
                sA = 1
                if x[0] < 0:
                    x, sA = -x, -1           # c = A - x  ->  coupling (A,+1, X,-1)
                else:
                    sA = 1                   # c = A + x  ->  coupling (A,+1, X,+1)
                if x[0] < cfg["edge_min_step_kw"]:
                    continue
                if not (-0.15 * x[0] <= x[1] <= imp["max_qp_ratio"] * x[0]):
                    continue                 # no physical load has that power factor
                if any(m2(x - b.mu, b.cov + gate) < 9.0 for b in apps):
                    continue                 # part already known: the couple move covers it
                sX = 1 if (c.mu - A.mu)[0] > 0 else -1
                if c.n_matched > imp["composite_max_rel_freq"] * A.n_matched:
                    continue                 # too frequent to be a coincidence of A and X
                if imp["search_state_consistency"]:
                    cons = _joint_consistency(c, [(A, 1)])
                    if cons is None or cons < imp["composite_min_consistency"]:
                        continue
                # X = C - A is estimated from two learned vectors: its
                # uncertainty is the sum of theirs, not a fresh wide prior
                floor = np.diag(np.square(cfg["min_cov_sigma"]))
                extra = {"mu": x, "beta": (c.beta - A.beta) * (1 if (c.mu - A.mu)[0] > 0 else -1),
                         "cov": np.maximum(c.cov + A.cov, floor), "n": 3,
                         "on_durations": [], "off_durations": []}
                cands.append((f"decompose ({c.mu[0]:.1f},{c.mu[1]:.1f}) = A({A.mu[0]:.1f},{A.mu[1]:.1f}) "
                              f"{'+' if sX > 0 else '-'} X({x[0]:.1f},{x[1]:.1f})",
                              rest, coup, extra, (A, 1, "X", sX)))
            for A, X in combinations(rest, 2):
                if min(A.n_matched, X.n_matched) <= c.n_matched:
                    continue
                for sA, sX in ((1, 1), (1, -1), (-1, 1)):
                    if m2(c.mu - (sA * A.mu + sX * X.mu), c.cov + A.cov + X.cov) < 9.0:
                        if c.n_matched > imp["composite_max_rel_freq"] * min(A.n_matched, X.n_matched):
                            continue
                        if imp["search_state_consistency"]:
                            cons = _joint_consistency(c, [(A, sA), (X, sX)])
                            if cons is None or cons < imp["composite_min_consistency"]:
                                continue
                        cands.append((f"couple ({c.mu[0]:.1f},{c.mu[1]:.1f}) = "
                                      f"{'+' if sA > 0 else '-'}({A.mu[0]:.1f},{A.mu[1]:.1f}) "
                                      f"{'+' if sX > 0 else '-'}({X.mu[0]:.1f},{X.mu[1]:.1f})",
                                      rest, coup + [(A, sA, X, sX)], None, None))
        if imp.get("asymmetric_steps") and imp.get("asym_merge_move"):
            # merge: two appliances that are one unit's start and stop. The
            # bigger one is the start (compressor + fan), the smaller the stop
            # (compressor alone); replace both by one asymmetric appliance
            # whose tail is the difference. The objective decides -- two
            # genuinely different compressors are sometimes on together,
            # which one merged appliance cannot explain.
            for c in apps:
                for A in apps:
                    if A is c:
                        continue
                    x = c.mu - A.mu
                    if not (imp["asym_min_kw"] <= x[0] <= 0.35 * A.mu[0]):
                        continue
                    if not (-0.15 * x[0] <= x[1] <= imp["max_qp_ratio"] * x[0]):
                        continue
                    rest = [a for a in apps if a is not c and a is not A]
                    merged = {"mu": c.mu0.copy(), "beta": c.beta.copy(), "cov": c.cov.copy(),
                              "mu_tail": x.copy(), "asym": True, "n": max(c.n, A.n),
                              "on_durations": list(c.on_durations), "off_durations": list(A.off_durations),
                              "signed": []}
                    cands.append((f"merge start ({c.mu[0]:.1f},{c.mu[1]:.1f}) + stop ({A.mu[0]:.1f},{A.mu[1]:.1f})"
                                  f" -> asymmetric, tail ({x[0]:.1f},{x[1]:.1f})", rest, coup, merged, None))
        if imp.get("asymmetric_signatures"):
            # One physical unit learned as two appliances: one is (almost)
            # only ever switched ON, the other (almost) only OFF -- e.g. a
            # compressor whose evaporator fan starts with it but stops a minute
            # later. A normal appliance switches on and off equally often, so
            # this sign imbalance is the signature. Replace the on-heavy one
            # by the part X = C - A, coupled to A's start only.
            ups, downs = {}, {}
            for _, _, dec in tr_ref.log:
                for m_ in re.finditer(r"A(\d+)([+-])(?!r)", dec):
                    (ups if m_.group(2) == "+" else downs)[int(m_.group(1))] = \
                        (ups if m_.group(2) == "+" else downs).get(int(m_.group(1)), 0) + 1
            frac_up = {}
            for k_ in range(len(apps)):
                n_ = ups.get(k_, 0) + downs.get(k_, 0)
                frac_up[k_] = (ups.get(k_, 0) / n_) if n_ >= imp["asym_min_events"] else None
            for ic, c in enumerate(apps):
                for ia, A in enumerate(apps):
                    if A is c or frac_up[ic] is None or frac_up[ia] is None:
                        continue
                    fq = imp["asym_min_frac"]
                    if frac_up[ic] >= fq and frac_up[ia] <= 1 - fq:
                        sgn_ = 1          # C is A's start (+ X); A's stop is A alone
                    elif frac_up[ic] <= 1 - fq and frac_up[ia] >= fq:
                        sgn_ = -1         # C is A's stop (+ X); A's start is A alone
                    else:
                        continue
                    x = c.mu - A.mu
                    if x[0] < cfg["edge_min_step_kw"] or not (-0.15 * x[0] <= x[1] <= imp["max_qp_ratio"] * x[0]):
                        continue
                    rest = [a for a in apps if a is not c]
                    known = [b for b in rest if m2(x - b.mu, b.cov + gate) < 9.0]
                    tag = (f"asymmetric ({c.mu[0]:.1f},{c.mu[1]:.1f}) = A({A.mu[0]:.1f},{A.mu[1]:.1f}) "
                           f"{'start' if sgn_ > 0 else 'stop'} + X({x[0]:.1f},{x[1]:.1f})")
                    if known:
                        cands.append((tag + " [X known]", rest, coup + [(A, sgn_, known[0], sgn_, True)], None, None))
                    else:
                        floor = np.diag(np.square(cfg["min_cov_sigma"]))
                        extra = {"mu": x, "beta": c.beta - A.beta, "cov": np.maximum(c.cov + A.cov, floor),
                                 "n": 3, "on_durations": [], "off_durations": []}
                        cands.append((tag, rest, coup, extra, (A, sgn_, "X", sgn_, True)))
        if imp.get("multi_unit"):
            # Identical units. A rack modelled as one unit re-asserts its start
            # whenever another unit starts ("missed stop" repairs); two copies
            # of the same unit show up as two appliances with the same step.
            rplus = {}
            for _, _, dec in tr_ref.log:
                for m_ in re.finditer(r"A(\d+)\+r", dec):
                    rplus[int(m_.group(1))] = rplus.get(int(m_.group(1)), 0) + 1
            ok = lambda a: not a.resistive and not a.asym and a.mu0[0] > 0
            near = lambda c, A, r: np.all(np.abs(A.mu0 - c.mu0) <= r * np.abs(c.mu0))
            for ic, c in enumerate(apps):
                if any(A is not c and near(c, A, imp["unit_twin_rel"]) for A in apps):
                    continue     # a similar appliance already exists: twins, or copies for the merge move
                if c.units < 2:
                    continue     # only a known rack grows: a single compressor's "+ while on" is
                                 # far more often a missed stop (tested: 2-unit compressors appeared)
                if ok(c) and rplus.get(ic, 0) >= imp["unit_min_reasserts"]:
                    cands.append((f"add unit ({c.mu[0]:.1f},{c.mu[1]:.1f}) -> {c.units + 1} units",
                                  list(apps), coup, None, ("units", c, c.units + 1)))
            rel = imp["unit_merge_rel"]
            for ic, c in enumerate(apps):
                for A in apps[ic + 1:]:
                    if ok(c) and ok(A) and np.all(np.abs(A.mu0 - c.mu0) <= rel * np.abs(c.mu0)):
                        keep_, drop_ = (c, A) if c.n_matched >= A.n_matched else (A, c)
                        cands.append((f"merge identical ({keep_.mu[0]:.1f}) + ({drop_.mu[0]:.1f}) -> "
                                      f"{keep_.units + drop_.units} units",
                                      [a for a in apps if a is not drop_], coup, None,
                                      ("units", keep_, keep_.units + drop_.units)))
        best = best_merge = None
        considered = []
        for name, rest, cpl, extra, new_cp in cands:
            d2, c2 = pack(rest, cpl, extra)
            if new_cp is not None and new_cp[0] == "units":
                d2[rest.index(new_cp[1])]["units"] = new_cp[2]
                o, t2 = evaluate(d2, c2)
                sup = units_supported(t2.apps[rest.index(new_cp[1])], split_t)
                considered.append(f"{name}: obj {o:.1f}{'' if sup else ' (all units rarely on together: rejected)'}")
                if not sup:
                    continue
                if name.startswith("merge identical") and (best_merge is None or o > best_merge[0]):
                    best_merge = (o, name, t2, rest, cpl, extra, new_cp)
                if best is None or o > best[0]:
                    best = (o, name, t2, rest, cpl, extra, new_cp)
                continue
            if new_cp is not None and imp["decompose_adds_coupling"]:
                A, sA, _, sX = new_cp[:4]
                c2 = c2 + [(rest.index(A), sA, len(d2) - 1, sX, *new_cp[4:])]
            o, t2 = evaluate(d2, c2)
            if extra is not None:
                # identifiability: a part that never switches on its own cannot
                # be told apart from the composite it was split from
                xid = len(d2) - 1
                solo = sum(1 for _, _, dec in t2.log if dec in (f"A{xid}+", f"A{xid}-"))
                considered.append(f"{name}: obj {o:.1f}, solo events of X {solo}")
                if solo < imp["part_min_solo_events"]:
                    continue
            if best is None or o > best[0]:
                best = (o, name, t2, rest, cpl, extra, new_cp)
        log.append({"move": "(decompositions considered)", "detail": considered})
        if best_merge is not None and best_merge[0] >= obj:
            # two copies of one unit are the most direct evidence of a rack:
            # settle them first, before moves that only fit better. A merge
            # removes a magnitude, so its saving is already in the objective;
            # it only has to explain the events no worse.
            best = best_merge
        elif best is None or best[0] < obj + K:
            break
        obj, name, t2, rest, cpl, extra, new_cp = best
        # frozen run: t2.apps is exactly the evaluated dictionary, in order
        new_apps = list(t2.apps[:len(rest) + (1 if extra is not None else 0)])
        remap = {id(a): new_apps[k] for k, a in enumerate(rest)}
        coup = [(remap[id(A)], sA, remap[id(X)], sX, *dr) for A, sA, X, sX, *dr in cpl
                if id(A) in remap and id(X) in remap]
        if new_cp is not None and new_cp[0] != "units" and imp["decompose_adds_coupling"]:
            A, sA, _, sX = new_cp[:4]
            coup.append((remap[id(A)], sA, new_apps[-1], sX, *new_cp[4:]))
        # refine the accepted dictionary's parameters with one learning pass
        # (no new appliances), so a freshly decomposed part gets fitted
        dic, cp = pack(new_apps, coup)
        tr_fit = _track(train, tgaps, split_t, cfg, None, None, dic, frozen=False,
                        couplings=cp, no_create=True)
        fitted = list(tr_fit.apps[:len(new_apps)])
        remap2 = {id(a): fitted[k] for k, a in enumerate(new_apps)}
        coup = [(remap2[id(A)], sA, remap2[id(X)], sX, *dr) for A, sA, X, sX, *dr in coup]
        apps = [a for a in fitted if a.n_matched >= imp["prune_min_matches"]]
        log.append({"move": name, "objective": round(obj, 1),
                    "appliances": [f"({a.mu[0]:.1f},{a.mu[1]:.1f}){f' x{a.units}' if a.units > 1 else ''} n={a.n_matched}"
                                   for a in apps],
                    "couplings": [f"{'+' if sA > 0 else '-'}({A.mu[0]:.1f}) {'+' if sX > 0 else '-'}({X.mu[0]:.1f})"
                                  + (" [one-way]" if dr and dr[0] else "") for A, sA, X, sX, *dr in coup]})
    return pack(apps, coup), log


def _long_blocks(T_learn, cfg):
    """Learning blocks [(start, end)] spread evenly over [0, T_learn)."""
    n = max(1, int(cfg.get("long_learn_blocks", 3)))
    total = min(int(cfg.get("long_learn_days", 21) * 86400), T_learn)
    blen = total // n
    starts = np.linspace(0, max(T_learn - blen, 0), n).astype(int)
    out = []
    for s0 in starts:
        e0 = min(T_learn, int(s0) + blen)
        if out and s0 < out[-1][1]:
            out[-1] = (out[-1][0], e0)      # overlapping blocks: merge
        else:
            out.append((int(s0), e0))
    return out


def use_long_mode(T, cfg):
    m = cfg.get("long_mode", "auto")
    if m == "auto":
        return T > cfg.get("long_min_days", 14) * 86400
    return bool(m)


def run_tracker_long(events, gaps, T, cfg, seeds=None, split_t=None):
    """
    Long recordings. The structure search re-tracks its learning events
    once per candidate move, so its cost grows with (events x moves) -- fine
    for days, hours for a year. Here it learns from a SAMPLE: long_learn_days
    of data in long_learn_blocks blocks spread over the learning period (the
    training part in evaluation, the whole series otherwise), so seasons and
    operating modes are represented. Block boundaries are treated as data
    gaps (states unknown afterwards). The learned dictionary (appliances and
    couplings) then starts ONE online pass over the whole series, which keeps
    learning (and can still add appliances) up to split_t, exactly like the
    final pass of the short mode. Cost: one structure search on <= 21 days plus
    one pass that is linear in the number of events.
    """
    imp = cfg["improvements"]
    T_learn = split_t if split_t is not None else T
    blocks = _long_blocks(T_learn, cfg)
    learn = [e for e in events if any(a <= e["t"] < b for a, b in blocks)]
    lgaps = [g for g in gaps if any(a <= g[0] < b for a, b in blocks)]
    for (a0, b0), (a1, _) in zip(blocks[:-1], blocks[1:]):
        lgaps.append((b0, a1 - b0))                         # the jump between blocks is a gap
    lgaps.sort()
    cfg_l = dict(cfg)
    if cfg.get("long_block_resync", False):
        cfg_l["improvements"] = dict(imp, unknown_initial_state=True)
    end = blocks[-1][1]
    t0 = time.time()
    if imp.get("structure_search"):
        (dictionary, couplings), log = structure_search(learn, lgaps, end, cfg_l, seeds)
    else:
        tr_l = _track(learn, lgaps, end, cfg_l, seeds, None, mht=True)
        dictionary = _dictionary([a for a in tr_l.live if a.confirmed and a.n_matched >= imp["prune_min_matches"]])
        couplings, log = [], []
    t_learn = time.time() - t0
    # the final pass adds no appliances: anything it created would skip the
    # structure search's clean-up (tested: composites appeared after learning)
    tr = _track(events, gaps, T, cfg, None, split_t, dictionary, couplings=couplings, mht=True,
                no_create=not cfg.get("long_final_create", False))
    tr.refine_log = log
    tr.long_info = {"learn_blocks_s": blocks, "learn_events": len(learn), "events": len(events),
                    "learn_days": round(sum(b - a for a, b in blocks) / 86400, 1),
                    "learn_seconds": round(t_learn, 1), "track_seconds": round(time.time() - t0 - t_learn, 1),
                    "appliances_learned": len(dictionary)}
    return tr


def run_tracker(events, gaps, T, cfg, seeds=None, split_t=None):
    """
    Without composite refinement: one online pass (train, freeze, held-out).
    With it: track the TRAINING events only, retire composite appliances,
    and repeat with the cleaned dictionary until nothing more is retired;
    then do the full online pass starting from that dictionary. Learning
    still continues during the training part of the final pass, and the
    held-out part is never seen before the freeze.
    """
    imp = cfg["improvements"]
    if use_long_mode(T, cfg):
        return run_tracker_long(events, gaps, T, cfg, seeds, split_t)
    if imp.get("structure_search") and split_t is not None:
        (dictionary, couplings), log = structure_search(events, gaps, split_t, cfg, seeds)
        if not any(not e["move"].startswith("(") and e["move"] != "online discovery" for e in log):
            # no structural change found: behave exactly like the plain tracker
            # (re-tracking from the discovered dictionary would take a different
            # learning path and change results without any structural reason)
            tr = _track(events, gaps, T, cfg, seeds, split_t, mht=True)
        else:
            tr = _track(events, gaps, T, cfg, None, split_t, dictionary, couplings=couplings, mht=True)
        tr.refine_log = log
        return tr
    if not imp.get("composite_refinement") or split_t is None:
        return _track(events, gaps, T, cfg, seeds, split_t, mht=True)
    train = [e for e in events if e["t"] < split_t]
    dictionary, log = None, []
    for p in range(imp["refine_max_passes"]):
        tr = _track(train, [g for g in gaps if g[0] < split_t], split_t, cfg,
                    seeds if p == 0 else None, None, dictionary)
        live = [a for a in tr.live if a.confirmed and a.n_matched >= imp["prune_min_matches"]]
        retired = find_composites(live, cfg)
        log.append({"pass": p, "appliances": [f"A{a.id}({a.mu[0]:.1f},{a.mu[1]:.1f}) n={a.n_matched}" for a in live],
                    "retired": list(retired.values())})
        dictionary = [{"mu": a.mu.copy(), "cov": a.cov.copy(), "n": a.n,
                       "on_durations": a.on_durations, "off_durations": a.off_durations}
                      for a in live if a.id not in retired]
        if not retired:
            break
    tr = _track(events, gaps, T, cfg, None, split_t, dictionary)
    tr.refine_log = log
    return tr


def continuous_estimate(P, states, apps, cfg, X=None):
    """Causal EMA of aggregate minus the discrete appliances (each at its
    temperature-dependent magnitude when that model is on)."""
    disc = np.zeros(len(P))
    x_ref = cfg.get("_x_ref")
    for a, s in zip(apps, states):
        if X is not None and x_ref is not None and np.any(a.beta):
            disc += s * (a.mu0[0] + a.beta[0] * (X - x_ref))
        else:
            disc += s * a.mu0[0]
    resid = pd.Series(P - disc).interpolate(limit_direction="both")
    return resid.ewm(alpha=1.0 / cfg["continuous_ema_tau_s"], adjust=False).mean().to_numpy()


# =========================================================================
# Scoring
# =========================================================================
def _f1(pred, truth):
    tp = (pred & truth).sum(); fp = (pred & ~truth).sum(); fn = (~pred & truth).sum()
    p = tp / max(tp + fp, 1); r = tp / max(tp + fn, 1)
    return float(2 * p * r / max(p + r, 1e-9))


def score(names, states, gt, cfg, split_idx):
    """
    Two metrics:
      greedy  -- label-switching-aware one-to-one best match (same as
                 run_staged.py, so numbers compare with FHMM/report).
                 NOTE: flatters split identities -- if a load is tracked by
                 two duplicate appliances, it just picks the better copy.
      mapped  -- duplicate-aware: every discovered appliance is labelled
                 with the ground-truth component it best matches on the
                 TRAINING part; each component's held-out prediction is the
                 OR of all appliances carrying its label. A stuck or
                 duplicate copy now costs precision, as it would in use.
    """
    cols = [c for c in cfg["ground_truth_cols"] if c in gt.columns]
    def_cols = [c for c in cols if "defrost" in c]
    comp_cols = [c for c in cols if c not in def_cols]
    thr = cfg["ground_truth_on_threshold_kw"]
    gt_on = {c: (gt[c].to_numpy() > thr) for c in cols}
    ho = slice(split_idx, None)
    tr = slice(0, split_idx)

    def greedy(sl):
        sc = {(n, c): _f1(states[i, sl].astype(bool), gt_on[c][sl])
              for i, n in enumerate(names) for c in cols}
        rn, rc, out = set(names), set(cols), []
        while rn and rc:
            bp = max(((n, c) for n in rn for c in rc), key=lambda nc: sc[nc])
            out.append((bp[0], bp[1], sc[bp]))
            rn.discard(bp[0]); rc.discard(bp[1])
        return out

    held = greedy(ho)
    full = greedy(slice(None))
    best = {c: max([s for n, cc, s in held if cc == c], default=0.0) for c in cols}
    stable = sum(1 for n1, c1, _ in held for n2, c2, _ in full if n1 == n2 and c1 == c2)

    label = {}
    for i, n in enumerate(names):
        f = {c: _f1(states[i, tr].astype(bool), gt_on[c][tr]) for c in cols}
        c_best = max(f, key=f.get)
        if f[c_best] > 0.1:
            label[i] = c_best
    mapped = {}
    for c in cols:
        members = [i for i, l in label.items() if l == c]
        pred = np.zeros(len(gt_on[c]), dtype=bool)
        for i in members:
            pred |= states[i].astype(bool)
        mapped[c] = _f1(pred[ho], gt_on[c][ho])

    n_dup = sum(max(0, sum(1 for l in label.values() if l == c) - 1) for c in cols)
    # near-identical compressors (true on-power within 6 %) scored as a group:
    # per second, how many of them run vs how many appliances labelled with
    # any of them run (TP = min, FP/FN = the excess) -- identity-free, so a
    # label swap between twins costs nothing, a missed or extra run does
    level = {c: float(np.median(gt[c].to_numpy()[gt_on[c]])) for c in comp_cols if gt_on[c].sum() > 100}
    groups, seen = [], set()
    for c in level:
        if c in seen:
            continue
        g = [d for d in level if abs(level[d] - level[c]) <= 0.06 * max(level[d], level[c])]
        if len(g) > 1:
            groups.append(g)
            seen |= set(g)
    mapped_g = dict(mapped)
    group_f1 = {}
    for g in groups:
        truth = sum(gt_on[c][ho].astype(int) for c in g)
        pred = np.zeros_like(truth)
        for i, l in label.items():
            if l in g:
                pred = pred + states[i, ho].astype(int)
        tp = np.minimum(pred, truth).sum(); fp = np.clip(pred - truth, 0, None).sum(); fn = np.clip(truth - pred, 0, None).sum()
        f = float(2 * tp / max(2 * tp + fp + fn, 1))
        group_f1["+".join(g)] = f
        for c in g:
            mapped_g[c] = f
    return {"held_out": held, "full": full, "greedy_f1": best,
            "group_f1": group_f1,
            "mapped_mean_comp_grouped": float(np.mean([mapped_g[c] for c in comp_cols])),
            "greedy_mean_comp": float(np.mean([best[c] for c in comp_cols])),
            "greedy_mean_defrost": float(np.mean([best[c] for c in def_cols])) if def_cols else None,
            "mapped_f1": mapped,
            "mapped_mean_comp": float(np.mean([mapped[c] for c in comp_cols])),
            "mapped_mean_defrost": float(np.mean([mapped[c] for c in def_cols])) if def_cols else None,
            "n_duplicate_identities": n_dup,
            "n_stable": stable, "n_matches": len(held)}


def rated_power(states, apps, gt, cfg, split_idx, X=None):
    """
    Rated-power accuracy per compressor -- the quantity a demand-response
    assessment actually needs. Each true compressor is matched to the
    discovered appliance with the best on/off agreement on the TRAINING part
    (the same labelling the duplicate-aware F1 uses); that appliance's
    magnitude at the reference temperature is compared with the true
    on-power at the same temperature (a linear fit of the true on-power
    against ambient when a covariate is available, else its median).
    Returns {component: {"est", "true", "err_pct"}} with est None if no
    appliance carries the label.
    """
    cols = [c for c in cfg["ground_truth_cols"] if c in gt.columns and "defrost" not in c]
    thr = cfg["ground_truth_on_threshold_kw"]
    tr = slice(0, split_idx)
    x_ref = cfg.get("_x_ref")
    out = {}
    for c in cols:
        p = gt[c].to_numpy()
        on = p > thr
        if X is not None and x_ref is not None:
            b = np.polyfit(X[on], p[on], 1)
            true = float(np.polyval(b, x_ref))
        else:
            true = float(np.median(p[on]))
        best, best_f = None, 0.1
        for a, st in zip(apps, states):
            f = _f1(st[tr].astype(bool), on[tr])
            if f > best_f:
                best, best_f = a, f
        # an asymmetric appliance's own magnitude is its STOP step (its tail,
        # e.g. the evaporator fan, is still running at that moment)
        est = float(best.mu0[0] - best.mu_tail[0]) if best is not None else None
        if best is not None and getattr(best, "rated_kw", None) is not None:
            est = best.rated_kw
        out[c] = {"est": est, "true": true,
                  "err_pct": (abs(est - true) / true * 100) if est is not None else None,
                  "train_f1": best_f if best is not None else 0.0}
    return out


def instantaneous_step(Pi, t_start, t_after, pre_s=30, fit_s=60):
    """
    Step size at the moment of a switch. In a compressor rack the VFD lead
    compressor compensates a fixed stage's start (or stop) within tens of
    seconds, so the aggregate shows a step followed by a partial decay, and
    any level measured "after the step" understates the stage's power by
    15-20 %. Fit level(t) = L + A * exp(-t / tau) to the window after the
    switch and evaluate it at the switch (L + A); the level before is the
    median of the preceding window. Without compensation A ~ 0 and this
    equals the plain step.
    """
    from scipy.optimize import least_squares
    T = len(Pi)
    a0, a1 = max(0, t_start - pre_s - 2), t_start - 2
    b0, b1 = t_after + 1, min(T, t_after + 1 + fit_s)
    if a1 - a0 < 5 or b1 - b0 < 15:
        return None
    pre = float(np.median(Pi[a0:a1]))
    y = Pi[b0:b1]
    x = np.arange(1, len(y) + 1, dtype=float)
    tail = float(np.median(y[-10:]))
    head = float(np.median(y[:5]))
    try:
        r = least_squares(lambda p: p[0] + p[1] * np.exp(-x / p[2]) - y,
                          [tail, head - tail, 40.0], bounds=([-1e5, -1e5, 5.0], [1e5, 1e5, 300.0]),
                          loss="soft_l1", f_scale=2.0)
        return float(r.x[0] + r.x[1]) - pre
    except Exception:
        return None


def appliance_rated_power(tr, P, X, cfg, events):
    """Per discovered appliance: median instantaneous step over its clean
    (single-transition) switches, referred to the reference temperature
    with the appliance's own slope. For an appliance with a tail (fan that
    stops later) only its stops are used: the stop step is the compressor
    alone. Sets a.rated_kw; returns {appliance id: kW}."""
    Pi = pd.Series(P).interpolate(limit_direction="both").to_numpy()
    span = {e["t"]: e for e in events}
    x_ref = cfg.get("_x_ref")
    out = {}
    for a in tr.apps:
        vals = []
        for t, d, dec in tr.log:
            if dec not in (f"A{a.id}+", f"A{a.id}-"):
                continue
            sgn = 1 if dec.endswith("+") else -1
            if a.asym and sgn > 0:
                continue
            e = span.get(t)
            if e is None:
                continue
            v = instantaneous_step(Pi, t, e.get("te", t), cfg["rated_pre_s"], cfg["rated_fit_s"])
            if v is None:
                continue
            v = sgn * v
            if X is not None and x_ref is not None and np.any(a.beta):
                v -= a.beta[0] * (X[t] - x_ref)
            vals.append(v)
        a.rated_kw = float(np.median(vals)) if len(vals) >= 5 else None
        out[a.id] = a.rated_kw
    return out


# =========================================================================
# Results for the flexibility analysis (real-data output)
# =========================================================================
def _runs(row, value):
    """Lengths (s) of complete runs of `value` in a 0/1 row (runs touching
    either end of the series are incomplete and left out)."""
    d = np.diff(np.concatenate([[1 - value], (row == value).astype(np.int8) * 1, [1 - value]])) \
        if value == 1 else np.diff(np.concatenate([[0], (row == value).astype(np.int8), [0]]))
    starts, ends = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
    keep = (starts > 0) & (ends < len(row))
    return (ends - starts)[keep]


def _local_time(t0, idx, tz):
    return pd.to_datetime(t0 + np.asarray(idx), unit="s", utc=True).tz_convert(tz)


def start_dynamics(tr, events, P, cfg):
    """
    What happens to the level after each of an appliance's clean starts,
    counting only the gradual change BETWEEN events (other appliances'
    switches are left out). Per appliance: median fall of the level within
    10 min as a share of the start step, and the share of that fall that
    comes after the first 2 min.

    A fixed-speed compressor's level stays flat (fall ~0). A variable-speed
    compressor restarting after a cut-out pulls the room down at elevated
    speed and slows towards minimum speed over several minutes, so its level
    falls by ~40 % of the start step, mostly after 2 min. On a compressor
    rack a fixed compressor's start is also followed by a fall -- the VFD
    lead compressor compensating -- but that settles within 1-2 min, so the
    late share separates the two.
    """
    Pi = pd.Series(P).interpolate(limit_direction="both").to_numpy()
    T = len(Pi)
    ev = sorted(events, key=lambda e: e["t"])
    pos = {e["t"]: k for k, e in enumerate(ev)}
    W, E = cfg["vsd_decay_window_s"], cfg["vsd_early_s"]

    def drift_to(k, end):
        drift, cur = 0.0, ev[k]["post"][0]
        j = k + 1
        while j < len(ev) and ev[j]["t"] < end:
            drift += ev[j]["pre"][0] - cur
            cur = ev[j]["post"][0]
            j += 1
        return drift + float(np.median(Pi[max(0, end - 10):end + 10])) - cur

    out = {}
    starts = {}
    for t, d, dec in tr.log:
        m_ = re.match(r"A(\d+)\+u?$", dec)
        if m_ and d[0] > 0:
            starts.setdefault(int(m_.group(1)), []).append((t, d[0]))
    for aid, st in starts.items():
        full, early = [], []
        for t, step in st:
            k = pos.get(t)
            if k is None or t + W >= T:
                continue
            full.append(-drift_to(k, t + W) / step)
            early.append(-drift_to(k, t + E) / step)
        if len(full) >= 5:
            f, e = float(np.median(full)), float(np.median(early))
            out[aid] = (f, (f - e) / f if f > 1e-6 else 0.0)
    return out


def start_rise(tr, events, P, Q, cfg):
    """
    A screw compressor with a continuously modulating slide valve starts
    unloaded (25 % capacity, ~40 % of full-load power, Q/P near 1: an
    induction motor at minimum load) and then loads without steps. After a
    defrost or a warm period it reaches full load within a few minutes, so
    its level RISES after the start -- a fixed compressor's stays flat, a
    VFD's falls (start_dynamics()). Per appliance with >= 5 clean starts:
    the level change (between events only, other switches left out) from
    the start to mod_window_s later, in P and Q. Returns
    {id: {"n", "rise_p90_kW", "rise_max_kW", "rise_qp"}}.
    """
    Pi = pd.Series(P).interpolate(limit_direction="both").to_numpy()
    Qi = pd.Series(Q).interpolate(limit_direction="both").to_numpy()
    T = len(Pi)
    ev = sorted(events, key=lambda e: e["t"])
    pos = {e["t"]: k for k, e in enumerate(ev)}
    W = cfg["mod_window_s"]

    def drift_to(k, end, ch, X):
        drift, cur = 0.0, ev[k]["post"][ch]
        j = k + 1
        while j < len(ev) and ev[j]["t"] < end:
            drift += ev[j]["pre"][ch] - cur
            cur = ev[j]["post"][ch]
            j += 1
        return drift + float(np.median(X[max(0, end - 30):end + 30])) - cur

    starts = {}
    for t, d, dec in tr.log:
        m_ = re.match(r"A(\d+)\+u?$", dec)
        if m_ and d[0] > 0:
            starts.setdefault(int(m_.group(1)), []).append(t)
    out = {}
    for aid, ts in starts.items():
        rp, rq = [], []
        for t in ts:
            k = pos.get(t)
            if k is None or t + W + 30 >= T:
                continue
            rp.append(drift_to(k, t + W, 0, Pi))
            rq.append(drift_to(k, t + W, 1, Qi))
        if len(rp) >= 5:
            rp, rq = np.array(rp), np.array(rq)
            p90 = float(np.percentile(rp, 90))
            top = rp >= np.percentile(rp, 75)
            out[aid] = {"n": int(len(rp)), "rise_p90_kW": round(p90, 1), "rise_max_kW": round(float(rp.max()), 1),
                        "rise_qp": round(float(np.median(rq[top]) / max(np.median(rp[top]), 1e-6)), 2)}
    return out


def prune_units(apps, states, cfg):
    """A rack unit that was added online is kept only if all units are seen
    running together often enough (unit_top_min_share of the time, in
    unit_top_min_episodes episodes); otherwise the extra unit was a missed
    stop or a coincidence. Counts above the kept number are clipped."""
    imp = cfg["improvements"]
    for i, a in enumerate(apps):
        while a.units > 1:
            top = states[i] >= a.units
            episodes = int((np.diff(top.astype(np.int8)) == 1).sum() + top[0])
            if top.mean() >= imp["unit_top_min_share"] and episodes >= imp["unit_top_min_episodes"]:
                break
            a.units -= 1
            states[i] = np.minimum(states[i], a.units)
    return states


def unity_level(P, Q, events):
    """
    P - Q / r, with r the typical Q/P of the site's inductive switching
    steps (its compressors). The compressors (and the inductive part of the
    base load) nearly cancel, so what remains follows the unity-power-factor
    loads: chargers, heaters, PV. 31 s rolling median, NaN-safe.
    """
    ratios = [e["delta"][1] / e["delta"][0] for e in events
              if e["delta"][0] > 0 and e["delta"][1] > 0.3 * e["delta"][0]]
    r = float(np.median(ratios)) if len(ratios) >= 10 else 0.55
    u = pd.Series(P - Q / r).interpolate(limit_direction="both")
    return u.rolling(31, center=True, min_periods=1).median().to_numpy(), r


def _timer_test(times, durs, n_days, tz, t0, cfg):
    """Do these event times repeat on a clock or at a fixed interval, with a
    consistent duration? Returns (period_h or None, clock_times or [])."""
    times = np.asarray(times)
    if len(times) < 6 or n_days < 2:
        return None, []
    d = np.asarray(durs, float) / 60.0
    d = d[np.isfinite(d)]
    lo, hi = cfg["timer_duration_min"]
    real = d[d >= 1.0]                           # sub-minute runs: tracking artefacts
    if len(real) < 4:
        return None, []
    med = float(np.median(real))
    consistent = np.abs(d - med) <= cfg["timer_duration_cv"] * med
    if not (lo <= med <= hi) or consistent.mean() < 0.6:
        return None, []
    loc = _local_time(t0, times, tz)
    tod = (loc.hour * 60 + loc.minute).to_numpy().astype(float)
    day = loc.normalize().to_numpy()
    # circular clustering of time of day: cut at the largest gap
    o = np.argsort(tod)
    st = tod[o]
    gaps_ = np.diff(np.concatenate([st, [st[0] + 1440]]))
    cut = int(np.argmax(gaps_)) + 1
    order = np.concatenate([o[cut:], o[:cut]])
    clusters, cur, ref = [], [order[0]], tod[order[0]]
    for i in order[1:]:
        if (tod[i] - ref) % 1440 <= cfg["timer_cluster_min"]:
            cur.append(i)
        else:
            clusters.append(cur); cur, ref = [i], tod[i]
    clusters.append(cur)
    regular = [c for c in clusters if len(set(day[c])) >= cfg["timer_min_day_share"] * n_days]
    n_reg = sum(len(c) for c in regular)
    if regular and len(regular) <= 6 and n_reg >= cfg["timer_min_event_share"] * len(times):
        clock = sorted(f"{int(np.median(tod[c]) // 60):02d}:{int(np.median(tod[c]) % 60):02d}" for c in regular)
        return 24.0 / len(regular), clock
    iv = np.diff(np.sort(times)) / 3600.0
    iv = iv[iv >= 1.0]
    if len(iv) >= 4:
        m = np.median(iv)
        ok = np.abs(iv - m) <= cfg["timer_interval_tol"] * m
        if cfg["timer_interval_h"][0] <= m <= cfg["timer_interval_h"][1] and ok.mean() >= 0.6:
            return float(m), []
    return None, []


def classify_timer(apps, states, table, data, cfg):
    """
    Defrost runs on a timer (or a near-fixed interval): every 6, 8 or 12 h,
    at the same clock times, for a similar time. Three electrical
    signatures, all found the same way -- events that repeat on a clock or
    a fixed interval with a consistent duration:
      - starts of a unity-PF appliance        -> electric defrost heater
      - starts of an inductive appliance      -> compressor in hot-gas mode?
      - STOPS of an appliance that is mostly on (>= 70 % of the time)
                                              -> evaporator fans stopped for
                                                 defrost (hot-gas / off-cycle)
    No heater step is needed, so hot-gas and off-cycle defrost can be
    recognised too. Returns {appliance id: {"role", "period_h", "clock"}}.
    """
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    obs = ~np.isnan(data["P"])
    n_days = obs.sum() / 86400.0
    out = {}
    for a, st in zip(apps, states):
        r = rows.get(f"A{a.id}")
        if r is None or r.get("variable_speed_suspected"):
            continue
        on = st > 0
        d = np.diff(np.concatenate([[0], on.astype(np.int8), [0]]))
        ups, downs = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        duty = on[obs].mean() if obs.any() else 0
        pf = r.get("power_factor")
        if duty >= 0.7:
            # mostly on: look at its stops and how long it stays off
            offs = [(dn, (ups[ups > dn][0] - dn) if (ups > dn).any() else np.nan) for dn in downs if dn < len(on)]
            period, clock = _timer_test([x for x, _ in offs], [y for _, y in offs], n_days, tz, data["t0"], cfg)
            role = ("stops on a defrost timer: evaporator fans (hot-gas / off-cycle defrost?), "
                    "or a compressor that only stops for defrost")
        else:
            runs = [(u_, dn - u_) for u_, dn in zip(ups, downs)]
            period, clock = _timer_test([x for x, _ in runs], [y for _, y in runs], n_days, tz, data["t0"], cfg)
            role = ("defrost heater (timer)" if pf is not None and pf >= cfg["sched_min_pf"]
                    else "periodic inductive load at defrost times: compressor in hot-gas mode, "
                         "or a compressor stop + heater start seen as one step")
        if period is not None:
            out[a.id] = {"role": role, "period_h": round(period, 2), "clock": clock,
                         "defrost_load": duty < 0.7}       # the heater / hot-gas mode itself
    return out


def detect_lagging_parts(tr, apps, events, cfg):
    """
    A compressor whose evaporator fan starts with it but stops a minute or
    two after it shows a START step of compressor + fan and a STOP step of
    the compressor alone. The online asymmetry check only sees this when one
    appliance is matched to both its starts and its stops; when the tracker
    instead learns the stop as a second appliance or as "start minus a fan",
    the rating came out as compressor + fan (10-15 % high).

    Here, after tracking and attribution-free: for every start of appliance A
    (a single-appliance '+' decision), the first later stop event of similar
    size and power factor is taken as A's stop. If the stop is consistently
    smaller than the start, and a step of the difference (the fan) follows the
    stop within lag_followup_s in enough cycles, A gets a lagging part = median
    paired difference (P and Q; pairing cancels temperature drift) and its
    rating becomes start - lagging part. Sets a.mu_tail / a.asym / a.lag_info
    on appliances that pass; returns {appliance id: info}.
    """
    imp = cfg["improvements"]
    E = np.array([e["t"] for e in events])
    D = np.array([e["delta"] for e in events]) if events else np.zeros((0, 2))
    by_t = {e["t"]: e["delta"] for e in events}
    lo_f, hi_f = cfg["lag_followup_s"]
    out = {}
    for a in apps:
        if a.asym or a.units > 1 or a.mu0[0] < 10 or a.mu0[1] < 0.3 * a.mu0[0]:
            continue
        S, qp = a.mu0[0], a.mu0[1] / a.mu0[0]
        ups = [t for t, _, dec in tr.log if dec == f"A{a.id}+"]
        pairs, follow = [], []
        for t in ups:
            j = np.flatnonzero((E > t) & (E < t + 4 * 3600) & (-D[:, 0] > 0.75 * S) & (-D[:, 0] < 1.05 * S)
                               & (np.abs(D[:, 1] / np.where(D[:, 0] == 0, 1, D[:, 0]) - qp) < 0.2))
            if not len(j):
                continue
            k = j[0]
            start, stop = np.asarray(by_t[t], float), -D[k]
            diff = start - stop
            pairs.append(diff)
            f = np.flatnonzero((E > E[k] + lo_f) & (E < E[k] + hi_f) & (D[:, 0] < -1.5))
            follow.append(any(abs(-D[i, 0] - diff[0]) < max(1.5, 0.35 * abs(diff[0])) for i in f))
        if len(pairs) < cfg["lag_min_pairs"]:
            continue
        pairs = np.array(pairs)
        med = np.median(pairs, axis=0)
        mad = 1.4826 * np.median(np.abs(pairs[:, 0] - med[0])) + 1e-6
        se = 1.253 * mad / math.sqrt(len(pairs))
        share = float(np.mean(follow))
        if (med[0] >= max(cfg["lag_min_kw"], cfg["lag_min_share"] * S) and med[0] > 3 * se
                and share >= cfg["lag_min_followup"]
                and -0.15 * med[0] <= med[1] <= imp["max_qp_ratio"] * med[0]):
            a.mu_tail, a.asym = med.copy(), True
            if getattr(a, "rated_kw", None) is not None:       # instantaneous (rack) rating: also start-based
                a.rated_kw = a.rated_kw - med[0]
            a.lag_info = {"tail_kW": round(float(med[0]), 2), "pairs": len(pairs), "followup_share": round(share, 2)}
            out[a.id] = a.lag_info
    return out


def _second_start_share(events, group, cfg, corrected=False):
    """Among raw events of the start size (step incl. any lagging part) or
    stop size (without it) of the appliances in `group`: how many starts,
    and the share of them whose previous such event was also a start (a
    start of that size while one of that size already runs). With
    `corrected`, event steps are first moved to the reference ambient with
    the group's mean temperature slope (sizes drift ~1 %/degC)."""
    starts = [x.mu0[0] for x in group]
    stops = [x.mu0[0] - (x.mu_tail[0] if x.asym else 0.0) for x in group]
    beta = float(np.mean([x.beta[0] for x in group])) if corrected else 0.0
    x_ref = cfg.get("_x_ref", 0.0)
    tol = lambda v: max(1.5, 0.04 * v)
    last, n_up, n_second = None, 0, 0
    for e in events:
        dp = e["delta"][0]
        if beta and e.get("x") is not None:
            dp = dp - np.sign(dp) * beta * (e["x"] - x_ref)
        if any(abs(dp - v) <= tol(v) for v in starts):
            n_up += 1
            n_second += last == "up"            # started again with no stop of that size between
            last = "up"
        elif any(abs(-dp - v) <= tol(v) for v in stops):
            last = "down"
    return n_up, (n_second / n_up if n_up else 0.0)


def _two_gaussian_separation(r, init_gap):
    """1-D two-component Gaussian mixture by EM; returns (separation in
    pooled standard deviations, smaller component weight)."""
    r = np.asarray(r, float)
    if len(r) < 20:
        return None, None
    m = np.array([np.median(r) - init_gap / 2, np.median(r) + init_gap / 2])
    v = np.full(2, max(np.var(r) / 4, 1e-4))
    w = np.array([0.5, 0.5])
    for _ in range(200):
        ll = -0.5 * (r[:, None] - m) ** 2 / v - 0.5 * np.log(v) + np.log(w)
        ll -= ll.max(axis=1, keepdims=True)
        g = np.exp(ll); g /= g.sum(axis=1, keepdims=True)
        nk = g.sum(axis=0) + 1e-9
        w = nk / len(r)
        m_new = (g * r[:, None]).sum(axis=0) / nk
        v = np.maximum((g * (r[:, None] - m_new) ** 2).sum(axis=0) / nk, 1e-4)
        if np.allclose(m_new, m, atol=1e-6):
            m = m_new
            break
        m = m_new
    return float(abs(m[1] - m[0]) / np.sqrt(v.mean())), float(w.min())


def twin_compressors(tr, apps, table, cfg, events, exclude=(), rack=None):
    """
    Two real compressors of (almost) the same size. Event by event they are
    told apart only by their step size, so when the size difference is not
    much larger than the spread of the steps (noise, temperature, slow
    drift), whole cycles get swapped between the two models or one model
    takes both machines. Sizes stay right (both near the common size); which
    machine ran when does not.
      pairs   two appliances whose start steps (incl. a lagging fan) or stop
              steps (without) are within twin_rel_kw, Q/P within
              twin_rel_qp, and that are not one compressor learned twice
              (duplicate_identities()). separation = distance between the two
              means of a two-Gaussian fit to the temperature-corrected sizes
              of both appliances' starts (or stops), in pooled standard
              deviations -- from the data, not from the tracker's split of it,
              which always looks clean; the closer of the two edges counts.
              Below twin_min_separation (or a component under 10 % weight):
              not separable.
    When the tracker has instead put both machines into one model, the
    structure search's "merge identical" move usually makes it one appliance
    with 2 units (sizes right, per-unit timing not given). A test for one
    model holding two machines from the raw event sequence (share of its
    starts that come while one of its size already runs) was tried and
    dropped: single compressors scored 0.16-0.86 on the rack and
    "realistic" datasets, as high as real pairs.
    Returns {(id_a, id_b): info}.
    """
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    x_ref = cfg.get("_x_ref", 0.0)
    cand = []
    for a in apps:
        r = rows.get(f"A{a.id}", {})
        if a.id in exclude or r.get("variable_speed_suspected") or a.units > 1 \
                or a.mu0[0] < 10 or a.mu0[1] < 0.3 * a.mu0[0]:
            continue
        cand.append(a)
    single = {}                               # appliance id -> [(|step P| at reference ambient)]
    for t, _, dec in tr.log:
        m_ = re.fullmatch(r"A(\d+)([+\-])", dec)
        if m_:
            single.setdefault(int(m_.group(1)), []).append((int(t), m_.group(2)))
    ev_at = {e["t"]: e for e in events}
    by_id = {a.id: a for a in cand}

    def sizes(a, beta, sign):
        """|step P| of a's single starts (sign '+') or stops ('-'), at the
        reference ambient. A start includes any lagging fan, a stop not."""
        out = []
        for t, sg in single.get(a.id, []):
            e = ev_at.get(t)
            if e is None or sg != sign:
                continue
            y = abs(e["delta"][0])
            if e.get("x") is not None:
                y -= beta * (e["x"] - x_ref)
            out.append(y)
        return out

    rel = cfg["twin_rel_kw"]
    close = lambda u, v: abs(u - v) <= rel * max(u, v)
    # with rack compensation the measured steps are shrunk by a varying amount
    # (34 and 40 kW for two 42/44 kW twins), so sizes are compared at the
    # instant of switching (rated_kW) with a wider window
    on_rack = bool(rack and rack.get("detected"))
    rated = {}
    for a in cand:
        v = rows.get(f"A{a.id}", {}).get("rated_kW")
        rated[a.id] = float(v) if v is not None and not (isinstance(v, float) and np.isnan(v)) else None
    rel_r = cfg.get("twin_rel_kw_rack", 0.11)
    pairs = {}
    for i, a in enumerate(cand):
        for b in cand[i + 1:]:
            # compared as starts (incl. a lagging fan) and as stops (without):
            # a 42 kW compressor with a 4 kW fan starts like a 46 kW one
            start = (a.mu0[0], b.mu0[0])
            stop = tuple(x.mu0[0] - (x.mu_tail[0] if x.asym else 0.0) for x in (a, b))
            core_q = [x.mu0[1] - (x.mu_tail[1] if x.asym else 0.0) for x in (a, b)]
            ra, rb = rated[a.id], rated[b.id]
            by_rated = on_rack and ra and rb and abs(ra - rb) <= rel_r * max(ra, rb)
            if not (close(*start) or close(*stop) or by_rated) \
                    or abs(core_q[0] / stop[0] - core_q[1] / stop[1]) > cfg["twin_rel_qp"]:
                continue
            if by_rated and not (close(*start) or close(*stop)):
                # the shrunk steps are too far apart for the size test; on a
                # compensated rack the step sizes do not identify the machine
                pairs[(a.id, b.id)] = {"sizes_kW": [round(ra, 1), round(rb, 1)],
                                       "start_sizes_kW": [round(start[0], 1), round(start[1], 1)],
                                       "separation_sd": None, "closest_on": "rated size (rack-compensated steps)",
                                       "minor_weight": None, "concurrent_start_share": None,
                                       "separable": False, "basis": "rated"}
                continue
            beta = float(np.mean([a.beta[0], b.beta[0]]))
            seps = []
            for sign, (ma, mb) in (("+", start), ("-", stop)):
                if not close(ma, mb):
                    continue               # told apart on this edge by size alone
                sep_, w_ = _two_gaussian_separation(sizes(a, beta, sign) + sizes(b, beta, sign), abs(ma - mb))
                if sep_ is not None:
                    seps.append((sep_ if w_ >= 0.1 else 0.0, sign, w_))
            n_up, share = _second_start_share(events, (a, b), cfg, corrected=True)
            sep, edge, wmin = min(seps) if seps else (None, None, None)
            ok = sep is not None and sep >= cfg["twin_min_separation"]
            pairs[(a.id, b.id)] = {"sizes_kW": [round(stop[0], 1), round(stop[1], 1)],
                                   "start_sizes_kW": [round(start[0], 1), round(start[1], 1)],
                                   "separation_sd": None if sep is None else round(sep, 2),
                                   "closest_on": {"+": "starts", "-": "stops"}.get(edge),
                                   "minor_weight": None if wmin is None else round(wmin, 2),
                                   "concurrent_start_share": round(share, 2), "separable": bool(ok)}
    return pairs


def duplicate_identities(apps, states, table, cfg, exclude=(), events=None):
    """
    The same compressor learned as two appliances (one often takes the
    starts, the other the stops, or one gets stuck on): steps within
    dup_rel_kw / dup_rel_kvar, and in the raw EVENTS a start of that size
    almost never happens while one of that size is already running. The
    tracked on/off states are not used for this -- a stuck copy makes them
    overlap. Test: among events of either appliance's start size (compressor
    + any lagging part) and stop size (compressor alone), the share of starts
    whose previous such event was also a start. One compressor: only after a
    stop hidden in a combined step (measured 0.01-0.04). Two real compressors
    of that size: about the other one's duty cycle (measured 0.25-0.39 for
    twins). A running count was tried first and drifts up after every hidden
    stop. Returns
    {duplicate id: kept id}; the one with fewer switch decisions is the duplicate.
    """
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    cand = []
    for i, a in enumerate(apps):
        r = rows.get(f"A{a.id}", {})
        rp, rq = r.get("rated_kW"), r.get("rated_kvar")
        if a.id in exclude or r.get("variable_speed_suspected") or rp is None or rq is None \
                or (isinstance(rp, float) and np.isnan(rp)) or a.units > 1 or rq < 0.3 * rp or rp < 10:
            continue
        cand.append((i, a, float(rp), float(rq), r.get("n_switch_decisions", 0) or 0))
    out = {}
    for x in range(len(cand)):
        for y in range(x + 1, len(cand)):
            i, a, p1, q1, n1 = cand[x]
            j, b, p2, q2, n2 = cand[y]
            if a.id in out or b.id in out:
                continue
            if abs(p1 - p2) > cfg["dup_rel_kw"] * max(p1, p2) or abs(q1 - q2) > cfg["dup_rel_kvar"] * max(q1, q2):
                continue
            if not events:
                continue
            n_up, share = _second_start_share(events, (a, b), cfg)
            if n_up < 10 or share > cfg["dup_max_second_start"]:
                continue
            keep, dup = (a, b) if n1 >= n2 else (b, a)
            out[dup.id] = keep.id
    return out


def capacity_stages(apps, log, table, cfg, exclude=()):
    """
    Capacity steps of one compressor (slide-valve or unloader steps of a
    screw / reciprocating machine): the compressor starts unloaded, then
    loads step by step, and unloads before it stops. Electrically: the
    start step A is followed within minutes by one or more load steps B.
    The test uses the event SEQUENCE, not the tracked states (a state that
    is wrong for a while does not break it):
      share of A's starts followed by a start of B within
      stage_window_s (before A stops)  >=  stage_min_follow
      and  >= stage_min_lift x the share expected by chance from B's own
      start rate.
    Identical load steps (within unit_merge_rel) are one group; how many
    steps the group has is the longest run of its starts after one start
    of A without a stop in between (the screw loads 25->50->75->100 %), taking
    the most steps reached in >= stage_min_period_share of A's runs (a
    stray extra start does not add a step).
    Two physical checks: a load step is no bigger than the start step
    (stage_max_rel_size: a screw starts at 25 % capacity, ~40 % power, and
    adds ~20 % per step), and it is mostly real power (stage_max_rel_qp):
    an induction motor's magnetising reactive power is already there at
    minimum load, so its power factor rises as it loads -- the start step
    has Q/P ~1, the load steps ~0.3-0.5. A lag compressor that a rack
    starts after its lead brings its own magnetising Q and fails this.
    Full load = A + steps x step.
    Returns ({stage id: parent id}, {parent id: [(step_kW, n_steps, ids)]}).
    """
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    ev = {}
    for t, _, dec in log:
        for m_ in re.finditer(r"A(\d+)([+\-])", dec):
            ev.setdefault(int(m_.group(1)), []).append((int(t), 1 if m_.group(2) == "+" else -1))
    cand = [a for a in apps if a.id not in exclude and a.mu0[0] > 0
            and not rows.get(f"A{a.id}", {}).get("variable_speed_suspected")]
    T_span = max((t for v in ev.values() for t, _ in v), default=1) - min((t for v in ev.values() for t, _ in v), default=0)
    D = cfg["stage_window_s"]
    parent = {}
    for b in cand:
        b_up = np.array([t for t, sg in ev.get(b.id, []) if sg > 0])
        if len(b_up) < 5:
            continue
        chance = 1 - math.exp(-len(b_up) / max(T_span, 1) * D)
        best = None
        for a in cand:
            if a is b or b.mu0[0] > cfg["stage_max_rel_size"] * a.mu0[0]:
                continue                 # a load step adds less than the unloaded start
            if a.mu0[1] <= 0 or b.mu0[1] / b.mu0[0] > cfg["stage_max_rel_qp"] * a.mu0[1] / a.mu0[0]:
                continue                 # ... and mostly real power: the magnetising Q came with the start
            a_ev = ev.get(a.id, [])
            a_up = [t for t, sg in a_ev if sg > 0]
            a_dn = np.array([t for t, sg in a_ev if sg < 0])
            if len(a_up) < 5:
                continue
            hit = 0
            for t in a_up:
                stop = a_dn[a_dn > t]
                lim = min(t + D, stop[0] if len(stop) else t + D)
                hit += bool(((b_up > t) & (b_up <= lim)).any())
            share = hit / len(a_up)
            if share >= cfg["stage_min_follow"] and share >= cfg["stage_min_lift"] * chance:
                if best is None or share > best[0]:
                    best = (share, a)
        if best is not None:
            parent[b.id] = best[1].id
    parent = {k: v for k, v in parent.items() if parent.get(v) != k and v not in parent}
    groups = {}
    byid = {a.id: a for a in apps}
    rel = cfg["improvements"].get("unit_merge_rel", 0.04)
    # identical copies of an accepted load step are the same step (the
    # tracker spreads one screw's several equal steps over copies)
    for sid, pid in list(parent.items()):
        for c_ in cand:
            if c_.id not in parent and c_.id != pid and \
                    np.all(np.abs(c_.mu0 - byid[sid].mu0) <= rel * np.abs(byid[sid].mu0)):
                parent[c_.id] = pid
    for sid, pid in parent.items():
        s_ = byid[sid]
        for g in groups.setdefault(pid, []):
            if np.all(np.abs(byid[g[0]].mu0 - s_.mu0) <= rel * np.abs(byid[g[0]].mu0)):
                g.append(sid)
                break
        else:
            groups[pid].append([sid])
    out = {}
    for pid, gs in groups.items():
        a_ev = sorted(ev.get(pid, []))
        for g in gs:
            stream = sorted([e for i in g for e in ev.get(i, [])] + [(t, 0) for t, sg in a_ev if sg < 0]
                            + [(t, 2) for t, sg in a_ev if sg > 0])
            run = mx = 0
            per = []
            for _, sg in stream:
                if sg == 2 or sg == 0:              # parent starts / stops: new run
                    per.append(mx)
                    run = mx = 0
                elif sg > 0:
                    run += 1
                    mx = max(mx, run)
                else:
                    run = max(run - 1, 0)
            per.append(mx)
            per = np.asarray([x for x in per if x > 0])
            best_run = max([v for v in range(1, int(per.max()) + 1)
                            if (per >= v).mean() >= cfg["stage_min_period_share"]], default=1) if len(per) else 1
            n_steps = max(best_run, sum(byid[i].units for i in g) if len(g) == 1 else len(g))
            n_steps = max(n_steps, 1)
            out.setdefault(pid, []).append((float(np.mean([byid[i].mu0[0] for i in g])), int(n_steps), list(g)))
    return parent, out


def capacitor_bank(qsteps, data, cfg):
    """Summarise reactive-only steps as a capacitor bank: stage size (median
    |dQ|), stages regularly switched (within any hour), switchings per day.
    Stages that are always in (or never) cannot be seen from switching."""
    if len(qsteps) < 8:
        return None
    dq = np.array([q[2] for q in qsteps])
    stage = float(np.median(np.abs(dq)))
    k = np.round(-dq / stage)
    fit = np.mean(np.abs(-dq / stage - k) <= 0.25)
    # stages regularly in use: the range of the running stage count within
    # one hour (95th percentile over all hours). Over longer spans a missed
    # switching makes the running count drift; within an hour it hardly can.
    t = np.array([q[0] for q in qsteps])
    run = np.cumsum(k)
    span = []
    for i in range(len(t)):
        m = (t >= t[i]) & (t < t[i] + 3600)
        span.append(run[m].max() - min(run[m].min(), run[i] - k[i]))
    best = int(np.percentile(span, 95))
    days = max((~np.isnan(data["P"])).sum() / 86400.0, 1e-9)
    return {"stage_kvar": round(stage, 2), "stages_seen": int(best),
            "switchings_per_day": round(len(qsteps) / days, 1), "share_fitting_stage": round(float(fit), 3),
            "dP_per_stage_kW": round(float(np.median([abs(q[1]) for q in qsteps])), 3)}


def _unity_steps(x, w=60, gap=5, thr=3.0, sep=120):
    """Steps in a 1 s level: mean of [t+gap, t+gap+w) minus mean of
    [t-gap-w, t-gap); local maxima of |difference| >= thr, >= sep apart."""
    T = len(x)
    cs = np.concatenate([[0], np.cumsum(x)])
    t = np.arange(gap + w, T - gap - w)
    d = np.zeros(T)
    d[t] = (cs[t + gap + w] - cs[t + gap]) / w - (cs[t - gap] - cs[t - gap - w]) / w
    out, taken = [], np.zeros(T, bool)
    for i in np.argsort(-np.abs(d)):
        if abs(d[i]) < thr:
            break
        if taken[max(0, i - sep): i + sep].any():
            continue
        taken[i] = True
        out.append((int(i), float(d[i])))
    return sorted(out)


def _qp_drift(tr, apps, events, T, window_s=7200):
    """Site-wide drift of the compressors' Q/P over time: for every event
    explained by one inductive appliance alone, (dQ/dP) / (its Q/P), then a
    rolling median over window_s. 1.0 = no drift. Q/P moves with load,
    voltage and temperature (+-8 % over a day in the pf_drift tests); a
    compressor subtracted with a fixed Q leaves +-5 kW steps in the unity
    level otherwise."""
    if tr is None:
        return np.ones(T)
    byid = {a.id: a for a in apps if a.mu0[0] >= 10 and a.mu0[1] >= 0.3 * a.mu0[0]}
    ev_at = {e["t"]: e for e in events}
    pts = []
    for t, _, dec in tr.log:
        m_ = re.fullmatch(r"A(\d+)[+\-]", dec)
        if not m_ or int(m_.group(1)) not in byid or t not in ev_at:
            continue
        a = byid[int(m_.group(1))]
        dp, dq = ev_at[t]["delta"]
        if abs(dp) < 5:
            continue
        pts.append((int(t), (dq / dp) / (a.mu0[1] / a.mu0[0])))
    if len(pts) < 20:
        return np.ones(T)
    ts_, ks = np.array(pts).T
    ks = np.clip(ks, 0.7, 1.3)
    grid = np.arange(0, T, 600)
    k_grid = np.array([np.median(ks[np.abs(ts_ - g) <= window_s / 2]) if (np.abs(ts_ - g) <= window_s / 2).sum() >= 3
                       else np.nan for g in grid])
    k_grid = pd.Series(k_grid).interpolate(limit_direction="both").fillna(1.0).to_numpy()
    return np.interp(np.arange(T), grid, k_grid)


def rebuild_defrost(names, states, apps, data, events, cfg, busy=None, tr=None, qsteps=()):
    """
    Defrost heaters, rebuilt from the UNITY LEVEL instead of the event
    tracker. A defrost usually starts in the same second as its compressor
    is forced off (the meter sees one -33 kW step, the heater's +9 kW is
    inside it), several heaters often start together, and their ends are
    small. The tracker therefore learns heaters badly (composites, nothing
    at all) and its defrost timing was ~0.5 F1 at best.

    Unity level: meter minus every tracked compressor (each at its own P and
    Q), then P - Q/r with r the site's compressor Q/P -- what is left of any
    compressor cancels, a unity-PF heater keeps ~75-100 % of its power. In it:
      ends    = down-steps; grouped by size (within 15 %): one group = one heater
      starts  = for each end, the latest up-step 3-90 min before it, of at
                least 0.8 x the heater, after which the level stays raised by
                >= 0.6 x the heater until the end (a shared start of several
                heaters serves each of them)
    A group is a defrost heater only if it behaves like one: >= 4 runs, at
    most defrost_max_per_day runs a day, durations consistent (CV <= 0.35).
    Groups whose runs repeat another group's (overlap > 90 % both ways) are
    dropped (Z3's runs inside Z1's with the same start are NOT a copy).
    Tracker appliances with unity PF whose on-time lies mostly (>= 50 %)
    inside the rebuilt runs, or whose switches mostly (>= 50 %) fall within
    60 s of a rebuilt heater's switches, are replaced by the rebuilt heaters.
    Returns (names, states, apps, info).
    """
    P, Q = data["P"], data["Q"]
    T = len(P)
    X, x_ref = data.get("X"), cfg.get("_x_ref")
    P2, Q2 = P.copy(), Q.copy()
    kq = _qp_drift(tr, apps, events, T)
    for a, st in zip(apps, states):
        if a.mu0[0] >= 10 and a.mu0[1] >= 0.3 * a.mu0[0]:
            mp = a.mu0[0] + (a.beta[0] * (X - x_ref) if X is not None and x_ref is not None else 0.0)
            mq = a.mu0[1] + (a.beta[1] * (X - x_ref) if X is not None and x_ref is not None else 0.0)
            P2 = P2 - st * mp
            Q2 = Q2 - st * mq * kq
    uu, r = unity_level(P2, Q2, events)
    x = pd.Series(uu).interpolate(limit_direction="both").to_numpy()
    st_ = _unity_steps(x, thr=cfg["defrost_step_kw"])
    if busy is not None and busy.any():
        st_ = [(t, v) for t, v in st_ if not busy[t]]
    # a capacitor stage switching (-15 kvar) is a +26 kW step of P - Q/r
    q_t = np.asarray([q[0] for q in qsteps], int)
    if len(q_t):
        st_ = [(t, v) for t, v in st_ if np.abs(q_t - t).min() > 90]
    ups = [(t, v) for t, v in st_ if v > 0]
    downs = [(t, -v) for t, v in st_ if v < 0]
    lo, hi = cfg["defrost_dur_min"]
    days = max(T / 86400.0, 1e-9)
    # 1) every down-step paired with its start (sized by the step itself)
    runs = []
    for te, v in downs:
        for ts, vs in sorted([(ts, vs) for ts, vs in ups if te - hi * 60 <= ts <= te - lo * 60 and vs >= 0.8 * v],
                             reverse=True):
            pre = np.median(x[max(0, ts - 120): max(ts - 10, 1)])
            if np.percentile(x[ts + 30: max(te - 30, ts + 31)], 10) >= pre + 0.6 * v:
                runs.append((ts, te, v, (te - ts) / 60.0))
                break
    # 2) runs grouped by size AND duration (heaters of similar size differ in
    #    run length: 9 kW / 25 min, 11 kW / 20 min, 7 kW / 18 min); average
    #    linkage on (log size / 0.08, log duration / 0.3), merge while <= 1.5
    feats = np.array([[np.log(v) / 0.08, np.log(dmin) / 0.3] for _, _, v, dmin in runs]) if runs else np.zeros((0, 2))
    groups = [[k] for k in range(len(runs))]
    def link(g1, g2):
        return float(np.mean([np.linalg.norm(feats[a] - feats[b]) for a in g1 for b in g2]))
    while len(groups) > 1:
        best, pair = None, None
        cen = [feats[g].mean(axis=0) for g in groups]
        for a in range(len(groups)):
            for b in range(a + 1, len(groups)):
                dd = np.linalg.norm(cen[a] - cen[b])
                if dd <= 3.0:                     # cheap pre-filter on centroids
                    l_ = link(groups[a], groups[b])
                    if best is None or l_ < best:
                        best, pair = l_, (a, b)
        if pair is None or best > 1.5:
            break
        a, b = pair
        groups[a] = groups[a] + groups[b]
        del groups[b]
    cands = []
    for g in groups:
        if len(g) < cfg["defrost_min_runs"]:
            continue
        if np.median([runs[k][2] for k in g]) < cfg["defrost_min_step"]:
            continue                       # smaller than any defrost heater: leftovers of compressors
        on = np.zeros(T, bool)
        for k in g:
            on[runs[k][0]:runs[k][1]] = True
        h = float(np.median([runs[k][2] for k in g]))
        d_ = np.diff(np.concatenate([[0], on.astype(np.int8), [0]]))
        durs = (np.flatnonzero(d_ == -1) - np.flatnonzero(d_ == 1)) / 60.0
        cv = float(np.std(durs) / np.mean(durs)) if len(durs) > 1 else 9.0
        ok = len(durs) >= cfg["defrost_min_runs"] and cfg["defrost_min_per_day"] <= len(durs) / days \
            <= cfg["defrost_max_per_day"] and cv <= cfg["defrost_max_dur_cv"] \
            and np.median(durs) <= cfg["defrost_max_median_min"]
        if ok:
            cands.append((h, on, len(durs), float(np.median(durs)), cv))
    # a site has about one heater per refrigerated room: no more than its
    # compressors + 1; the best supported (most runs) are kept
    n_comp = sum(1 for a in apps if a.mu0[0] >= 10 and a.mu0[1] >= 0.3 * a.mu0[0])
    cands = sorted(cands, key=lambda c: -c[2])[:max(1, n_comp + 1)]
    keep = []
    for c in sorted(cands, key=lambda c: -c[1].sum()):
        if any((c[1] & k[1]).sum() > 0.9 * c[1].sum() and (c[1] & k[1]).sum() > 0.9 * k[1].sum() for k in keep):
            continue
        keep.append(c)
    info = {"r": round(float(r), 3), "n_steps": len(st_), "heaters": []}
    if not keep:
        return names, states, apps, info
    union = np.zeros(T, bool)
    for c in keep:
        union |= c[1]
    edges = np.flatnonzero(np.diff(union.astype(np.int8)) != 0) + 1
    # replace tracker pieces of the heaters: unity-PF appliances living inside
    # the runs, or switching mostly at the heaters' switch times
    drop = []
    for i, (a, st) in enumerate(zip(apps, states)):
        on_a = st > 0
        if not (a.mu0[0] > 0 and abs(a.mu0[1]) < 0.3 * a.mu0[0] and on_a.sum() > 0):
            continue
        sw = np.flatnonzero(np.diff(on_a.astype(np.int8)) != 0) + 1
        near = (np.mean([np.abs(edges - t_).min() <= 60 for t_ in sw]) if len(sw) and len(edges) else 0.0)
        if (on_a & union).sum() >= 0.5 * on_a.sum() or near >= 0.5:
            drop.append(i)
    ev_t = np.array([e["t"] for e in events]) if events else np.zeros(0)
    ev_d = np.array([e["delta"] for e in events]) if events else np.zeros((0, 2))
    new_apps, new_states = [], []
    next_id = max([a.id for a in apps], default=0) + 100
    for k, (h, on, n, dmed, cv) in enumerate(keep):
        d_ = np.diff(np.concatenate([[0], on.astype(np.int8), [0]]))
        ends = np.flatnonzero(d_ == -1)
        # its own kW and kvar from clean unity-PF events at its ends
        pq = []
        for te in ends:
            j = np.flatnonzero((np.abs(ev_t - te) <= 30) & (ev_d[:, 0] < 0) & (np.abs(ev_d[:, 1]) < 0.3 * np.abs(ev_d[:, 0]))
                               & (-ev_d[:, 0] >= 0.7 * h) & (-ev_d[:, 0] <= 1.6 * h)) if len(ev_t) else []
            if len(j):
                pq.append(-ev_d[j[0]])
        p_kw, q_kvar = (np.median(pq, axis=0) if pq else (h, 0.0))
        a = Appliance(next_id + k, [float(p_kw), float(q_kvar)], np.diag([1.0, 1.0]), cfg, source="defrost-rebuild")
        a.n = a.n_matched = int(n)
        a.on_durations = list((ends - np.flatnonzero(d_ == 1)).astype(float))
        new_apps.append(a)
        new_states.append(on.astype(np.int8))
        info["heaters"].append({"appliance": f"A{a.id}", "kW": round(float(p_kw), 1), "kvar": round(float(q_kvar), 1),
                                "runs": int(n), "median_min": round(dmed, 1), "duration_cv": round(cv, 2)})
    info["replaced"] = [f"A{apps[i].id}" for i in drop]
    keep_i = [i for i in range(len(apps)) if i not in drop]
    apps = [apps[i] for i in keep_i] + new_apps
    names = [names[i] for i in keep_i] + [f"A{a.id}({a.mu0[0]:.1f},{a.mu0[1]:.1f})" for a in new_apps]
    states = np.vstack([states[keep_i]] + [np.asarray(new_states)]) if keep_i else np.asarray(new_states)
    return names, states, apps, info


def hidden_units(apps, states, table, data, cfg, exclude=(), busy=None):
    """
    A compressor that never stops is never seen switching: it is part of
    the base level, and a rack whose first unit always runs is reported
    one unit short (the unit count is a lower bound). The base level cannot
    say WHICH loads it holds, but it does bound how many more units of a
    learned size could hide in it, because a unit brings its reactive power
    too: k units of (P_u, Q_u) need k*P_u AND k*Q_u in the always-on level.

    Base level = meter minus every tracked appliance (at its temperature-
    dependent size), as 15-min medians outside busy windows; its floor is
    the hidden_floor_pct percentile of those, in P and in Q separately.
    Per compressor appliance: possible hidden units = how many of its
    units fit in both floors (>= 1 - hidden_tol of a unit). 0 means the
    count found is complete (no unit of that size can be always on); k > 0
    means up to k more may run continuously -- the count is then a range.
    Returns ({appliance id: k}, {"floor_kW", "floor_kvar"}).
    """
    P, Q = data["P"], data["Q"]
    T = len(P)
    X, x_ref = data.get("X"), cfg.get("_x_ref")
    obs = ~np.isnan(P)
    # an inductive appliance that (almost) never stops IS part of the base
    # level: often the always-on unit(s) of a rack learned as one "appliance"
    # (e.g. 33 kW on 96 % of the time for a 25 kW unit plus base). It is not
    # subtracted, and it is reported.
    always_on = {}
    for a, st in zip(apps, states):
        if a.mu0[0] >= 10 and a.mu0[1] >= 0.3 * a.mu0[0] and a.id not in exclude and a.units == 1:
            duty = float((st[obs] > 0).mean()) if obs.any() else 0.0
            if duty >= cfg.get("hidden_always_on_duty", 0.9):
                always_on[a.id] = round(duty, 3)
    dp, dq = np.zeros(T), np.zeros(T)
    for a, st in zip(apps, states):
        if a.id in always_on:
            continue
        if X is not None and x_ref is not None and np.any(a.beta):
            dp += st * (a.mu0[0] + a.beta[0] * (X - x_ref))
            dq += st * (a.mu0[1] + a.beta[1] * (X - x_ref))
        else:
            dp += st * a.mu0[0]
            dq += st * a.mu0[1]
    rp, rq = P - dp, Q - dq
    ok = ~np.isnan(rp) & ~np.isnan(rq)
    if busy is not None:
        ok &= ~busy
    B = int(cfg["hidden_block_s"])
    n = T // B
    bp, bq = [], []
    for i in range(n):
        m = ok[i * B:(i + 1) * B]
        if m.mean() >= 0.5:
            bp.append(np.median(rp[i * B:(i + 1) * B][m]))
            bq.append(np.median(rq[i * B:(i + 1) * B][m]))
    if len(bp) < 8:
        return {}, {}
    fp = float(np.percentile(bp, cfg["hidden_floor_pct"]))
    fq = float(np.percentile(bq, cfg["hidden_floor_pct"]))
    # the non-switching level as a whole: what it spans and how it follows
    # ambient. Variable-speed compressors that never stop, a modulating screw
    # between its rare starts, fans, pumps and the building's own load all
    # live here; from one meter they cannot be told apart.
    level = {"p5_kW": round(float(np.percentile(bp, 5)), 1), "median_kW": round(float(np.median(bp)), 1),
             "p95_kW": round(float(np.percentile(bp, 95)), 1),
             "qp": round(float(np.median(bq) / np.median(bp)), 2) if np.median(bp) > 1 else None}
    if X is not None:
        bx = [np.nanmean(X[i * B:(i + 1) * B]) for i in range(n) if ok[i * B:(i + 1) * B].mean() >= 0.5]
        if len(bx) == len(bp) and np.std(bx) > 0.5:
            sl, ic = np.polyfit(bx, bp, 1)
            level["ambient_slope_kW_per_C"] = round(float(sl), 2)
            level["ambient_r"] = round(float(np.corrcoef(bx, bp)[0, 1]), 2)
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    out = {}
    for a in apps:
        r = rows.get(f"A{a.id}", {})
        if a.id in exclude or a.id in always_on or r.get("variable_speed_suspected") \
                or a.mu0[0] < 10 or a.mu0[1] < 0.3 * a.mu0[0] or a.units < 2:
            continue                       # only racks: "how many units" is the question
        pu = a.mu0[0] - (a.mu_tail[0] if a.asym else 0.0)
        qu = a.mu0[1] - (a.mu_tail[1] if a.asym else 0.0)
        if pu <= 0 or qu <= 0:
            continue
        out[a.id] = int(max(0, np.floor(min(fp / pu, fq / qu) + cfg["hidden_tol"])))
    return out, {"floor_kW": round(fp, 1), "floor_kvar": round(fq, 1), "blocks": len(bp), "level": level,
                 "always_on": {f"A{k}": v for k, v in always_on.items()}}


def classify_pv(apps, states, table, data, cfg, exclude=()):
    """
    Solar PV seen as loads. A cloud passing over the panels lowers the
    generation for 20 s - 10 min, which the meter sees as a unity-PF load
    switching on and off; the tracker learns these edges as one or two small
    unity-PF appliances (5-20 kW). Three things set them apart from heaters,
    chargers and small motors, without knowing the site's location:
      - unity power factor (>= sched_min_pf);
      - daylight only: the busiest pv_window_h clock hours (all days pooled)
        hold >= pv_min_day_share of its starts, and that window is centred
        within pv_center_hours (local time);
      - weather, not a schedule: the number of starts per day varies a lot
        (coefficient of variation >= pv_min_day_cv; clear and overcast days
        have almost none, broken-cloud days dozens). A defrost timer, a
        charger or a fan does about the same every day;
      - many short steps: on average >= sched_daylight_min_starts_per_day
        starts per day (cloud edges 23-57 in the tests; a truck charger,
        also daytime-only and weather-free but irregular, 1-11).
    Returns ({appliance id: info}, {appliance id: features of every unity-PF
    appliance tested}).
    """
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    obs = ~np.isnan(data["P"])
    T = len(obs)
    # whole local days with >= 90 % data
    loc0 = _local_time(data["t0"], [0], tz)[0]
    first_midnight = int((loc0.normalize() + pd.Timedelta(days=1) - loc0).total_seconds())
    day_edges = np.arange(first_midnight, T - 86400 + 1, 86400)
    full = [d for d in day_edges if obs[d:d + 86400].mean() >= 0.9]
    out, feats = {}, {}
    W = int(cfg["pv_window_h"])
    for a, st in zip(apps, states):
        r = rows.get(f"A{a.id}")
        if r is None or r.get("variable_speed_suspected") or a.id in exclude or a.mu0[0] <= 0:
            continue
        pf = r.get("power_factor")
        if pf is None or pf < cfg["sched_min_pf"]:
            continue
        starts = np.flatnonzero(np.diff(st.astype(np.int8)) == 1) + 1
        if len(starts) < cfg["sched_min_starts"]:
            continue
        hrs = _local_time(data["t0"], starts, tz)
        h = (hrs.hour + hrs.minute / 60.0).to_numpy()
        cnt = np.bincount(hrs.hour.to_numpy(), minlength=24)
        cc = np.concatenate([cnt, cnt])
        sums = [cc[h0:h0 + W].sum() for h0 in range(24)]
        h0 = int(np.argmax(sums))
        share = sums[h0] / len(starts)
        center = (h0 + W / 2.0) % 24
        per_day = np.array([((starts >= d) & (starts < d + 86400)).sum() for d in full], float)
        cv = float(per_day.std() / per_day.mean()) if len(per_day) >= 3 and per_day.mean() > 0 else None
        f = {"starts": int(len(starts)), "day_share": round(float(share), 3), "window_center_h": round(center, 1),
             "day_cv": None if cv is None else round(cv, 2), "days": int(len(per_day)),
             "starts_per_day": [int(x) for x in per_day]}
        feats[a.id] = f
        lo, hi = cfg["pv_center_hours"]
        f["mean_starts_per_day"] = round(float(per_day.mean()), 1) if len(per_day) else None
        if share >= cfg["pv_min_day_share"] and lo <= center <= hi and cv is not None and cv >= cfg["pv_min_day_cv"] \
                and per_day.mean() >= cfg["sched_daylight_min_starts_per_day"]:
            out[a.id] = {"label": "PV-like (daytime unity-PF steps that vary with the weather: cloud passages)",
                         "charger_like": False, "dead_hours": None,
                         "start_hours": sorted(set(int(x) for x in hrs.hour)), "pv": f}
    return out, feats


def classify_schedule(apps, states, table, data, cfg, exclude=()):
    """
    Which discovered appliances are not refrigeration, from the data alone.
    Compressors and defrost run around the clock (the load follows the
    weather and a defrost timer repeats every few hours); a truck charger,
    a process line or PV switches only in part of the day. An appliance is
    'scheduled' when its power factor is near unity (not an induction motor;
    a suspected variable-speed drive is left alone) and, pooling all days,
    there is a run of >= sched_min_dead_hours consecutive clock hours in
    which it never starts. Scheduled appliances with many short daytime
    steps are labelled PV-like (cloud passages), the rest charger-like.
    Returns {appliance id: {"label", "dead_hours", "start_hours"}}.
    """
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    rows = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    out = {}
    for a, st in zip(apps, states):
        r = rows.get(f"A{a.id}")
        if r is None or r.get("variable_speed_suspected") or a.id in exclude:
            continue
        pf = r.get("power_factor")
        if pf is None or pf < cfg["sched_min_pf"] or a.mu0[0] <= 0:
            continue
        starts = np.flatnonzero(np.diff(st.astype(np.int8)) == 1) + 1
        if len(starts) < cfg["sched_min_starts"]:
            continue
        hrs = _local_time(data["t0"], starts, tz).hour.to_numpy()
        cnt = np.bincount(hrs, minlength=24)
        # longest run of clock hours (circular) holding at most 3 % of the
        # starts -- a few stray starts (a repaired transition) do not break it
        allow = int(cfg["sched_dead_tolerance"] * len(starts))
        cc = np.concatenate([cnt, cnt])
        dead = max([L for L in range(1, 24) for h0 in range(24) if cc[h0:h0 + L].sum() <= allow], default=0)
        if dead < cfg["sched_min_dead_hours"]:
            continue
        pv_like = (r.get("starts_per_day") or 0) >= cfg["sched_daylight_min_starts_per_day"]
        out[a.id] = {"label": "PV-like (daytime unity-PF steps: cloud passages?)" if pv_like
                     else "scheduled (charger / process: unity PF, idle part of the day)",
                     "charger_like": not pv_like, "dead_hours": int(dead),
                     "start_hours": sorted(set(int(h) for h in hrs))}
    return out


def busy_mask(apps, states, sched, data, events, cfg):
    """
    Busy windows = sessions of the charger-like scheduled appliances: from
    each switch-on until the unity-load level (unity_level) is back to where
    it was before the session (a charger tapers off long after the tracker
    has lost it), plus a margin either side. Inside them the second pass
    creates no appliances, updates no magnitudes and repairs no levels.
    """
    T = data["T"]
    mask = np.zeros(T, bool)
    ids = [k for k, v in sched.items() if v["charger_like"]]
    if not ids:
        return mask
    u, _ = unity_level(data["P"], data["Q"], events)
    m, ext = cfg["sched_window_margin_s"], cfg["sched_window_max_ext_s"]
    for a, st in zip(apps, states):
        if a.id not in ids:
            continue
        d = np.diff(np.concatenate([[0], (st > 0).astype(np.int8), [0]]))
        on, off = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        tol = max(0.15 * a.mu0[0], 3.0)
        for t_on, t_off in zip(on, off):
            pre = u[max(0, t_on - 300): max(1, t_on - 30)]
            u_pre = float(np.median(pre)) if len(pre) else u[t_on]
            seg = u[t_off: min(T, t_off + ext)]
            back = np.flatnonzero(seg <= u_pre + tol)
            end = t_off + (int(back[0]) if len(back) else len(seg))
            mask[max(0, t_on - m): min(T, end + m)] = True
    return mask


def appliance_table(tr, apps, states, data, cfg, rack, inst, dyn=None):
    """
    One row per discovered appliance: the input table for the flexibility
    estimate. Magnitudes are at the reference ambient (median of the learning
    period); temp_slope_* gives how they change per degC. rated_kW is the
    compressor's own power: the step at the moment of switching when rack
    compensation is detected, and without its lagging tail (fan) when it
    has one. share_clean_switches is a quality flag: the share of its
    switches explained by it alone (not as part of a combination and not
    as a repaired, missed transition) -- low values mean its timing (duty
    cycle, durations) is less reliable than its size.

    reliability bands share_clean_switches (calibrated on 56 synthetic
    compressors in 16 stress datasets, consistent on both halves):
      good  >= 0.85  duty-cycle error median 0.3 %, rated power all within 5 %
    variable_speed_suspected: the level falls >= 15 % of the start step within
    10 min after starts, >= 40 % of that after the first 2 min (see
    start_dynamics()), and its power factor is >= 0.95; rated_kW is then left empty -- the step is not a
    rating -- and settled_kW estimates the minimum-speed power.
      fair  0.70-0.85  duty-cycle error median ~11 %, rated within 5 % for 7 in 8
      poor  < 0.70  duty-cycle error median ~10 %, rated within 5 % for 5 in 8
    plus "too few switches" below 20 switch decisions.
    units: identical units sharing one step (a compressor rack, see the
    structure-search moves "merge identical" / "add unit"); rated_kW is per
    unit, duty_cycle per unit, mean_units_running = average units on. One
    unit that never stops is indistinguishable from base load, so for a
    rack whose count never reaches zero `units` is a lower bound.
    main() adds `category` (refrigeration / non-refrigeration, see
    classify_schedule()) and appends charger rows found in earlier passes.
    """
    obs = ~np.isnan(data["P"])
    days = max(obs.sum() / 86400.0, 1e-9)
    dec_counts = {}
    for _, _, dec in tr.log:
        parts = dec.split()
        for p_ in parts:
            m_ = re.match(r"A(\d+)([+\-t])([ru]?)$", p_)
            if not m_:
                continue
            k = int(m_.group(1))
            c = dec_counts.setdefault(k, {"clean": 0, "combo": 0, "repaired": 0})
            if m_.group(3) == "r":
                c["repaired"] += 1
            elif len(parts) > 1:
                c["combo"] += 1
            else:
                c["clean"] += 1
    rows = []
    for a, st in zip(apps, states):
        tail = a.mu_tail if a.asym else np.zeros(2)
        rated_p = a.mu0[0] - tail[0]
        src = "step"
        if inst and getattr(a, "rated_kw", None) is not None:
            rated_p, src = a.rated_kw, "step at switch (rack compensation)"
        rated_q = a.mu0[1] - tail[1]
        qp = rated_q / rated_p if rated_p > 0 else np.nan
        if qp >= cfg["resistive_qp_ratio"]:
            kind = "inductive (compressor / motor)"
            if a.units > 1:
                kind = f"inductive: {a.units} identical units (compressor rack?)"
            if a.asym:
                kind += ", with lagging part (fan?)"
        else:
            kind = "resistive / unity-PF (heater, defrost, charger, PV?)"
        on_r, off_r = _runs(st, 1) / 60.0, _runs(st, 0) / 60.0
        pct = lambda x, q_: float(np.percentile(x, q_)) if len(x) else None
        starts = int(((np.diff(st.astype(np.int8)) == 1) & obs[1:]).sum())
        duty = float(st[obs].mean()) / a.units if obs.any() else None     # per unit for a rack
        dc = dec_counts.get(a.id, {"clean": 0, "combo": 0, "repaired": 0})
        n_dec = sum(dc.values())
        rows.append({
            "appliance": f"A{a.id}",
            "type": kind,
            "rated_kW": round(float(rated_p), 2),
            "rated_kvar": round(float(rated_q), 2),
            "power_factor": round(float(rated_p / math.hypot(rated_p, rated_q)), 3) if rated_p > 0 else None,
            "rated_source": src,
            "units": int(a.units),           # identical units sharing this step; rated_kW is per unit
            "step_kW": round(float(a.mu0[0]), 2),
            "step_kvar": round(float(a.mu0[1]), 2),
            "tail_kW": round(float(tail[0]), 2),
            "temp_slope_kW_per_C": round(float(a.beta[0]), 3),
            "temp_slope_kvar_per_C": round(float(a.beta[1]), 3),
            "reference_ambient_C": round(cfg["_x_ref"], 2) if cfg.get("_x_ref") is not None else None,
            "magnitude_covariate": cfg.get("_x_label") if cfg.get("_x_ref") is not None else None,
            "duty_cycle": round(duty, 4) if duty is not None else None,
            "starts_per_day": round(starts / days, 2),
            "on_min_p10": pct(on_r, 10), "on_min_median": pct(on_r, 50), "on_min_p90": pct(on_r, 90),
            "off_min_p10": pct(off_r, 10), "off_min_median": pct(off_r, 50), "off_min_p90": pct(off_r, 90),
            "energy_kWh_per_day": round(duty * a.units * rated_p * 24, 1) if duty is not None else None,
            "mean_units_running": round(duty * a.units, 3) if duty is not None else None,
            "n_switch_decisions": n_dec,
            "share_clean_switches": round(dc["clean"] / n_dec, 3) if n_dec else None,
            "n_repaired_switches": dc["repaired"],
            "reliability": ("too few switches" if n_dec < 20 else
                            "good" if dc["clean"] / n_dec >= 0.85 else
                            "fair" if dc["clean"] / n_dec >= 0.70 else "poor"),
            "fall_after_start_10min": round(dyn[a.id][0], 3) if dyn and a.id in dyn else None,
            "fall_share_after_2min": round(dyn[a.id][1], 3) if dyn and a.id in dyn else None,
            "variable_speed_suspected": bool(dyn and a.id in dyn
                                             and dyn[a.id][0] >= cfg["vsd_min_decay"]
                                             and dyn[a.id][1] >= cfg["vsd_min_late_share"]
                                             and rated_p > 0
                                             and rated_p / math.hypot(rated_p, rated_q) >= cfg["vsd_min_pf"]),
        })
    for r_ in rows:
        if r_["variable_speed_suspected"]:
            # The start step is a pull-down level, not the drive's rating;
            # the level it settles to is roughly its minimum-speed power.
            r_["type"] = "variable-speed compressor (suspected)"
            r_["settled_kW"] = round(r_["step_kW"] * (1 - r_["fall_after_start_10min"]), 1)
            r_["rated_source"] = ("not rated: start step of a variable-speed drive; get the rating from the "
                                  "nameplate / drive data. settled_kW ~ minimum-speed power")
            r_["rated_kW"] = None
            r_["rated_kvar"] = None
            r_["energy_kWh_per_day"] = None      # its power varies while on; not step x duty
            r_["reliability"] = "poor"
    t = pd.DataFrame(rows)
    for c in [c for c in t.columns if c.startswith(("on_min", "off_min"))]:
        t[c] = t[c].astype(float).round(1)
    return t.sort_values("step_kW", ascending=False).reset_index(drop=True) if len(t) else t


def export_results(table, tr, apps, states, c_est, data, cfg, rack, res):
    """Write appliances.csv, switches.csv, timeseries_<res>s.csv and
    summary.json to cfg['output_dir']; returns the file paths."""
    out = cfg["output_dir"]
    os.makedirs(out, exist_ok=True)
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    t0, T = data["t0"], data["T"]
    files = []

    p = os.path.join(out, "appliances.csv")
    table.to_csv(p, index=False)
    files.append(p)

    sw = []
    for a, st in zip(apps, states):
        d = np.diff(np.concatenate([[0], st.astype(np.int8)]))
        for i_ in np.flatnonzero(d != 0):
            sw.append((int(i_), f"A{a.id}", int(st[i_])))
    sw.sort()
    sdf = pd.DataFrame(sw, columns=["i", "appliance", "new_state"])
    sdf.insert(0, "time_local", _local_time(t0, sdf["i"], tz).strftime("%Y-%m-%d %H:%M:%S%z"))
    sdf.insert(0, "time_utc_s", t0 + sdf.pop("i"))
    p = os.path.join(out, "switches.csv")
    sdf.to_csv(p, index=False)
    files.append(p)

    r = max(1, int(cfg.get("output_resolution_s", 60)))
    n = T // r
    def agg(x):
        import warnings
        x = np.asarray(x, float)[:n * r].reshape(n, r)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)      # all-NaN intervals (data gaps) -> NaN
            return np.nanmean(x, axis=1)
    ts = pd.DataFrame({"time_local": _local_time(t0, np.arange(n) * r, tz).strftime("%Y-%m-%d %H:%M:%S%z"),
                       "P_kW": agg(data["P"]), "Q_kvar": agg(data["Q"])})
    X, x_ref = data.get("X"), cfg.get("_x_ref")
    if data.get("X_dry") is not None:
        ts["ambient_C"] = agg(data["X_dry"])
    if X is not None and data["info"].get("covariate", "dry-bulb degC") != "dry-bulb degC":
        ts["covariate_" + data["info"]["covariate"].split()[0]] = agg(X)
    if data.get("RH") is not None:
        ts["rh_pct"] = agg(data["RH"])
    total = np.zeros(T)
    for a, st, row in zip(apps, states, table.set_index("appliance").loc[[f"A{a.id}" for a in apps]].itertuples()):
        mag = np.full(T, a.mu0[0])
        if X is not None and x_ref is not None and np.any(a.beta):
            mag = a.mu0[0] + a.beta[0] * (X - x_ref)
        pw = st * mag
        total += pw
        ts[f"A{a.id}_kW"] = agg(pw)
    # near-identical compressors whose identities swap: their sum is reliable,
    # the split between them is not (see twin_compressors())
    for grp in res.get("twin_groups") or []:
        members = grp.split("+")
        if all(f"{m}_kW" in ts for m in members):
            ts[f"{grp}_kW"] = sum(ts[f"{m}_kW"] for m in members)
    ts["continuous_est_kW"] = agg(c_est)
    ts["discrete_total_kW"] = agg(total)
    p = os.path.join(out, f"timeseries_{r}s.csv")
    ts.to_csv(p, index=False, float_format="%.3f")
    files.append(p)

    files += export_hourly_compressors(table, apps, states, data, cfg)
    if cfg.get("humidity_check") and data.get("RH") is not None and data.get("X_dry") is not None:
        hc = humidity_check(tr, apps, data, cfg)
        if hc is not None and len(hc):
            p = os.path.join(out, "humidity_check.csv")
            hc.to_csv(p, index=False)
            files.append(p)
            res["humidity_check"] = hc.to_dict(orient="records")
        dw = duty_vs_weather(table, apps, states, data, cfg)
        if dw is not None and len(dw):
            p = os.path.join(out, "duty_vs_weather.csv")
            dw.to_csv(p, index=False)
            files.append(p)
            res["duty_vs_weather"] = dw.to_dict(orient="records")

    summary = {k: v for k, v in res.items() if k not in ("appliance_table", "held_out", "full", "output_files")}
    summary["settings"] = {k: cfg[k] for k in ("train_frac", "train_frac_real", "timestamp_timezone",
                                               "power_unit", "weather_path", "output_resolution_s",
                                               "humidity_path", "magnitude_covariate", "humidity_measure")
                           if k in cfg}
    summary["period_local"] = [str(_local_time(t0, [0], tz)[0]), str(_local_time(t0, [T - 1], tz)[0])]
    p = os.path.join(out, "summary.json")
    with open(p, "w") as fh:
        json.dump(summary, fh, indent=2, default=str)
    files.append(p)
    return files


def controllable_flag(row):
    """(controllable 0/1, reason) for one appliances.csv row. 1 only for an
    inductive refrigeration compressor that switches: not variable-speed
    (suspected), not always-on, not a defrost / timer load, not a duplicate,
    not non-refrigeration, not the capacitor bank."""
    cat = str(row.get("category") or "refrigeration")
    role = str(row.get("role") or "")
    typ = str(row.get("type") or "")
    if not cat.startswith("refrigeration"):
        return 0, cat
    if "same compressor as" in cat:
        return 0, "duplicate identity (learned twice)"
    if "always on" in cat:
        return 0, "always on (part of the base level)"
    if str(row.get("variable_speed_suspected")).lower() == "true" or "variable-speed" in typ:
        return 0, "variable-speed suspected"
    if "resistive" in typ or "unity-PF" in typ:
        return 0, "resistive / unity-PF (defrost heater?)"
    if role.startswith(("defrost", "periodic inductive")) or "defrost timer" in role:
        return 0, f"timer / defrost load: {role}"
    if "capacity step of" in cat:
        return 1, "capacity step of a compressor"
    return 1, "inductive refrigeration compressor"


def _ols_p(X, y):
    """OLS with intercept in X. Returns (beta, p-values, R2)."""
    from scipy import stats as _st
    n, k = X.shape
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    res_ = y - X @ beta
    dof = n - k
    sst = float(((y - y.mean()) ** 2).sum()) + 1e-12
    r2 = 1 - float(res_ @ res_) / sst
    if dof <= 0:
        return beta, np.full(k, np.nan), r2
    s2 = float(res_ @ res_) / dof
    se = np.sqrt(np.maximum(np.diag(s2 * np.linalg.pinv(X.T @ X)), 0))
    with np.errstate(divide="ignore", invalid="ignore"):
        p = 2 * _st.t.sf(np.abs(beta / se), dof)
    return beta, p, r2


def humidity_check(tr, apps, data, cfg):
    """Does an appliance's step size still depend on humidity once the
    magnitude covariate (dry-bulb, wet-bulb or enthalpy) is accounted for?
    Uses the single-appliance switches of the final tracker (log entries
    'A12+' / 'A12-'): |step P| ~ 1 + stop + covariate + humidity, OLS.
    p-values treat switches as independent (consecutive switches are not
    quite), so read them as indicative."""
    X, Xd, RH = data.get("X"), data.get("X_dry"), data.get("RH")
    hm, hlab = humidity_measure(Xd, RH, cfg)
    T = data["T"]
    by = {}
    for t, d, dec in tr.log:
        m_ = re.fullmatch(r"A(\d+)([+\-])", str(dec).strip())
        if not m_ or t >= T:
            continue
        i0 = max(0, int(t) - 30)
        by.setdefault(int(m_.group(1)), []).append((abs(float(np.asarray(d)[0])), m_.group(2) == "-",
                                                    float(np.mean(X[i0:int(t) + 1])), float(np.mean(hm[i0:int(t) + 1]))))
    rows = []
    for a in apps:
        v = by.get(a.id, [])
        row = {"appliance": f"A{a.id}", "step_kW": round(float(a.mu0[0]), 2), "n_switches": len(v),
               "covariate": data["info"].get("covariate"), "humidity_measure": hlab}
        if len(v) < cfg.get("humidity_check_min_switches", 40):
            row["verdict"] = "too few single-appliance switches"
            rows.append(row)
            continue
        y, stop, x, h = (np.array(c, float) for c in zip(*v))
        if np.std(h) < 1e-6:
            row["verdict"] = "no humidity spread"
            rows.append(row)
            continue
        cols = [np.ones_like(y)] + ([stop] if 0 < stop.mean() < 1 else []) + [x - x.mean(), h - h.mean()]
        b, pv, r2 = _ols_p(np.column_stack(cols), y)
        b0, _, r2_0 = _ols_p(np.column_stack(cols[:-1]), y)
        iqr = float(np.subtract(*np.percentile(h, [75, 25])))
        eff = b[-1] * iqr / max(float(np.median(y)), 1e-6)
        row.update({"covariate_slope_kW": round(float(b[-2]), 4), "covariate_p": float(pv[-2]),
                    "humidity_slope_kW_per_unit": round(float(b[-1]), 4), "humidity_p": float(pv[-1]),
                    "humidity_iqr": round(iqr, 2), "humidity_effect_over_iqr_pct_of_step": round(100 * eff, 2),
                    "r2_without_humidity": round(r2_0, 4), "r2_with_humidity": round(r2, 4),
                    "verdict": ("humidity explains step size beyond the covariate"
                                if pv[-1] < 0.01 and abs(eff) >= 0.01 else
                                "no material humidity effect on step size")})
        rows.append(row)
    return pd.DataFrame(rows)


def duty_vs_weather(table, apps, states, data, cfg):
    """Run time against weather. Per compressor: daily running share (share of
    observed seconds on, per unit) regressed on daily mean outdoor T, then on
    T + the humidity measure. Reports both fits, the humidity coefficient and
    its p-value. Days are autocorrelated, so p-values are optimistic; the
    R2 gain and the sign are the robust part."""
    Xd, RH = data.get("X_dry"), data.get("RH")
    hm, hlab = humidity_measure(Xd, RH, cfg)
    t0, T = data["t0"], data["T"]
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    off = pd.Timestamp(t0, unit="s", tz="UTC").tz_convert(tz).utcoffset().total_seconds()
    day = ((int(t0) + int(off) + np.arange(T)) // 86400).astype(np.int64)
    day -= day[0]
    nd = int(day[-1]) + 1
    obs = ~np.isnan(np.asarray(data["P"], float))
    n_obs = np.bincount(day, weights=obs.astype(float), minlength=nd)
    n_all = np.bincount(day, minlength=nd).astype(float)
    good = (n_obs >= cfg.get("hourly_min_observed", 0.9) * 86400) & (n_all >= 86400 * 0.99)
    dT = np.bincount(day, weights=Xd, minlength=nd) / np.maximum(n_all, 1)
    dH = np.bincount(day, weights=hm, minlength=nd) / np.maximum(n_all, 1)
    rows_ = {r["appliance"]: r for r in table.to_dict(orient="records")} if len(table) else {}
    out = []
    for a, st in zip(apps, states):
        aid = f"A{a.id}"
        r_ = rows_.get(aid, {})
        on = np.asarray(st, float) / max(int(a.units), 1)
        share = np.bincount(day, weights=np.where(obs, on, 0.0), minlength=nd) / np.maximum(n_obs, 1)
        row = {"appliance": aid, "category": r_.get("category"), "role": r_.get("role"),
               "controllable_candidate": bool(str(r_.get("category", "")).startswith("refrigeration")
                                              and not r_.get("variable_speed_suspected")),
               "humidity_measure": hlab, "n_days": int(good.sum())}
        if good.sum() < cfg.get("duty_weather_min_days", 20) or np.std(share[good]) < 1e-6:
            row["verdict"] = "too few days or constant running share"
            out.append(row)
            continue
        y, xT, xH = share[good], dT[good] - dT[good].mean(), dH[good] - dH[good].mean()
        one = np.ones_like(y)
        bT, pT, r2T = _ols_p(np.column_stack([one, xT]), y)
        bB, pB, r2B = _ols_p(np.column_stack([one, xT, xH]), y)
        corr = float(np.corrcoef(xT, xH)[0, 1]) if np.std(xH) > 0 else np.nan
        row.update({"mean_running_share": round(float(y.mean()), 4),
                    "T_only_slope_per_C": round(float(bT[1]), 5), "T_only_p": float(pT[1]), "T_only_r2": round(r2T, 4),
                    "T_slope_per_C": round(float(bB[1]), 5), "T_p": float(pB[1]),
                    "humidity_slope_per_unit": round(float(bB[2]), 5), "humidity_p": float(pB[2]),
                    "T_humidity_r2": round(r2B, 4), "r2_gain_from_humidity": round(r2B - r2T, 4),
                    "corr_T_humidity_daily": round(corr, 3),
                    "verdict": ("humidity adds to temperature for run time" if pB[2] < 0.01 and r2B - r2T >= 0.02 else
                                "temperature alone explains run time as well" if pT[1] < 0.05 else
                                "run time does not follow the weather")})
        out.append(row)
    return pd.DataFrame(out)


def export_hourly_compressors(table, apps, states, data, cfg):
    """compressor_list.csv (appliances.csv + controllable) and
    compressor_hourly.csv: site, compressor id, clock hour (local, start),
    running share a_k(h) in [0, 1] (share of the hour on; for a rack the
    share of its units running), observed share of the hour. An hour with
    fewer than hourly_min_observed of its seconds observed gets no share."""
    out = cfg["output_dir"]
    tz = cfg.get("timestamp_timezone", "Europe/Stockholm")
    site = cfg.get("site_code") or os.path.basename(os.path.normpath(out))
    files = []
    if not len(table) or "appliance" not in table:
        return files
    lst = table.copy()
    fl = [controllable_flag(r) for _, r in lst.iterrows()]
    lst.insert(0, "site", site)
    lst.insert(2, "controllable", [f[0] for f in fl])
    lst.insert(3, "controllable_reason", [f[1] for f in fl])
    p = os.path.join(out, "compressor_list.csv")
    lst.to_csv(p, index=False)
    files.append(p)

    t0, T = data["t0"], data["T"]
    obs = ~np.isnan(np.asarray(data["P"], float))
    hour = (int(t0) + np.arange(T)) // 3600            # whole-hour offsets: UTC hours = local clock hours
    codes = hour - hour[0]
    n_h = int(codes[-1]) + 1
    n_obs = np.bincount(codes, weights=obs.astype(float), minlength=n_h)
    n_all = np.bincount(codes, minlength=n_h).astype(float)
    obs_share = np.divide(n_obs, n_all, out=np.zeros(n_h), where=n_all > 0)
    ok = obs_share >= cfg.get("hourly_min_observed", 0.9)
    starts = _local_time(0, (hour[0] + np.arange(n_h)) * 3600, tz).strftime("%Y-%m-%d %H:%M:%S%z")
    wx = {}
    if data.get("X_dry") is not None:
        def hmean(x):
            x = np.asarray(x, float)
            ok_ = ~np.isnan(x)
            sm = np.bincount(codes, weights=np.where(ok_, x, 0.0), minlength=n_h)
            ct = np.bincount(codes, weights=ok_.astype(float), minlength=n_h)
            return np.divide(sm, ct, out=np.full(n_h, np.nan), where=ct > 0)
        wx["outdoor_T_C"] = np.round(hmean(data["X_dry"]), 2)
        if data.get("RH") is not None:
            wx["outdoor_RH_pct"] = np.round(hmean(data["RH"]), 1)
            wx["humidity_ratio_gkg"] = np.round(humidity_ratio_gkg(wx["outdoor_T_C"], wx["outdoor_RH_pct"],
                                                                   cfg.get("air_pressure_hpa", 1013.25)), 2)
    ctrl = dict(zip(lst["appliance"], lst["controllable"]))
    rated = dict(zip(lst["appliance"], lst.get("rated_kW", pd.Series(np.nan, index=lst.index))))
    rows = []
    for a, st in zip(apps, states):
        aid = f"A{a.id}"
        on = np.asarray(st, float) / max(int(a.units), 1)
        on_obs = np.bincount(codes, weights=np.where(obs, on, 0.0), minlength=n_h)
        share = np.divide(on_obs, n_obs, out=np.full(n_h, np.nan), where=n_obs > 0)
        share[~ok] = np.nan
        rows.append(pd.DataFrame({"site": site, "compressor_id": aid, "hour_start_local": starts,
                                  "running_share": np.round(np.clip(share, 0, 1), 4),
                                  "observed_share": np.round(obs_share, 4), "units": int(a.units),
                                  "rated_kW": rated.get(aid), "controllable": ctrl.get(aid, 0),
                                  "source_resolution": "1 s", **wx}))
    if rows:
        h = pd.concat(rows, ignore_index=True)
        p = os.path.join(out, "compressor_hourly.csv")
        h.to_csv(p, index=False)
        files.append(p)
    return files


def score_continuous(c_est, gt, cfg, split_idx):
    cols = [c for c in cfg["continuous_truth_cols"] if c in gt.columns]
    if not cols:
        return None
    truth = gt[cols].sum(axis=1).to_numpy()[split_idx:]
    est = c_est[split_idx:]
    ok = ~np.isnan(truth)
    return {"mae_kw": float(np.mean(np.abs(est[ok] - truth[ok]))),
            "corr": float(np.corrcoef(est[ok], truth[ok])[0, 1]),
            "truth_mean_kw": float(truth[ok].mean())}


# =========================================================================
# Main
# =========================================================================
def main(cfg=CONFIG, data=None, verbose=True, return_tracker=False, label=""):
    t_start = time.time()
    data = data or load_grid(cfg)
    if cfg.get("production_path"):
        data = add_production(data, cfg["production_path"], cfg)
        print(f"  [solar] production added back: {data['info']['production']}")
    if cfg.get("dark_only"):
        data = dark_only(data, cfg)
        print(f"  [solar] dark hours only: {data['info']['dark_only']['share_kept']:.0%} of the recording kept")
    T = data["T"]
    gt_comp = [c for c in cfg.get("ground_truth_cols", []) if c in data["gt"].columns and "defrost" not in c]
    evaluate = bool(gt_comp)
    # Evaluation: learn on the first part, freeze, score the held-out rest.
    # Real data: nothing to score, so learn from the whole series.
    split_idx = min(T, int(T * (cfg["train_frac"] if evaluate else cfg.get("train_frac_real", 1.0))))

    t0 = time.time()
    events, gaps, qsteps = detect_edges(data["P"], data["Q"], cfg, return_qsteps=True)
    rack = None
    P_track, Q_track = data["P"], data["Q"]
    if cfg.get("rack_compensation") or cfg.get("rated_instantaneous") == "auto":
        Pi = pd.Series(data["P"]).interpolate(limit_direction="both").to_numpy()
        Qi = pd.Series(data["Q"]).interpolate(limit_direction="both").to_numpy()
        est = estimate_compensation(Pi, events, cfg)
        rack = {"c_median": est[0], "tau_s": est[1], "n_curves": est[2], "applied": False,
                "detected": bool(est and est[0] >= cfg["rack_min_c"])} if est else None
        if cfg.get("rack_compensation") and est and est[0] >= cfg["rack_min_c"]:
            Pc, Qc, n_corr = correct_compensation(Pi, Qi, events, est[1], cfg)
            nan = np.isnan(data["P"])
            P_track, Q_track = Pc.copy(), Qc.copy()
            P_track[nan] = np.nan
            Q_track[nan] = np.nan
            events, gaps = detect_edges(P_track, Q_track, cfg)
            rack.update(applied=True, n_corrected=n_corr)
    t_edges = time.time() - t0
    if cfg.get("_busy_mask") is not None:          # externally given busy windows (tests)
        mask = cfg["_busy_mask"]
        for e in events:
            e["busy"] = bool(mask[min(e["t"], T - 1)])
    if data.get("X") is not None and cfg["improvements"]["temperature_magnitude"]:
        X = data["X"]
        cfg = dict(cfg)
        cfg["_x_ref"] = float(np.median(X[:split_idx]))    # training part only
        cfg["_x_label"] = data["info"].get("covariate", "dry-bulb degC")
        for e in events:
            e["x"] = float(X[max(0, e["t"] - 30): e["t"] + 1].mean())   # causal: last 30 s

    seeds = []
    if cfg["fhmm_seed"] and cfg.get("fhmm_params_path") and os.path.exists(cfg["fhmm_params_path"]):
        with open(cfg["fhmm_params_path"], "rb") as fh:
            seeds = fhmm_seeds(pickle.load(fh)["params"], cfg)

    t0 = time.time()
    tr = run_tracker(events, gaps, T, cfg, seeds=seeds, split_t=split_idx)
    inst = cfg.get("rated_instantaneous")
    if inst == "auto":
        inst = bool(rack and rack.get("detected"))
    Xm = data.get("X") if cfg["improvements"]["temperature_magnitude"] else None

    info_ = [({}, ({}, {}), {}, {}, {})]
    defrost_info = [{}]
    mod_info = [{}]
    busy_ref = [None]
    pv_info = [{}]

    def analyse(tr):
        names, states, apps = tr.state_matrix(T)
        states = prune_units(apps, states, cfg)
        if cfg.get("defrost_rebuild"):
            names, states, apps, drb = rebuild_defrost(names, states, apps, data, events, cfg, busy=busy_ref[0], tr=tr,
                                                       qsteps=qsteps)
            defrost_info[0] = drb
        for a in apps:
            a.set_x(None)                      # report magnitudes at the reference covariate
        if inst:
            appliance_rated_power(tr, P_track, Xm, cfg, events)
        lags = detect_lagging_parts(tr, apps, events, cfg) if cfg.get("lag_detection") else {}
        if cfg.get("mod_detection"):
            rises = start_rise(tr, events, P_track, Q_track, cfg)
            mods = {}
            for a in apps:
                rr_ = rises.get(a.id)
                if not rr_ or a.mu0[0] < 10 or a.mu0[1] < cfg["mod_min_start_qp"] * a.mu0[0]:
                    continue
                if rr_["rise_p90_kW"] >= max(cfg["mod_min_rise_kw"], cfg["mod_min_rise_share"] * a.mu0[0]) \
                        and cfg["mod_min_rise_qp"] <= rr_["rise_qp"] <= cfg["mod_max_rise_qp"]:
                    mods[a.id] = dict(rr_, start_kW=round(float(a.mu0[0]), 1),
                                      full_load_kW=round(float(a.mu0[0] + rr_["rise_max_kW"]), 1))
            mod_info[0] = mods
        table = appliance_table(tr, apps, states, data, cfg, rack, inst,
                                dyn=start_dynamics(tr, events, P_track, cfg))
        pv, pv_feats = classify_pv(apps, states, table, data, cfg) if cfg.get("pv_classification") else ({}, {})
        pv_info[0] = pv_feats
        timer = classify_timer(apps, states, table, data, cfg) if cfg.get("timer_classification") else {}
        timer = {k: v for k, v in timer.items() if k not in pv}      # cloud edges are no defrost timer
        sched = classify_schedule(apps, states, table, data, cfg, exclude=set(timer) | set(pv)) \
            if cfg.get("schedule_classification") else {}
        sched.update(pv)
        stages = capacity_stages(apps, tr.log, table, cfg,
                                 exclude={k for k, v in timer.items() if v["defrost_load"]} | set(sched)) \
            if cfg.get("stage_classification") else ({}, {})
        dups = duplicate_identities(apps, states, table, cfg, exclude=set(timer) | set(sched)
                                    | set(stages[0]), events=events) if cfg.get("lag_detection") else {}
        twins = twin_compressors(tr, apps, table, cfg, events, exclude=set(timer) | set(sched)
                                 | set(stages[0]) | set(dups), rack=rack) if cfg.get("twin_detection") else {}
        info_[0] = (timer, stages, dups, lags, twins)
        return names, states, apps, table, sched

    names, states, apps, table, sched = analyse(tr)
    sched_info = {"pass1": {f"A{k}": v for k, v in sched.items()}, "second_pass": False}
    carried = []                               # charger-like loads found in pass 1 (absent from pass 2)
    mask = np.zeros(T, bool)
    n_pass = 1
    while any(v["charger_like"] for v in sched.values()) and n_pass < cfg.get("sched_max_passes", 3):
        # Another pass: same events, but nothing is learned inside the
        # sessions of the scheduled loads (their steps, tapers and module
        # switching corrupted the compressor models). A pass can uncover a
        # charger the previous one had mixed up with something else; its
        # sessions are added and the tracker runs again.
        mask |= busy_mask(apps, states, sched, data, events, cfg)
        busy_ref[0] = mask
        rows1 = {r["appliance"]: r for r in table.to_dict(orient="records")}
        carried += [dict(rows1[f"A{k}"], appliance=f"S{n_pass}.{k}", category="non-refrigeration: " + v["label"],
                         dead_hours=v["dead_hours"]) for k, v in sched.items() if v["charger_like"]]
        for e in events:
            e["busy"] = bool(mask[min(e["t"], T - 1)])
        tr = run_tracker(events, gaps, T, cfg, seeds=seeds, split_t=split_idx)
        names, states, apps, table, sched = analyse(tr)
        n_pass += 1
        sched_info.update(second_pass=True, passes=n_pass, busy_share=float(mask.mean()),
                          n_busy_events=int(sum(e.get("busy", False) for e in events)))
        sched_info[f"pass{n_pass}"] = {f"A{k}": v for k, v in sched.items()}
    if carried:
        # one row per charger: drop copies found again in a later pass
        found = [a.mu0[0] for a in apps if a.id in sched and sched[a.id]["charger_like"]]
        uniq = []
        for r in carried[::-1]:
            if not any(abs(s_ - r["step_kW"]) <= 0.1 * r["step_kW"] for s_ in found):
                uniq.append(r)
                found.append(r["step_kW"])
        carried = uniq[::-1]
    sched_info["final"] = {f"A{k}": v for k, v in sched.items()}
    t_track = time.time() - t0

    # appliances the pipeline itself lists as non-refrigeration are not
    # claimed to be compressors or defrost, so they are not scored as such
    keep = [i for i, a in enumerate(apps) if a.id not in sched]
    res = score([names[i] for i in keep], states[keep], data["gt"], cfg, split_idx) if evaluate else {}
    res["mode"] = "evaluation" if evaluate else "real data"
    c_est = continuous_estimate(data["P"], states, apps, cfg, data.get("X"))
    res["continuous"] = score_continuous(c_est, data["gt"], cfg, split_idx) if evaluate else None
    res["rack"] = rack
    res["appliance_rated_kw"] = {f"A{a.id}": getattr(a, "rated_kw", None) for a in apps}
    if evaluate:
        res["rated"] = rated_power(states[keep], [apps[i] for i in keep], data["gt"], cfg, split_idx, Xm)
        errs = [v["err_pct"] for v in res["rated"].values() if v["err_pct"] is not None]
        res["rated_mean_err_pct"] = float(np.mean(errs)) if errs else None
        res["rated_n_missing"] = sum(v["est"] is None for v in res["rated"].values())
    res["stats"] = tr.stats
    res["long_mode"] = getattr(tr, "long_info", None)
    res["pv_features"] = {f"A{k}": v for k, v in pv_info[0].items()}
    res["defrost_rebuild"] = defrost_info[0]
    res["modulated_compressors"] = {f"A{k}": v for k, v in mod_info[0].items()}
    hidden, base_floor = (hidden_units(apps, states, table, data, cfg,
                                       exclude=set(sched) | set(info_[0][2]) | set(info_[0][1][0]), busy=mask)
                          if cfg.get("hidden_unit_check") else ({}, {}))
    res["base_floor"] = base_floor
    res["possible_hidden_units"] = {f"A{k}": v for k, v in hidden.items()}
    res["n_events"] = len(events)
    res["n_appliances"] = len(apps)
    res["appliances"] = names
    res["non_refrigeration"] = [names[i] for i, a in enumerate(apps) if a.id in sched] + \
                               [f"{r['appliance']}({r['step_kW']:.1f})" for r in carried]
    res["schedule"] = sched_info
    res["seeds"] = [np.round(s, 2).tolist() for s in seeds]
    res["runtime_s"] = {"edges": t_edges, "tracking": t_track, "total": time.time() - t_start}
    res["input"] = data.get("info", {})
    timer, stages, dups, lags, twins = info_[0]
    stage_of = stages[0]
    twin_pairs = twins
    res["twin_compressors"] = {f"A{i}/A{j}": v for (i, j), v in twin_pairs.items()}
    # identity-mixed groups: near-identical compressors connected by pairs
    # that cannot be told apart; their SUM is reliable, the split is not
    parent = {}
    def _root(x):
        while parent.get(x, x) != x:
            x = parent[x]
        return x
    for (i, j), v in twin_pairs.items():
        if not v["separable"]:
            parent.setdefault(i, i); parent.setdefault(j, j)
            parent[_root(i)] = _root(j)
    groups = {}
    for x in parent:
        groups.setdefault(_root(x), []).append(x)
    twin_groups = [sorted(g) for g in groups.values() if len(g) > 1]
    res["twin_groups"] = ["+".join(f"A{i}" for i in g) for g in twin_groups]
    group_of = {i: "+".join(f"A{x}" for x in g) for g in twin_groups for i in g}
    res["duplicate_identities"] = {f"A{k}": f"A{v}" for k, v in dups.items()}
    res["lagging_parts"] = {f"A{k}": v for k, v in lags.items()}
    if len(table):
        ids = [int(a[1:]) for a in table["appliance"]]
        table.insert(1, "category", [("non-refrigeration: " + sched[i]["label"]) if i in sched else
                                     f"refrigeration: capacity step of A{stage_of[i]}" if i in stage_of else
                                     f"refrigeration: same compressor as A{dups[i]} (learned twice)" if i in dups else
                                     "refrigeration: always on (part of the base level; size may be a sum of units)"
                                     if f"A{i}" in (base_floor.get("always_on") or {}) else
                                     "refrigeration" for i in ids])
        note = {}
        def _why(v):
            if v.get("basis") == "rated":
                return "rated sizes within 11 % on a compensated rack, where the steps do not identify the machine"
            if v["separation_sd"] is None:
                return "too few clean switches to tell them apart"
            if v["minor_weight"] < 0.1:
                return f"their {v['closest_on']} form one size group"
            return f"{v['closest_on']} only {v['separation_sd']} sd apart"
        for (i, j), v in twin_pairs.items():
            for k, o in ((i, j), (j, i)):
                if v["separable"]:
                    note.setdefault(k, f"near-identical to A{o}: told apart by step size")
                else:
                    g = group_of[k]
                    others = ", ".join(m for m in g.split("+") if m != f"A{k}")
                    note[k] = (f"identity mixed with {others}: {_why(v)} -- sizes reliable, which of them runs "
                               f"when is not (use their sum, column {g}_kW)")
        table["twin_note"] = [note.get(i) for i in ids]
        table["possible_hidden_units"] = [hidden.get(i) for i in ids]
        ao = {int(k[1:]): v for k, v in (base_floor.get("always_on") or {}).items()}
        if ao:
            table["twin_note"] = [((n_ + "; ") if isinstance(n_, str) else "") +
                                  f"never stops (on {ao[i]:.0%} of the time): part of the always-on base level -- "
                                  f"possibly rack unit(s) that always run; its size may be a sum of units"
                                  if i in ao else n_ for i, n_ in zip(ids, table["twin_note"])]
        table.insert(2, "role", [(f"{timer[i]['role']}; every {timer[i]['period_h']} h"
                                  + (f" at {', '.join(timer[i]['clock'])}" if timer[i]["clock"] else ""))
                                 if i in timer else None for i in ids])
        # a compressor with capacity stages: its full load is the start step
        # plus every load step
        stage_of, groups = stages
        rated_of = {i: (r_["rated_kW"] if r_["rated_kW"] is not None and not pd.isna(r_["rated_kW"])
                        else r_["step_kW"]) for i, (_, r_) in zip(ids, table.iterrows())}
        mods = mod_info[0]
        # a measured continuous loading beats inferred capacity steps (a
        # stray small load can pass as a "step" of a modulating screw)
        table["full_load_kW"] = [mods[i]["full_load_kW"] if i in mods else
                                 round(float(rated_of[i] + sum(kw * n for kw, n, _ in groups[i])), 2)
                                 if i in groups else None for i in ids]
        if mods:
            table["type"] = [("capacity-modulated compressor (slide valve?): start step is minimum load, "
                              f"loads up by up to {mods[i]['rise_max_kW']} kW") if i in mods else t_
                             for i, t_ in zip(ids, table["type"])]
        table["capacity_steps"] = [" + ".join([f"{rated_of[i]:.1f}"] + [f"{n} x {kw:.1f}" for kw, n, _ in groups[i]])
                                   if i in groups else None for i in ids]
    cap = capacitor_bank(qsteps, data, cfg)
    res["capacitor_bank"] = cap
    res["timer_loads"] = {f"A{k}": v for k, v in timer.items()}
    res["capacity_stages"] = {f"A{k}": f"A{v}" for k, v in stage_of.items()}
    if cap:
        table = pd.concat([table, pd.DataFrame([{
            "appliance": "C1", "category": "power-factor correction",
            "type": f"capacitor bank: {cap['stages_seen']} stage(s) regularly switched x {cap['stage_kvar']} kvar",
            "units": cap["stages_seen"], "rated_kvar": -cap["stage_kvar"], "step_kvar": -cap["stage_kvar"],
            "step_kW": cap["dP_per_stage_kW"], "starts_per_day": cap["switchings_per_day"],
            "reliability": f"{cap['share_fitting_stage']:.0%} of reactive steps fit whole stages"}])],
            ignore_index=True)
    if carried:
        table = pd.concat([table, pd.DataFrame(carried)], ignore_index=True)
    res["appliance_table"] = table.to_dict(orient="records")
    if cfg.get("output_dir"):
        res["output_files"] = export_results(table, tr, apps, states, c_est, data, cfg, rack, res)
    if verbose and not evaluate:
        print(f"--- {label} [real-data mode: no ground truth, nothing scored]")
        for w in res["input"].get("warnings", []):
            print(f"  warning: {w}")
        print(f"  events={len(events)} appliances={len(apps)} rack compensation detected="
              f"{bool(rack and rack.get('detected'))}  runtime={res['runtime_s']['total']:.1f}s")
        cols = ["appliance", "category", "role", "type", "units", "rated_kW", "full_load_kW", "step_kW", "power_factor", "temp_slope_kW_per_C",
                "duty_cycle", "starts_per_day", "on_min_median", "reliability", "variable_speed_suspected"]
        print(table[[c for c in cols if c in table.columns]].to_string(index=False))
        for _, r_ in table.iterrows():
            if isinstance(r_.get("twin_note"), str):
                print(f"  {r_['appliance']}: {r_['twin_note']}")
        if res.get("humidity_check") or res.get("duty_vs_weather"):
            print(f"  humidity ({res['input'].get('humidity_source')}; covariate {res['input'].get('covariate')}):")
            for r_ in res.get("humidity_check") or []:
                if "humidity_p" in r_:
                    print(f"    step  {r_['appliance']}: {r_['verdict']} (effect over IQR "
                          f"{r_['humidity_effect_over_iqr_pct_of_step']} % of the step, p = {r_['humidity_p']:.2g})")
            for r_ in res.get("duty_vs_weather") or []:
                if "humidity_p" in r_ and r_.get("controllable_candidate"):
                    print(f"    duty  {r_['appliance']}: {r_['verdict']} (R2 {r_['T_only_r2']} -> {r_['T_humidity_r2']}, "
                          f"humidity p = {r_['humidity_p']:.2g}, daily corr(T, humidity) = {r_['corr_T_humidity_daily']})")
        bf = res.get("base_floor") or {}
        lv = bf.get("level") or {}
        if lv:
            print(f"  non-switching level (meter minus every switching appliance, 15-min medians): {lv['p5_kW']} - "
                  f"{lv['p95_kW']} kW (median {lv['median_kW']}, Q/P {lv.get('qp')})"
                  + (f", follows ambient at {lv['ambient_slope_kW_per_C']} kW/degC (r = {lv['ambient_r']})"
                     if "ambient_slope_kW_per_C" in lv else "")
                  + ". Variable-speed compressors that never stop are inside this level together with fans, pumps "
                    "and the building's load; one meter cannot split them -- ask for the drives' ratings.")
        units_of = dict(zip(table["appliance"], table["units"])) if "units" in table else {}
        for k, v in (res.get("possible_hidden_units") or {}).items():
            if v:
                if (units_of.get(k) or 1) > 1:
                    print(f"  {k}: rack of {units_of[k]} units found; up to {v} more of these units could run all "
                          f"the time inside the always-on base level ({bf.get('floor_kW')} kW, "
                          f"{bf.get('floor_kvar')} kvar) -- the unit count is {units_of[k]} to {units_of[k] + v}")
                else:
                    print(f"  {k}: the always-on base level ({bf.get('floor_kW')} kW, {bf.get('floor_kvar')} kvar) "
                          f"could also hold up to {v} compressor(s) of this size that never stop")
        for k, v in res.get("lagging_parts", {}).items():
            print(f"  {k}: lagging part (evaporator fan?) of {v['tail_kW']} kW stops after the compressor in "
                  f"{v['followup_share']:.0%} of {v['pairs']} cycles; rated_kW is without it")
        if res.get("output_files"):
            print(f"  wrote {len(res['output_files'])} files to {cfg['output_dir']}")
    if verbose and evaluate:
        g, m = res["greedy_f1"], res["mapped_f1"]
        short = lambda c: c.replace("gt_", "").replace("_power_kW", "").replace("_defrost_kW", "d")
        print(f"--- {label}")
        print(f"  events={len(events)} appliances={len(apps)} seeds={len(seeds)} "
              f"dup_identities={res['n_duplicate_identities']} stats={tr.stats}")
        print("  greedy " + " ".join(f"{short(c)}={g[c]:.3f}" for c in g)
              + f"  comp mean {res['greedy_mean_comp']:.3f}")
        print("  mapped " + " ".join(f"{short(c)}={m[c]:.3f}" for c in m)
              + f"  comp mean {res['mapped_mean_comp']:.3f}")
        cc = res["continuous"]
        print(f"  continuous MAE={cc['mae_kw']:.1f} kW corr={cc['corr']:.3f}  "
              f"stable={res['n_stable']}/{res['n_matches']}  runtime={res['runtime_s']['total']:.2f}s")
    if return_tracker:
        return res, tr, events, data
    return res


def cli(argv=None):
    """
    Run on a meter file:

      python3 unilm_fhmm.py METER.csv --out results/ [--time COL] [--p COL] [--q COL]
                            [--ambient COL | --weather SMHI.csv] [--humidity SMHI_RH.csv | --rh COL]
                            [--covariate dry_bulb|wet_bulb|enthalpy] [--tz Europe/Stockholm]
                            [--unit auto|kW|W] [--resolution 60]

    Without arguments the built-in synthetic evaluation (CONFIG) runs.
    """
    import argparse
    ap = argparse.ArgumentParser(description="Disaggregate fixed-speed compressors from a 1 s P+Q meter series.")
    ap.add_argument("meter_file", help="CSV (',' or ';'), Excel or pickle with timestamp, P and Q columns")
    ap.add_argument("--out", required=True, help="output folder")
    ap.add_argument("--time", help="timestamp column (default: common names, case-insensitive)")
    ap.add_argument("--p", help="active power column")
    ap.add_argument("--q", help="reactive power column")
    ap.add_argument("--ambient", help="ambient temperature column in the meter file")
    ap.add_argument("--weather", help="separate ambient file: SMHI open-data export or a time,temperature CSV")
    ap.add_argument("--humidity", help="relative humidity: SMHI open-data export (Relativ Luftfuktighet) or a time,rh CSV")
    ap.add_argument("--rh", help="relative humidity column in the meter file")
    ap.add_argument("--covariate", default=CONFIG["magnitude_covariate"], choices=["dry_bulb", "wet_bulb", "enthalpy"],
                    help="what the step size follows: dry-bulb T (air-cooled condenser), wet-bulb T (evaporative or "
                         "adiabatic condenser) or air enthalpy; the last two need humidity")
    ap.add_argument("--tz", default=CONFIG["timestamp_timezone"],
                    help="time zone of timestamps written without one (default Europe/Stockholm)")
    ap.add_argument("--weather-tz", default=CONFIG["weather_timezone"],
                    help="time zone of a plain weather file's timestamps (SMHI is always UTC)")
    ap.add_argument("--unit", default="auto", choices=["auto", "kW", "W"], help="unit of P and Q (kvar or var)")
    ap.add_argument("--resolution", type=int, default=60, help="exported time-series resolution in seconds")
    ap.add_argument("--site", help="anonymised site code for compressor_hourly.csv / compressor_list.csv "
                                   "(default: the --out folder name)")
    ap.add_argument("--production", help="solar production (inverter or production meter) for the same site: "
                                         "time + kW (or kWh per interval) -- added back to P to get the real load")
    ap.add_argument("--dark-only", action="store_true",
                    help="no production data on a PV site: use only the hours when the sun is down")
    ap.add_argument("--lat", type=float, default=56.05, help="site latitude for --dark-only (default Helsingborg)")
    ap.add_argument("--lon", type=float, default=12.7, help="site longitude for --dark-only")
    ap.add_argument("--evaluate", action="store_true",
                    help="file contains synthetic ground-truth columns: also score against them")
    a = ap.parse_args(argv)
    cfg = copy.deepcopy(CONFIG)
    cfg.update(csv_path=a.meter_file, cache_pickle=None, output_dir=a.out, timestamp_timezone=a.tz,
               weather_timezone=a.weather_tz, power_unit=a.unit, output_resolution_s=a.resolution,
               weather_path=a.weather, production_path=a.production, dark_only=a.dark_only,
               site_lat=a.lat, site_lon=a.lon, site_code=a.site, humidity_path=a.humidity,
               magnitude_covariate=a.covariate)
    for key, val in (("timestamp_col", a.time), ("p_col", a.p), ("q_col", a.q),
                     ("magnitude_covariate_col", a.ambient), ("humidity_col", a.rh)):
        if val:
            cfg[key] = [val]
    if not a.evaluate:
        cfg["ground_truth_cols"], cfg["continuous_truth_cols"] = [], []
    return main(cfg, label=os.path.basename(a.meter_file))


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        cli()
    else:
        out = main(label="CONFIG")
        with open("unilm_fhmm_result.json", "w") as fh:
            json.dump(out, fh, indent=2, default=str)
