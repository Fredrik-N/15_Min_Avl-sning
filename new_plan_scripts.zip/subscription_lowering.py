"""
subscription_lowering.py -- how much could the monthly subscription level be
lowered with the pool's flexibility? (replaces the excess-e view of
subscription_value.py for the main result; uses its engine and settings)

No assumed excess. For each month m:
  1. P_m = highest hourly mean of the substation series (the measured value
     that sets the subscription; proxy until the real series is in place).
  2. Lower the level step by step (10 kW): level = P_m - x. Every hour above it
     must be cut to it, r_h = A_h - level. This is the FlexAbility approach:
     step the level down, sum the energy that must be cut.
  3. A step is covered if r_h <= the pool's offer in every hour above the level
     (firm level P10 for the slice month x hour x weekday/weekend and block
     length min(event length, 4) h, as in subscription_value.py).
  4. Proposed lowering d_m = the largest covered x. Proposed level = P_m - d_m.
  5. For d_m: hours above, events, longest event, energy to cut E (MWh),
     value = p_sub x d_m (SEK for the month; 40 SEK/kW by default) and
     break-even = value / E (SEK per delivered MWh; not a bid).
The FlexAbility need curve (energy against lowering) and break-even curve are
the two figures of subscription_value.py, with the proposed lowering of each
month marked; they are drawn here too.

Sensitivities (same cases as subscription_value.py): f 0.3 / 1.0, P5 / P20,
p_sub 30 / 50, forecast margin 5 % of peak.

Outputs (subscription_lowering_out/):
  subscription_lowering_monthly.csv   case x month
  subscription_lowering_summary.csv   per case: sum over months
  subscription_lowering_table.tex     base case, LaTeX booktabs
  fig_need_energy / fig_breakeven     PNG + PDF
  subscription_lowering_header.txt    series, f, percentile, blocks, price, checks
"""
import os

import numpy as np
import pandas as pd

import subscription_value as SV

CONFIG = dict(SV.CONFIG)
CONFIG.update({
    "output_dir": "subscription_lowering_out",
    "value_basis": "level",               # value = p_sub x d (a lower subscription)
    "max_lowering_kw": None,              # None = up to the peak; or a cap in kW
})


def proposal(md, case, offer, cfg):
    row = {"case": case["name"], "month": md.month, "P_m_kW": md.peak, "hours_in_data": md.n}
    if md.n == 0:
        row["note"] = "no data"
        return row
    step = cfg["step_kw"]
    cap = int((md.peak - 1e-9) // step) * step
    if cfg.get("max_lowering_kw"):
        cap = min(cap, cfg["max_lowering_kw"])
    margin = case["margin_share"] * md.peak
    d = SV.largest_reduction(md, cap, margin, offer, cfg) if cap > 0 else 0.0
    level = md.peak - d
    idx, groups = SV._events(md, level - margin)
    lens = [len(g) for g in groups] if d > 0 else []
    E = SV.need_mwh(md, level - margin) if d > 0 else 0.0
    value = SV.value_factor(cfg) * case["p_sub"] * d
    # what stops a further step: first uncovered hour at d + step
    stop = ""
    if d + step <= cap:
        lv = md.peak - d - step - margin
        i2, g2 = SV._events(md, lv)
        for g in g2:
            b = SV._block(len(g), cfg)
            for k in g:
                i = i2[k]
                o = offer.get((b, md.month, int(md.hour[i]), str(md.dt[i])), 0.0)
                if md.vals[i] - lv > o + 1e-9:
                    stop = (f"{pd.Timestamp(int(md.th[i]) * 3600, unit='s'):%Y-%m-%d %H}:00, "
                            f"event {len(g)} h: needs {md.vals[i] - lv:.0f} kW, offer {o:.0f} kW")
                    break
            if stop:
                break
    elif d > 0:
        stop = "reached the cap"
    row.update({"proposed_lowering_kW": d, "proposed_level_kW": level, "lowering_share_of_peak": d / md.peak,
                "hours_above": len(idx) if d > 0 else 0, "events": len(lens), "longest_event_h": max(lens) if lens else 0,
                "events_beyond_4h": sum(1 for L in lens if L > cfg["max_block_h"]), "E_MWh": E,
                "value_SEK": value, "breakeven_SEK_per_MWh": value / E if E > 0 else np.nan,
                "pool_firm_at_peak_hour_kW": offer.get((1, md.month, int(md.hour[md.i_peak]), str(md.dt[md.i_peak]))),
                "limited_by": stop, "note": ""})
    return row


def latex(cfg, t, base):
    M = SV.MONTHS
    lines = [r"\begin{table}[htbp]", r"\centering",
             rf"\caption{{Proposed lowering of the monthly subscription level with the pool's flexibility, {cfg['year']}. "
             rf"Series: {cfg['series_label']}. $P_m$ is the monthly peak (highest hourly mean), $d$ the largest lowering "
             rf"(10~kW steps) at which the pool's firm level ({base['pct']}, f = {base['f']:g}, {cfg['source_label']} data) covers "
             rf"every hour above the new level, $E$ the energy cut. Value = {base['p_sub']:g}~SEK/kW $\times$ $d$; the "
             rf"break-even price is the value divided by $E$.}}",
             r"\label{tab:subscription_lowering}", r"\begin{tabular}{lrrrrrrr}", r"\toprule",
             r"Month & $P_m$ (kW) & $d$ (kW) & New level (kW) & Hours & $E$ (MWh) & Value (SEK) & Break-even (SEK/MWh) \\",
             r"\midrule"]
    for _, r in t.iterrows():
        if pd.isna(r.get("proposed_lowering_kW")):
            lines.append(f"{M[int(r['month']) - 1]} & \\multicolumn{{7}}{{l}}{{no data}} \\\\")
            continue
        lines.append(f"{M[int(r['month']) - 1]} & {SV.fmt(r['P_m_kW'])} & {SV.fmt(r['proposed_lowering_kW'])} & "
                     f"{SV.fmt(r['proposed_level_kW'])} & {int(r['hours_above'])} & {SV.fmt(r['E_MWh'], 1)} & "
                     f"{SV.fmt(r['value_SEK'])} & {SV.fmt(r['breakeven_SEK_per_MWh'])} \\\\")
    v, E = t["value_SEK"].sum(), t["E_MWh"].sum()
    lines += [r"\midrule", f"Year & -- & -- & -- & {int(t['hours_above'].sum())} & {SV.fmt(E, 1)} & {SV.fmt(v)} & "
              f"{SV.fmt(v / E if E > 0 else np.nan)} \\\\", r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    with open(os.path.join(cfg["output_dir"], "subscription_lowering_table.tex"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def main(cfg=CONFIG):
    os.makedirs(cfg["output_dir"], exist_ok=True)
    a, clipped = SV.read_series(cfg)
    cases, offers = SV.build_cases(cfg, SV.read_pool(cfg))
    mds = {m: SV.Month(m, a, cfg) for m in range(1, 13)}
    rows = []
    for c in cases:
        for m, md in mds.items():
            r = proposal(md, c, offers[c["name"]], cfg)
            r.update({"f": c["f"], "percentile": c["pct"], "source": cfg["source_label"], "series": cfg["series_label"],
                      "proxy_flag": "proxy" if cfg["series_is_proxy"] else "actual", "p_sub": c["p_sub"],
                      "forecast_margin_share": c["margin_share"], "block_lengths_h": "/".join(map(str, cfg["blocks_h"])),
                      "n_pool_sites": c.get("n_sites"), "hours_clipped": int(clipped.get(m, 0))})
            rows.append(r)
    D = pd.DataFrame(rows)
    SV.write(D.round(3), cfg, "subscription_lowering_monthly.csv")
    S = D.groupby("case", sort=False).agg(months=("proposed_lowering_kW", "count"),
                                           months_with_lowering=("proposed_lowering_kW", lambda s: int((s > 0).sum())),
                                           mean_lowering_kW=("proposed_lowering_kW", "mean"),
                                           min_lowering_kW=("proposed_lowering_kW", "min"),
                                           max_lowering_kW=("proposed_lowering_kW", "max"),
                                           E_MWh=("E_MWh", "sum"), value_SEK=("value_SEK", "sum")).reset_index()
    S["breakeven_SEK_per_MWh"] = np.where(S["E_MWh"] > 0, S["value_SEK"] / S["E_MWh"], np.nan)
    SV.write(S.round(3), cfg, "subscription_lowering_summary.csv")

    base = cases[0]
    t = D[D["case"] == "base"].sort_values("month")
    latex(cfg, t, base)
    # FlexAbility curves with the proposal marked
    off = offers["base"]
    cur = []
    for m, md in mds.items():
        for x in cfg["curve_e_kw"]:
            if md.n and x < md.peak:
                cur.append({"month": m, "e_kW": x, "E_MWh": SV.need_mwh(md, md.peak - x)})
    curves = pd.DataFrame(cur)
    lim = t.rename(columns={"proposed_lowering_kW": "d_max_kW", "E_MWh": "E_at_d_max_MWh"})[["month", "d_max_kW", "E_at_d_max_MWh"]]
    lim = lim.fillna({"d_max_kW": 0.0, "E_at_d_max_MWh": 0.0})
    SV.fig_need(cfg, curves, lim, mds, base)
    SV.fig_breakeven(cfg, mds, lim, base)

    checks = []
    if (D["proposed_lowering_kW"] > D["P_m_kW"]).any():
        checks.append("FAIL lowering > peak")
    if ((D["proposed_lowering_kW"] == 0) & (D["value_SEK"] != 0)).any():
        checks.append("FAIL value with no lowering")
    if not np.isclose(S.loc[S["case"] == "base", "value_SEK"].iloc[0], t["value_SEK"].sum()):
        checks.append("FAIL annual value is not the sum of the months")
    checks = checks or ["all checks passed: d <= P_m; value = 0 when d = 0; annual sum = sum of months"]
    head = [
        "subscription_lowering.py -- header of this run",
        f"series: {cfg['series_label']} ({'proxy' if cfg['series_is_proxy'] else 'actual'}), {cfg['proxy_csv']}, {cfg['year']}; "
        f"negative hours clipped to 0: {int(clipped.sum())}",
        f"pool: {cfg['pool_levels_csv']}; {cfg['source_label']}; f = {base['f']:g}; level {base['pct']}; blocks {cfg['blocks_h']} h; "
        f"sites: {base.get('n_sites')}",
        f"lowering: step {cfg['step_kw']} kW, perfect foresight, every hour above the new level cut to it; cap {cfg.get('max_lowering_kw')}",
        f"value: {base['p_sub']:g} SEK per kW and month of lowering (value_basis {cfg['value_basis']}); break-even = value / energy cut",
        "figures: fig_need_energy -- energy to cut against lowering per month (FlexAbility Figure 8 analogue), circle = proposed "
        "lowering; fig_breakeven -- break-even price against lowering, solid = covered by the pool, dotted = beyond it",
        "checks: " + "; ".join(checks),
    ]
    with open(os.path.join(cfg["output_dir"], "subscription_lowering_header.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(head) + "\n")
    print(t[["month", "P_m_kW", "proposed_lowering_kW", "proposed_level_kW", "hours_above", "E_MWh", "value_SEK",
             "breakeven_SEK_per_MWh", "limited_by"]].round(1).to_string(index=False))
    print(S[["case", "mean_lowering_kW", "value_SEK"]].round(1).to_string(index=False))
    print("\n".join(checks))
    print(f"[lower] outputs in {os.path.abspath(cfg['output_dir'])}")


if __name__ == "__main__":
    main()
