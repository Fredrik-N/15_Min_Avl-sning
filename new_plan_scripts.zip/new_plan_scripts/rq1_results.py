"""
rq1_results.py -- the RQ1 results in one place (run after offerable_flex.py
and figures.py). Site names as in the outputs (lpc_11.site_label).

1. rq1_heatmap_check.txt
   Why the heatmap range differs from the per-site season table: lists the
   pool's sites, the f values present, duplicate rows in reducible_power.csv,
   the min / max heatmap cell per f and day type, the pool's season median
   and P10 over all hours, the sum of the sites' season medians (the
   tab_p15_by_season numbers) and, at the highest cell, each site's share.
2. rq1_numbers.csv / rq1_numbers.tex  (\\newcommand macros for the text)
   firm-level range over the heatmap cells, share of hours the pool reaches
   0.1 MW, sites needed, pool firm level per f, drop from 1 h to 4 h blocks,
   pool without D / without the smallest, stand-alone sites, rebound.
3. Tables (booktabs): tab_rq1_sites (typical, firm, class per site and
   season), tab_rq1_pool (pool firm level per f, block and season),
   tab_rq1_variants, tab_rq1_rebound.
Every table states f, block length and percentile in its caption.
"""
import os
import sys

import numpy as np
import pandas as pd


def lpc_seasons(default):
    """The season definition shared by every script: lpc_11 CONFIG["seasons"]
    (winter Nov-Feb, summer Jun-Aug, shoulder Mar-May + Sep-Oct). Seasons
    only SUMMARISE results; every calculation is per month or per hour."""
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import lpc_11
        return {k: list(v) for k, v in lpc_11.CONFIG["seasons"].items()}
    except Exception:
        return default

CONFIG = {
    "reducible_csv": os.path.join("reducible_power_out", "reducible_power.csv"),
    "offer_dir": "offerable_flex_out",
    "output_dir": "rq1_out",
    "f": 0.5,                       # main f
    "block_h": 1,                   # main block length
    "day_type": "all",              # heatmap the range is read from: all days of the week together
    "lfm_min_kw": 100.0,
    "seasons": ["winter", "shoulder", "summer", "year"],
    "csv_sep": ";",
    "csv_decimal": ",",
}


def rd(cfg, name, folder=None):
    p = os.path.join(folder or cfg["offer_dir"], name) if not os.path.isabs(name) and folder != "" else name
    if not os.path.exists(p):
        print(f"[rq1] {p} not found -- skipped")
        return None
    d = pd.read_csv(p, sep=cfg["csv_sep"], decimal=cfg["csv_decimal"], encoding="utf-8-sig")
    if "f" in d:
        d["f"] = pd.to_numeric(d["f"], errors="coerce")
    return d


def isf(s, f):
    return np.isclose(s.astype(float).fillna(-1), f)


def num(x, d=0):
    return "--" if x is None or (isinstance(x, float) and not np.isfinite(x)) else f"{x:,.{d}f}".replace(",", r"\,")


def esc(x):
    return str(x).replace("_", r"\_").replace("%", r"\%").replace("&", r"\&")


def table(cfg, name, caption, label, colspec, head, body):
    t = [r"\begin{table}[htbp]", r"\centering", r"\small", rf"\caption{{{caption}}}", rf"\label{{tab:{label}}}",
         rf"\begin{{tabular}}{{{colspec}}}", r"\toprule", *head, r"\midrule", *body, r"\bottomrule",
         r"\end{tabular}", r"\end{table}"]
    with open(os.path.join(cfg["output_dir"], name), "w", encoding="utf-8") as fh:
        fh.write("\n".join(t) + "\n")


# ----------------------------------------------------------------------
def heatmap_check(cfg, red, pl, ph, ol):
    out = []
    w = out.append
    f0, L0 = cfg["f"], cfg["block_h"]
    w("RQ1 heatmap check")
    w("=" * 60)
    if red is not None:
        r15 = red[red["source"] == "15 min"]
        w(f"sites in reducible_power.csv: {sorted(red['site'].astype(str).unique())} "
          f"({red['site'].nunique()})")
        w(f"f values: {[float(v) for v in sorted(r15['f'].dropna().unique())]}")
        dup = red.duplicated(["site", "hour", "source", "f"]).sum()
        w(f"duplicate (site, hour, source, f) rows: {dup}" + ("  <-- these are summed into the pool twice" if dup else ""))
        for c in ("base_hours", "base_period"):
            if c in red:
                w(f"{c}: {sorted(red[c].dropna().astype(str).unique())}")
    if ph is not None:
        x = ph[isf(ph["f"], f0) & (ph["block_h"] == L0)]
        w(f"pool sites (pool_hourly n_sites): {[int(v) for v in sorted(x['n_sites'].unique())]}")
    w("")
    if pl is not None:
        for f in sorted(pl["f"].dropna().unique()):
            for dt in (cfg["day_type"],):
                g = pl[isf(pl["f"], f) & (pl["block_h"] == L0) & (pl["day_type"] == dt)]
                if g.empty:
                    continue
                fk = [c for c in g if c.startswith("firm_P")][0]
                tk = [c for c in g if c.startswith("typical_P")][0]
                mx = g.loc[g[fk].idxmax()]
                w(f"heatmap f={f:g} {L0} h {dt}: firm {g[fk].min():.0f}-{g[fk].max():.0f} kW, typical "
                  f"{g[tk].min():.0f}-{g[tk].max():.0f} kW; highest firm cell month {int(mx['month'])} hour "
                  f"{int(mx['hour_of_day'])} ({int(mx['n_hours'])} hours in the cell)")
    w("")
    if ph is not None:
        x = ph[isf(ph["f"], f0) & (ph["block_h"] == L0)].copy()
        x["hour"] = pd.to_datetime(x["hour"])
        som = {m: s for s, ms in lpc_seasons({"winter": [11, 12, 1, 2], "summer": [6, 7, 8], "shoulder": [3, 4, 5, 9, 10]}).items() for m in ms}
        x["season"] = x["hour"].dt.month.map(som)
        g = x.groupby("season")["pool_kw"].agg(median="median", P10=lambda v: v.quantile(0.1), max="max")
        w(f"pool over ALL hours of the season, f={f0:g}, {L0} h (kW):")
        w(g.round(0).to_string())
    if red is not None:
        r = red[(red["source"] == "15 min") & isf(red["f"], f0)]
        m = r.groupby(["season", "site"])["kW"].median().groupby("season").sum()
        w("")
        w(f"sum of the sites' season medians (tab_p15_by_season, f={f0:g}) (kW):")
        w(m.round(0).to_string())
    if pl is not None and ol is not None:
        g = pl[isf(pl["f"], f0) & (pl["block_h"] == L0) & (pl["day_type"] == cfg["day_type"])]
        if len(g):
            fk = [c for c in g if c.startswith("firm_P")][0]
            mx = g.loc[g[fk].idxmax()]
            o = ol[(isf(ol["f"], f0) | ol["f"].isna()) & (ol["block_h"] == L0) & (ol["month"] == mx["month"])
                   & (ol["hour_of_day"] == mx["hour_of_day"]) & (ol["day_type"] == cfg["day_type"])]
            if len(o):
                o = o[["site", fk]].sort_values(fk, ascending=False)
                o["share_of_sum"] = (o[fk] / o[fk].sum()).round(2)
                w("")
                w(f"sites at the highest cell ({'all days' if cfg['day_type'] == 'all' else cfg['day_type']}, "
                  f"month {int(mx['month'])}, hour "
                  f"{int(mx['hour_of_day'])}), each site's own P10 in that cell:")
                w(o.round(1).to_string(index=False))
    w("")
    w("Reading: a heatmap cell is the P10 of ONE month x hour slice over all days of the week (about 30 "
      "days), so it follows the daily profile; a season median over all hours includes the night hours and "
      "is lower. A pool cell can therefore lie well above the season figures without an error. An error is "
      "indicated by: more pool sites than intended, an f other than the one in the table, or duplicate rows.")
    txt = "\n".join(out)
    with open(os.path.join(cfg["output_dir"], "rq1_heatmap_check.txt"), "w", encoding="utf-8") as fh:
        fh.write(txt + "\n")
    print(txt)


# ----------------------------------------------------------------------
def numbers(cfg, pl, nd, vr, cl, rb):
    f0, L0 = cfg["f"], cfg["block_h"]
    n = {}
    if pl is not None:
        g = pl[isf(pl["f"], f0) & (pl["block_h"] == L0) & (pl["day_type"] == cfg["day_type"])]
        fk = [c for c in pl if c.startswith("firm_P")][0]
        if len(g):
            n["FirmMin"], n["FirmMax"] = g[fk].min(), g[fk].max()
            n["ShareCellsFirmAboveLfm"] = 100 * (g[fk] >= cfg["lfm_min_kw"]).mean()
    if nd is not None:
        y = nd[(nd["season"] == "year")]
        a = y[isf(y["f"], f0) & (y["block_h"] == L0)]
        if len(a):
            n["ShareHoursPool"] = 100 * a["share_hours_pool_ge_0_1MW"].iloc[0]
            n["SitesNeeded"] = a["sites_needed_for_firm_0_1MW"].iloc[0]
            n["PoolFirmYear"] = a["pool_firm_P10_kw"].iloc[0]
        for f, nm in ((0.3, "Low"), (0.5, "Mid"), (1.0, "High")):
            b = y[isf(y["f"], f) & (y["block_h"] == L0)]
            if len(b):
                n[f"PoolFirmF{nm}"] = b["pool_firm_P10_kw"].iloc[0]
                n[f"ShareHoursF{nm}"] = 100 * b["share_hours_pool_ge_0_1MW"].iloc[0]
        b1 = y[isf(y["f"], f0) & (y["block_h"] == 1)]
        b4 = y[isf(y["f"], f0) & (y["block_h"] == 4)]
        if len(b1) and len(b4):
            n["FirmOneH"], n["FirmFourH"] = b1["pool_firm_P10_kw"].iloc[0], b4["pool_firm_P10_kw"].iloc[0]
            n["DropOneToFourPct"] = 100 * (1 - n["FirmFourH"] / n["FirmOneH"]) if n["FirmOneH"] else np.nan
    if vr is not None:
        y = vr[(vr["season"] == "year") & isf(vr["f"], f0) & (vr["block_h"] == L0)]
        for name, key in (("without_D", "NoD"), ("without_3_smallest", "NoSmall")):
            r = y[y["variant"] == name]
            if len(r):
                n[f"Firm{key}"] = r["firm_P10_kw"].iloc[0]
                n[f"Change{key}Pct"] = r["firm_change_vs_all_pct"].iloc[0]
                n[f"ShareHours{key}"] = 100 * r["share_hours_ge_0_1MW"].iloc[0]
                n[f"LeftOut{key}"] = r["left_out"].iloc[0]
    if cl is not None:
        c = cl[(cl["season"] == "year") & (isf(cl["f"], f0) | cl["f"].isna()) & (cl["block_h"] == L0)]
        n["SitesStandAlone"] = int((c["class"] == "stand-alone").sum())
        n["SitesPoolCandidate"] = int((c["class"] == "pool candidate").sum())
        n["SitesNotRelevant"] = int((c["class"] == "not relevant").sum())
    if rb is not None:
        p = rb[(rb["unit"] == "pool") & (rb["season"] == "year") & isf(rb["f"], f0)]
        for L, key in ((1, "One"), (4, "Four")):
            r = p[p["block_h"] == L]
            if len(r):
                n[f"RecoveryMedian{key}H"] = r["rebound_median_recovery_h"].iloc[0]
                n[f"RecoveryPninety{key}H"] = r["rebound_P90_recovery_h"].iloc[0]
    rows = [{"name": k, "value": v} for k, v in n.items()]
    pd.DataFrame(rows).to_csv(os.path.join(cfg["output_dir"], "rq1_numbers.csv"), sep=cfg["csv_sep"],
                              decimal=cfg["csv_decimal"], index=False, encoding="utf-8-sig")
    lines = [f"% RQ1 numbers, f = {f0:g}, {L0} h blocks unless the name says otherwise; firm = P10. "
             f"Written by rq1_results.py -- do not edit by hand."]
    for k, v in n.items():
        if isinstance(v, (int, np.integer)) or (isinstance(v, str)):
            s = esc(v)
        elif k.endswith("Pct") or k.startswith(("Share",)):
            s = num(float(v), 0)
        elif "Recovery" in k:
            s = num(float(v), 0)
        else:
            s = num(float(v), 0)
        lines.append(rf"\newcommand{{\RQone{k}}}{{{s}}}")
    with open(os.path.join(cfg["output_dir"], "rq1_numbers.tex"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines))


# ----------------------------------------------------------------------
def tables(cfg, cl, nd, vr, rb, red):
    f0, L0 = cfg["f"], cfg["block_h"]
    S = cfg["seasons"]
    pvnet = set()
    if red is not None and "pv_flag" in red:
        r = red[red["source"] == "15 min"]
        g = r.groupby("site").agg(pv=("pv_flag", lambda x: x.astype(str).str.lower().isin(["true", "1"]).any()),
                                  series=("series", "first"))
        pvnet = set(g[g["pv"] & g["series"].astype(str).str.startswith("net")].index.astype(str))
    ab = {"stand-alone": "S", "pool candidate": "P", "not relevant": "--", "n/a": "n/a"}
    if cl is not None:
        c = cl[(isf(cl["f"], f0) | cl["f"].isna()) & (cl["block_h"] == L0)]
        body = []
        for site in sorted(c["site"].astype(str).unique()):
            cells = []
            for se in S:
                r = c[(c["site"].astype(str) == site) & (c["season"] == se)]
                if len(r):
                    r = r.iloc[0]
                    cells += [num(r["typical_P50_kw"]), num(r["firm_P10_kw"]), ab.get(r["class"], "--")]
                else:
                    cells += ["--"] * 3
            body.append(esc(site) + (r"$^{\dagger}$" if site in pvnet else "") + " & " + " & ".join(cells) + r" \\")
        head = [" & " + " & ".join(rf"\multicolumn{{3}}{{c}}{{{s.capitalize()}}}" for s in S) + r" \\",
                "".join(rf"\cmidrule(lr){{{2 + 3 * i}-{4 + 3 * i}}}" for i in range(len(S))),
                "Site & " + " & ".join(["P50", "P10", "Cl."] * len(S)) + r" \\"]
        table(cfg, "tab_rq1_sites.tex",
              rf"Typical (P50) and firm (P10) offerable power per site and season (kW), {L0}-hour blocks, "
              rf"$f={f0:g}$ for 15-minute sites. Class against the firm level: S = stand-alone ($\geq 100$\,kW), "
              rf"P = pool candidate ($\geq 10$\,kW), -- = not relevant."
              + (r" $^{\dagger}$ PV on site, net load: daytime values in Mar--Sep are a lower bound." if pvnet else ""),
              "rq1_sites", "l" + "rrc" * len(S), head, body)
    if nd is not None:
        body = []
        for f in sorted(nd["f"].dropna().unique()):
            for L in sorted(nd["block_h"].unique()):
                g = nd[isf(nd["f"], f) & (nd["block_h"] == L)].set_index("season")
                cells = [num(g["pool_firm_P10_kw"].get(s, np.nan)) for s in S]
                cells.append(num(100 * g["share_hours_pool_ge_0_1MW"].get("year", np.nan)))
                cells.append(esc(g["sites_needed_for_firm_0_1MW"].get("year", "--")))
                body.append(f"{f:g} & {L} & " + " & ".join(cells) + r" \\")
            body.append(r"\addlinespace")
        n_sites = int(nd["n_sites_available"].iloc[0])
        table(cfg, "tab_rq1_pool.tex",
              rf"Firm level (P10) of the pool of {n_sites} sites by $f$, block length and season (kW); share of "
              r"hours the pool reaches 0.1\,MW over the year, and the number of sites needed for a firm 0.1\,MW "
              r"(added in order of their firm level).",
              "rq1_pool", "rr" + "r" * len(S) + "rr",
              [r"$f$ & Block (h) & " + " & ".join(s.capitalize() for s in S) + r" & Hours $\geq$ 0.1\,MW (\%) & Sites \\"],
              body[:-1])
    if vr is not None:
        v = vr[isf(vr["f"], f0) & (vr["block_h"] == L0)]
        body = []
        for name in v["variant"].drop_duplicates():
            g = v[v["variant"] == name].set_index("season")
            lo = g["left_out"].iloc[0]
            lo = "--" if (not isinstance(lo, str) or not lo.strip()) else lo
            cells = [esc(lo), str(int(g["n_sites"].iloc[0]))] + [num(g["firm_P10_kw"].get(s, np.nan)) for s in S]
            cells += [num(g["firm_change_vs_all_pct"].get("year", np.nan)),
                      num(100 * g["share_hours_ge_0_1MW"].get("year", np.nan))]
            body.append(esc(name.replace("_", " ")) + " & " + " & ".join(cells) + r" \\")
        table(cfg, "tab_rq1_variants.tex",
              rf"Pool firm level (P10, kW) with sites left out, {L0}-hour blocks, $f={f0:g}$. Change and share "
              r"of hours $\geq$ 0.1\,MW over the year.",
              "rq1_variants", "llr" + "r" * len(S) + "rr",
              [r"Pool & Left out & Sites & " + " & ".join(s.capitalize() for s in S)
               + r" & Change (\%) & Hours $\geq$ 0.1\,MW (\%) \\"], body)
    if rb is not None:
        r = rb[isf(rb["f"], f0) & (rb["season"] == "year")]
        Ls = sorted(r["block_h"].unique())
        body = []
        units = [u for u in sorted(r["site"].astype(str).unique()) if u != "pool"] + \
                (["pool"] if (r["site"].astype(str) == "pool").any() else [])
        for u in units:
            cells = []
            for L in Ls:
                x = r[(r["site"].astype(str) == u) & (r["block_h"] == L)]
                if len(x):
                    x = x.iloc[0]
                    cells += [num(x["rebound_median_recovery_h"]), num(x["rebound_P90_recovery_h"]),
                              num(100 * x["rebound_share_recovered_within_block_h"])]
                else:
                    cells += ["--"] * 3
            body.append((r"\midrule Pool" if u == "pool" else esc(u)) + " & " + " & ".join(cells) + r" \\")
        head = [" & " + " & ".join(rf"\multicolumn{{3}}{{c}}{{{L} h block}}" for L in Ls) + r" \\",
                "".join(rf"\cmidrule(lr){{{2 + 3 * i}-{4 + 3 * i}}}" for i in range(len(Ls))),
                "Site & " + " & ".join([r"Median (h)", r"P90 (h)", r"$\leq L$ (\%)"] * len(Ls)) + r" \\"]
        table(cfg, "tab_rq1_rebound.tex",
              rf"Rebound from 15-minute data, year, $f={f0:g}$: hours after a block until the moved energy "
              r"($P \cdot L$) fits under the headroom (the month's highest hourly load minus the load), and the "
              r"share of blocks recovered within the block's own length. -- = not recovered within 24\,h. "
              r"The headroom includes non-compressor load, so these are lower bounds.",
              "rq1_rebound", "l" + "rrr" * len(Ls), head, body)


def main(cfg=CONFIG):
    os.makedirs(cfg["output_dir"], exist_ok=True)
    red = rd(cfg, cfg["reducible_csv"], folder="")
    pl, ph, ol = rd(cfg, "pool_levels.csv"), rd(cfg, "pool_hourly.csv"), rd(cfg, "offer_levels.csv")
    nd, vr = rd(cfg, "pool_sites_needed.csv"), rd(cfg, "pool_variants.csv")
    cl, rb = rd(cfg, "offer_classification.csv"), rd(cfg, "rebound.csv")
    if pl is not None and not (pl["day_type"] == cfg["day_type"]).any():
        raise SystemExit(f"[rq1] pool_levels.csv has no day_type {cfg['day_type']!r} -- rerun offerable_flex.py "
                         f"(its CONFIG day_types must include it), e.g.  python run_all.py --from offer")
    heatmap_check(cfg, red, pl, ph, ol)
    print()
    numbers(cfg, pl, nd, vr, cl, rb)
    tables(cfg, cl, nd, vr, rb, red)
    print(f"[rq1] outputs in {os.path.abspath(cfg['output_dir'])}")


if __name__ == "__main__":
    main()
