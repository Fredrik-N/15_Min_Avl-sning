"""
offerable_flex.py -- offerable flexibility per site and for the pool, for every
hour of the year (script 6, core of the revised plan).

Input: reducible_power.csv (reducible_power.py). Per site the hourly
reducible power is P_1s where that hour exists, otherwise P_15 at the given f
(every hour's source is kept: column share_1s). A site with only 1 s data
has no f; it enters every f run with the same values.

1. Time slices: month x hour of day x day type. CONFIG["day_types"] picks
   which: "weekday", "weekend", "all" (every day of the week together) and
   the single days "Mon" ... "Sun" (about 4-5 days per month each, so their
   P10 is close to the lowest value). The classification shares always use
   weekday / weekend, so adding day types does not change any class.
2. Levels per site and slice: typical = P50, firm = P10; sensitivity P5, P20.
3. Blocks of 1, 2, 4 consecutive hours: offerable power of a block starting
   at hour h = the minimum hour in the block (an LFM bid is held as an hourly
   average).
   Rebound (15-min sites, from the load itself, no activations needed):
   headroom H(h) = highest hourly load of the site in that month (P100, or
   CONFIG["rebound"]["cap_percentile"]) minus the load in hour h. A block of
   L hours at power P moves E = payback_share * P * L kWh; the recovery time
   is the number of hours after the block until the summed headroom reaches
   E (at most max_hours; beyond that "not recovered"). The season's highest
   load stands in for the compressors' capacity, so the headroom includes
   any non-compressor peak: recovery times are a lower bound. 1 s sites have
   no load column here: rebound N/A for them and for a pool that holds them.
4. Classification per site, season (and year) and block length:
   stand-alone (firm >= 100 kW), pool candidate (firm >= pool_candidate_kw,
   default 10), not relevant. firm = P10 of the block power over the hours.
5. Pool: sites summed hour by hour (only hours where every pool site has a
   value), then the same percentiles. Share of hours with pool >= 0.1 MW, and
   the number of sites needed for a firm 0.1 MW when sites are added in order
   of their firm level.
6. Pool variants (CONFIG["pool_variants"]): the same pool statistics with
   sites left out -- by code ("exclude") or the n smallest by mean reducible
   power at f = rank_f ("exclude_smallest"; ties by code). Default: all,
   without D, without the 3 smallest. pool_variants*.csv.
Outputs: offer_levels.csv, offer_classification.csv, pool_levels.csv,
pool_sites_needed.csv, pool_hourly.csv (for figures.py), pool_monthly.csv and
site_monthly.csv (per calendar month over all hours: typical P50, firm P10,
share of hours >= 0.1 MW), rebound.csv, pool_variants.csv,
pool_variants_monthly.csv, pool_variants_hourly.csv. Every row records
source resolution, season, block length, percentile and f.
"""
import os
import sys

import numpy as np
import pandas as pd


def lpc_seasons(default):
    """The season definition shared by every script: lpc_11 CONFIG["seasons"]
    (winter Nov-Feb, summer Jun-Aug, shoulder Mar-May + Sep-Oct). Seasons
    only SUMMARISE results; every calculation is per month or per hour."""
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import lpc_11
        return {k: list(v) for k, v in lpc_11.CONFIG["seasons"].items()}
    except Exception:
        return default

CONFIG = {
    "input_csv": os.path.join("reducible_power_out", "reducible_power.csv"),
    "output_dir": "offerable_flex_out",
    "f_values": None,                 # None = every f in the input
    "blocks_h": [1, 2, 4],
    "levels": {"typical": 50, "firm": 10, "sens_P5": 5, "sens_P20": 20},
    "standalone_kw": 100.0,
    "pool_candidate_kw": 10.0,
    "lfm_min_kw": 100.0,              # 0.1 MW
    "pool_sites": "all",              # "all" or [site codes]
    "pool_variants": {                # name: {} | {"exclude": [codes]} | {"exclude_smallest": n} | {"sites": [codes]}
        "all": {},
        "without_D": {"exclude": ["D"]},
        "without_3_smallest": {"exclude_smallest": 3},
    },
    "rank_f": 0.5,                    # f at which "smallest" is ranked (mean reducible power over the year)
    "rebound": {"payback_share": 1.0,  # share of the moved energy that comes back after the block
                "cap_percentile": 100, # headroom cap = this percentile of the period's hourly load
                "cap_period": "month", # "month" (default) | "season"
                "max_hours": 24},      # look this far after the block
    "seasons": lpc_seasons({"winter": [11, 12, 1, 2], "summer": [6, 7, 8], "shoulder": [3, 4, 5, 9, 10]}),   # summaries only (lpc_11 CONFIG["seasons"])
    "weekend_days": [5, 6],
    "day_types": ["weekday", "weekend", "all", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    "csv_sep": ";",
    "csv_decimal": ",",
}


def read_input(cfg):
    d = pd.read_csv(cfg["input_csv"], sep=cfg["csv_sep"], decimal=cfg["csv_decimal"], encoding="utf-8-sig")
    d["hour"] = pd.to_datetime(d["hour"])
    return d


def site_series(d, f):
    """{site: DataFrame(kW, is_1s) on a regular hourly index}."""
    out = {}
    for site, g in d.groupby("site"):
        g15 = g[(g["source"] == "15 min") & np.isclose(g["f"].astype(float), f)]
        s15 = g15.groupby("hour")["kW"].mean()
        ld = g15.groupby("hour")["load_kw"].mean() if "load_kw" in g15 else pd.Series(dtype=float)
        s1 = g[g["source"] == "1 s"].groupby("hour")["kW"].mean()
        if s15.empty and s1.empty:
            continue
        idx = s15.index.union(s1.index)
        kw = s15.reindex(idx)
        is1 = pd.Series(False, index=idx)
        if len(s1):
            kw.loc[s1.index] = s1
            is1.loc[s1.index] = True
        full = pd.date_range(idx.min(), idx.max(), freq="1h")
        load = ld.reindex(idx)
        if len(s1):
            load.loc[s1.index] = np.nan            # no load for 1 s hours here
        out[site] = pd.DataFrame({"kW": kw.reindex(full), "is_1s": is1.reindex(full).fillna(False).astype(bool),
                                  "load_kw": load.reindex(full)})
    return out


def block_min(s, L):
    """Value at the block's start hour = min over the L hours from there
    (NaN if any hour of the block is missing)."""
    return s.rolling(L, min_periods=L).min().shift(-(L - 1))


def slice_keys(idx, cfg):
    dt = np.where(np.isin(idx.dayofweek, cfg["weekend_days"]), "weekend", "weekday")
    return pd.DataFrame({"month": idx.month, "hour_of_day": idx.hour, "day_type": dt}, index=idx)


def season_of(idx, cfg):
    som = {m: k for k, ms in cfg["seasons"].items() for m in ms}
    return pd.Series([som.get(m) for m in idx.month], index=idx)


DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def levels_table(x, is1, cfg, day_types=("weekday", "weekend")):
    """Percentile levels per slice (month x hour of day x day type) of one
    hourly block series. day_types: any of weekday, weekend, all, Mon..Sun."""
    df = slice_keys(x.index, cfg).assign(kW=x.to_numpy(), is1=is1.to_numpy()).dropna(subset=["kW"])
    unknown = set(day_types) - {"weekday", "weekend", "all", *DAY_NAMES}
    if unknown:
        raise SystemExit(f"[offer] unknown day_types {sorted(unknown)}; use weekday, weekend, all, Mon..Sun")
    parts = []
    if {"weekday", "weekend"} & set(day_types):
        parts.append(df[df["day_type"].isin(day_types)])
    if "all" in day_types:
        parts.append(df.assign(day_type="all"))
    names = [d for d in DAY_NAMES if d in day_types]
    if names:
        dn = np.array(DAY_NAMES)[df.index.dayofweek]
        parts.append(df.assign(day_type=dn)[np.isin(dn, names)])
    df = pd.concat(parts)
    g = df.groupby(["month", "hour_of_day", "day_type"])
    t = g["kW"].agg(n_hours="count")
    for name, p in cfg["levels"].items():
        t[f"{name}_P{p}_kw"] = g["kW"].quantile(p / 100)
    t["share_1s"] = g["is1"].mean()
    return t.reset_index()


def headroom(load, cfg):
    """H(h) = cap(month or season) - load(h), >= 0; cap = cap_percentile of the period's
    hourly load. NaN where the load is missing."""
    seas = season_of(load.index, cfg) if cfg["rebound"].get("cap_period", "month") == "season" else \
        pd.Series(load.index.month, index=load.index)
    q = cfg["rebound"]["cap_percentile"] / 100
    cap = load.groupby(seas.to_numpy()).quantile(q)
    return (seas.map(cap).astype(float) - load).clip(lower=0)


def recovery_hours(block, H, L, cfg):
    """Per block start: hours after the block until the summed headroom
    covers E = payback * block * L. NaN = not recovered within max_hours
    (missing headroom counts as none); blocks with E <= 0 are dropped."""
    E = cfg["rebound"]["payback_share"] * block.to_numpy() * L
    Hs = H.fillna(0).to_numpy()
    n, kmax = len(Hs), int(cfg["rebound"]["max_hours"])
    T = np.full(n, np.nan)
    S = np.zeros(n)
    for k in range(1, kmax + 1):
        j = np.arange(n) + L + k - 1
        add = np.where(j < n, Hs[np.minimum(j, n - 1)], 0.0)
        S += add
        hit = np.isnan(T) & (S >= E) & (j < n)
        T[hit] = k
    keep = np.isfinite(E) & (E > 0)
    return pd.Series(T, index=block.index)[keep]


def rebound_summary(T, L, cfg):
    if T is None or not len(T):
        return {"rebound_median_recovery_h": np.nan, "rebound_P90_recovery_h": np.nan,
                "rebound_share_recovered_within_block_h": np.nan, "rebound_share_recovered": np.nan}
    t = T.fillna(np.inf)
    p90 = np.quantile(t, 0.9)
    return {"rebound_median_recovery_h": float(np.median(t)) if np.isfinite(np.median(t)) else np.nan,
            "rebound_P90_recovery_h": float(p90) if np.isfinite(p90) else np.nan,
            "rebound_share_recovered_within_block_h": float((t <= L).mean()),
            "rebound_share_recovered": float(np.isfinite(t).mean())}


def rebound_note(cfg):
    r = cfg["rebound"]
    return (f"headroom = P{r['cap_percentile']} of the {r.get('cap_period', 'month')}'s hourly load minus the load; "
            f"E = {r['payback_share']:g} x P x L; recovery searched up to {r['max_hours']} h "
            f"(NaN P90 / median = not recovered within that); lower bound on recovery time")


def classify(firm, cfg):
    if pd.isna(firm):
        return "n/a"
    return "stand-alone" if firm >= cfg["standalone_kw"] else \
        "pool candidate" if firm >= cfg["pool_candidate_kw"] else "not relevant"


def main(cfg=CONFIG):
    os.makedirs(cfg["output_dir"], exist_ok=True)
    d = read_input(cfg)
    fs = cfg["f_values"] or sorted(d.loc[d["source"] == "15 min", "f"].dropna().astype(float).unique()) or [1.0]
    pf = cfg["levels"]["firm"] / 100
    lv_rows, cl_rows, pool_rows, need_rows, pool_hourly = [], [], [], [], []
    rb_rows, var_rows, var_month, var_hourly = [], [], [], []
    pool_month, site_month = [], []

    def month_rows(x, extra):
        out = []
        x = x.dropna()
        for m, v in x.groupby(x.index.month):
            r = dict(extra, month=int(m), n_hours=len(v), mean_kw=v.mean(), typical_P50_kw=v.median(),
                     firm_P10_kw=v.quantile(pf), share_hours_ge_0_1MW=(v >= cfg["lfm_min_kw"]).mean())
            r["season"] = {m_: k for k, ms in cfg["seasons"].items() for m_ in ms}.get(int(m))
            out.append(r)
        return out
    for f in fs:
        ser = site_series(d, f)
        blocks, heads = {}, {}
        for site, sdf in ser.items():
            src = "1 s" if sdf["is_1s"].all() else "15 min" if not sdf["is_1s"].any() else "1 s where available, else 15 min"
            has_load = sdf["load_kw"].notna().any() and not sdf["is_1s"].any()
            H = headroom(sdf["load_kw"], cfg) if has_load else None
            heads[site] = H
            for L in cfg["blocks_h"]:
                b = block_min(sdf["kW"], L)
                blocks[(site, L)] = b
                T = recovery_hours(b, H, L, cfg) if H is not None else None
                if T is not None:
                    seasT = season_of(T.index, cfg)
                    for season in list(cfg["seasons"]) + ["year"]:
                        tt = T if season == "year" else T[(seasT == season).to_numpy()]
                        rb_rows.append(dict({"unit": "site", "site": site, "f": f, "block_h": L, "season": season,
                                             "n_blocks": len(tt),
                                             "headroom_P50_kw": H[(season_of(H.index, cfg) == season).to_numpy()
                                                                  if season != "year" else slice(None)].median()},
                                            **rebound_summary(tt, L, cfg)))
                site_month += month_rows(b, {"site": site, "f": f if not sdf["is_1s"].all() else np.nan,
                                             "block_h": L, "source": src})
                t = levels_table(b, sdf["is_1s"], cfg, cfg["day_types"])
                t.insert(0, "site", site)
                t.insert(1, "f", f if not sdf["is_1s"].all() else np.nan)
                t.insert(2, "block_h", L)
                t["source"] = src
                lv_rows.append(t)
                seas = season_of(b.index, cfg)
                for season in list(cfg["seasons"]) + ["year"]:
                    v = b if season == "year" else b[(seas == season).to_numpy()]
                    v = v.dropna()
                    firm = v.quantile(pf) if len(v) else np.nan
                    sl = levels_table(v, sdf["is_1s"].reindex(v.index), cfg) if len(v) else pd.DataFrame()
                    fk = f"firm_P{cfg['levels']['firm']}_kw"
                    cl_rows.append({"site": site, "f": f if not sdf["is_1s"].all() else np.nan, "block_h": L,
                                    "season": season, "n_hours": len(v),
                                    "typical_P50_kw": v.median() if len(v) else np.nan, "firm_P10_kw": firm,
                                    "class": classify(firm, cfg),
                                    "share_slices_standalone": (sl[fk] >= cfg["standalone_kw"]).mean() if len(sl) else np.nan,
                                    "share_slices_pool_or_better": (sl[fk] >= cfg["pool_candidate_kw"]).mean() if len(sl) else np.nan,
                                    "share_hours_ge_100kw": (v >= cfg["standalone_kw"]).mean() if len(v) else np.nan,
                                    "source": src,
                                    **(rebound_summary(None, L, cfg) if T is None else rebound_summary(
                                        T if season == "year" else T[(season_of(T.index, cfg) == season).to_numpy()],
                                        L, cfg)),
                                    "rebound_note": rebound_note(cfg) if T is not None else
                                    "N/A: no hourly load for this site (1 s data)"})
        # ---- pool
        sites = list(ser) if cfg["pool_sites"] == "all" else [s for s in cfg["pool_sites"] if s in ser]
        if not sites:
            continue
        for L in cfg["blocks_h"]:
            mat = pd.concat({s: blocks[(s, L)] for s in sites}, axis=1)
            is1 = pd.concat({s: ser[s]["is_1s"] for s in sites}, axis=1).reindex(mat.index).fillna(False)
            pool = mat.sum(axis=1, min_count=len(sites))
            pool[mat.isna().any(axis=1)] = np.nan
            t = levels_table(pool, is1.mean(axis=1), cfg, cfg["day_types"])
            t.insert(0, "f", f)
            t.insert(1, "block_h", L)
            t["n_sites"] = len(sites)
            pool_rows.append(t)
            seas = season_of(pool.index, cfg)
            ph = pd.DataFrame({"hour": pool.index, "f": f, "block_h": L, "pool_kw": pool.to_numpy(),
                               "n_sites": len(sites)})
            pool_hourly.append(ph)
            pool_month += month_rows(pool, {"f": f, "block_h": L, "n_sites": len(sites),
                                            "sites": " ".join(map(str, sites))})
            # sites needed: add in order of the site's firm level (year)
            firm_site = {s: blocks[(s, L)].dropna().quantile(pf) for s in sites}
            order = sorted(sites, key=lambda s: -np.nan_to_num(firm_site[s], nan=-1))
            for season in list(cfg["seasons"]) + ["year"]:
                m = mat if season == "year" else mat[(seas == season).to_numpy()]
                v_all = pool if season == "year" else pool[(seas == season).to_numpy()]
                v_all = v_all.dropna()
                n_need, cum = None, []
                for k in range(1, len(order) + 1):
                    sub = m[order[:k]]
                    ps = sub.sum(axis=1, min_count=k)[~sub.isna().any(axis=1)]
                    fv = ps.quantile(pf) if len(ps) else np.nan
                    cum.append(f"{order[k - 1]}:{fv:.1f}" if pd.notna(fv) else f"{order[k - 1]}:n/a")
                    if n_need is None and pd.notna(fv) and fv >= cfg["lfm_min_kw"]:
                        n_need = k
                need_rows.append({"f": f, "block_h": L, "season": season, "n_sites_available": len(order),
                                  "pool_hours": len(v_all),
                                  "share_hours_pool_ge_0_1MW": (v_all >= cfg["lfm_min_kw"]).mean() if len(v_all) else np.nan,
                                  "pool_firm_P10_kw": v_all.quantile(pf) if len(v_all) else np.nan,
                                  "sites_needed_for_firm_0_1MW": n_need if n_need else "not reached",
                                  "order_and_cumulative_firm_kw": " | ".join(cum)})
            # pool rebound: each site recovers its own energy in its own headroom
            if all(heads.get(s_) is not None for s_ in sites):
                Hp = pd.concat({s_: heads[s_] for s_ in sites}, axis=1).reindex(pool.index).sum(axis=1, min_count=len(sites))
                Tp = recovery_hours(pool, Hp, L, cfg)
                seasT = season_of(Tp.index, cfg)
                for season in list(cfg["seasons"]) + ["year"]:
                    tt = Tp if season == "year" else Tp[(seasT == season).to_numpy()]
                    rb_rows.append(dict({"unit": "pool", "site": "pool", "f": f, "block_h": L, "season": season,
                                         "n_blocks": len(tt), "headroom_P50_kw":
                                         (Hp if season == "year" else Hp[(seas == season).to_numpy()]).median()},
                                        **rebound_summary(tt, L, cfg)))
        # ---- pool variants (same statistics, sites left out)
        if cfg.get("pool_variants"):
            dr = d[d["site"].isin(sites)]
            rk = dr[dr["source"] == "1 s"].groupby("site")["kW"].mean().to_dict()
            r15 = dr[(dr["source"] == "15 min") & np.isclose(dr["f"].astype(float), cfg["rank_f"])]
            rk.update(r15.groupby("site")["kW"].mean().to_dict())
            by_size = sorted(sites, key=lambda s_: (rk.get(s_, np.inf), str(s_)))
            base_firm = {}
            for vname, spec in cfg["pool_variants"].items():
                spec = spec or {}
                if "sites" in spec:
                    vs = [s_ for s_ in sites if s_ in set(map(str, spec["sites"]))]
                else:
                    drop = set(map(str, spec.get("exclude", [])))
                    drop |= set(by_size[:int(spec.get("exclude_smallest", 0))])
                    vs = [s_ for s_ in sites if str(s_) not in drop]
                excl = [s_ for s_ in sites if s_ not in vs]
                note = "" if (excl or not spec) else "nothing left out (site(s) not in the pool)"
                if not vs:
                    continue
                for L in cfg["blocks_h"]:
                    mat = pd.concat({s_: blocks[(s_, L)] for s_ in vs}, axis=1)
                    pv_ = mat.sum(axis=1, min_count=len(vs))
                    pv_[mat.isna().any(axis=1)] = np.nan
                    seas = season_of(pv_.index, cfg)
                    extra = {"variant": vname, "f": f, "block_h": L, "n_sites": len(vs),
                             "sites": " ".join(map(str, vs)), "left_out": " ".join(map(str, excl)), "note": note}
                    var_month += month_rows(pv_, extra)
                    var_hourly.append(pd.DataFrame({"variant": vname, "hour": pv_.index, "f": f, "block_h": L,
                                                    "pool_kw": pv_.to_numpy(), "n_sites": len(vs)}))
                    for season in list(cfg["seasons"]) + ["year"]:
                        v = (pv_ if season == "year" else pv_[(seas == season).to_numpy()]).dropna()
                        firm = v.quantile(pf) if len(v) else np.nan
                        if vname == "all" or (not spec):
                            base_firm[(L, season)] = firm
                        b0 = base_firm.get((L, season), np.nan)
                        var_rows.append(dict(extra, season=season, n_hours=len(v),
                                             typical_P50_kw=v.median() if len(v) else np.nan, firm_P10_kw=firm,
                                             share_hours_ge_0_1MW=(v >= cfg["lfm_min_kw"]).mean() if len(v) else np.nan,
                                             firm_change_vs_all_pct=100 * (firm / b0 - 1) if b0 and pd.notna(b0) else np.nan,
                                             ranking=f"smallest first, mean kW at f={cfg['rank_f']}: "
                                                     + " ".join(f"{s_}:{rk.get(s_, np.nan):.1f}" for s_ in by_size)))
    meta = {"source_resolution": "see source / share_1s", "percentile_def": str(cfg["levels"])}
    w = dict(sep=cfg["csv_sep"], decimal=cfg["csv_decimal"], index=False, encoding="utf-8-sig")

    def wr(rows, name):
        if not rows:
            print(f"[offer] {name}: nothing to write")
            return None
        t = pd.concat(rows, ignore_index=True) if isinstance(rows[0], pd.DataFrame) else pd.DataFrame(rows)
        if "season" not in t and "month" in t:
            t["season"] = t["month"].map({m: k for k, ms in cfg["seasons"].items() for m in ms})
        for k, v in meta.items():
            t[k] = v
        t.round(3).to_csv(os.path.join(cfg["output_dir"], name), **w)
        return t
    wr(lv_rows, "offer_levels.csv")
    cl = wr(cl_rows, "offer_classification.csv")
    wr(pool_rows, "pool_levels.csv")
    nd = wr(need_rows, "pool_sites_needed.csv")
    pm = wr(pool_month, "pool_monthly.csv")
    wr(site_month, "site_monthly.csv")
    rb = wr(rb_rows, "rebound.csv")
    vr = wr(var_rows, "pool_variants.csv")
    wr(var_month, "pool_variants_monthly.csv")
    if var_hourly:
        pd.concat(var_hourly, ignore_index=True).to_csv(os.path.join(cfg["output_dir"], "pool_variants_hourly.csv"), **w)
    if vr is not None:
        print(vr[(vr["block_h"] == min(cfg["blocks_h"]))].pivot_table(
            index=["variant", "season"], columns="f", values="firm_P10_kw").round(1).to_string())
    if rb is not None:
        print(rb[rb["unit"] == "pool"][["f", "block_h", "season", "headroom_P50_kw", "rebound_median_recovery_h",
                                        "rebound_P90_recovery_h", "rebound_share_recovered_within_block_h"]]
              .round(2).to_string(index=False))
    if pm is not None:
        print(pm[pm["block_h"] == min(cfg["blocks_h"])].pivot_table(index="month", columns="f", values="firm_P10_kw")
              .round(1).to_string())
    if pool_hourly:
        pd.concat(pool_hourly, ignore_index=True).to_csv(
            os.path.join(cfg["output_dir"], "pool_hourly.csv"), **w)
    if cl is not None:
        print(cl[cl["season"] == "year"].pivot_table(index=["site"], columns=["f", "block_h"], values="class",
                                                     aggfunc="first").to_string())
    if nd is not None:
        print(nd[["f", "block_h", "season", "share_hours_pool_ge_0_1MW", "pool_firm_P10_kw",
                  "sites_needed_for_firm_0_1MW"]].round(3).to_string(index=False))
    print(f"[offer] outputs in {os.path.abspath(cfg['output_dir'])}")


if __name__ == "__main__":
    main()
