"""
clock_check.py -- which clock do the meter data and the eSett file follow?

Sweden has summer time. If meter time stamps are normal time (CET) all year,
every summer hour is shifted one hour against SE4, and "the top SE4 hours"
pick the wrong pool hour. Two independent checks, both from the data:

1. DST days (raw rows, before any de-duplication or resampling): on the last
   Sunday of March and of October {YEAR}. Summer time on a local clock gives
   a short spring day (no 02:00-02:59, 92 quarter-hours) and a long autumn
   day (02:00-02:59 twice, 100). A fixed clock (CET or UTC) gives 96 on both.
2. Solar noon (PV sites on net load, June): the midday dip in net load is
   centred on solar noon -- in Helsingborg about 13:10 summer time, 12:10
   CET, 11:10 UTC. The dip centre is the centroid of (line between the 07 and
   19 o'clock load) minus (the mean June profile), over 07-19.

The same DST-day count is made on the eSett file's local column; the v3
script reads eSett by its UTC column, so eSett needs no assumption.

Output: clock_check_out/clock_check.csv and clock_check.txt (read into the
header of subscription_value.py v3). Run from the data folder:
    python run_all.py --only clock
"""
import os
import sys

import numpy as np
import pandas as pd

YEAR = 2025
SE4_PATH = os.environ.get("EXJOBB_SE4") or os.path.join("data", "external", "SE4_consumption_2025.csv")
SOLAR_NOON = {"summer time (local wall clock)": 13 + 10 / 60, "CET all year": 12 + 10 / 60, "UTC": 11 + 10 / 60}
OUTPUT_DIR = "clock_check_out"


def dst_days(year):
    def last_sunday(month):
        d = pd.Timestamp(year, month, 1) + pd.offsets.MonthEnd(0)
        return d - pd.Timedelta(days=(d.dayofweek + 1) % 7)
    return last_sunday(3).normalize(), last_sunday(10).normalize()


def dst_verdict(ts):
    """ts: naive time stamps of ONE channel (raw rows). Counts per DST day,
    compared with the median count of the days around them."""
    spring, autumn = dst_days(YEAR)
    t = pd.Series(pd.to_datetime(ts)).dropna()
    days = t.dt.normalize()
    cnt = days.value_counts()
    normal = int(pd.Series([cnt.get(spring + pd.Timedelta(days=k), np.nan) for k in (-2, -1, 1, 2)]
                           + [cnt.get(autumn + pd.Timedelta(days=k), np.nan) for k in (-2, -1, 1, 2)]).median())
    n_s, n_a = int(cnt.get(spring, 0)), int(cnt.get(autumn, 0))
    s_rows = t[days == spring]
    has_0200 = bool(((s_rows.dt.hour == 2)).any())
    dup_autumn = int(t[days == autumn].duplicated().sum())
    if n_s == 0 or n_a == 0 or not normal:
        v = "undetermined (no data on a DST day)"
    elif n_s < normal and n_a > normal:
        v = "summer time (local wall clock)"
    elif n_s == normal and n_a == normal and has_0200 and dup_autumn == 0:
        v = "fixed clock (CET or UTC)"
    elif n_s < normal and n_a == normal and dup_autumn > 0:
        v = "summer time (local wall clock), autumn hour stored twice under one label"
    else:
        v = "unclear"
    return dict(rows_normal_day=normal, rows_spring_day=n_s, rows_autumn_day=n_a, spring_has_0200=has_0200,
                autumn_duplicate_stamps=dup_autumn, dst_verdict=v)


def solar_noon(net):
    """Dip centre (decimal hour on the file's clock) of the mean June net-load profile."""
    j = net[(net.index.month == 6) & (net.index.year == YEAR)].dropna()
    if len(j) < 24 * 4 * 10:
        return np.nan, "too little June data"
    prof = j.groupby(j.index.hour + j.index.minute / 60).mean()
    win = prof[(prof.index >= 7) & (prof.index <= 19)]
    if len(win) < 10:
        return np.nan, "no 07-19 profile"
    x = win.index.to_numpy(float)
    ref = np.interp(x, [x[0], x[-1]], [win.iloc[0], win.iloc[-1]])
    dip = np.clip(ref - win.to_numpy(float), 0, None)
    if dip.sum() <= 0:
        return np.nan, "no midday dip"
    centre = float((x * dip).sum() / dip.sum()) + 0.125      # quarter-hour stamps -> centre of the interval
    return centre, f"dip depth {dip.max():.1f} kW"


def nearest_clock(h):
    if not np.isfinite(h):
        return "undetermined"
    k = min(SOLAR_NOON, key=lambda c: abs(SOLAR_NOON[c] - h))
    return f"{k} (off by {abs(SOLAR_NOON[k] - h) * 60:.0f} min)"


def raw_stamps(L, path, lcfg):
    """Time stamps of the active-energy channel, straight from the file."""
    df = L._read_table(path)
    tc = lcfg["timestamp_col"]
    if tc not in df:
        raise KeyError(f"time column {tc!r} not in {os.path.basename(path)}")
    if lcfg.get("data_format") == "long":
        lf = lcfg["long_format"]
        df = L._select_channel_rows(df, lf["channel_col"], lf["kwh_channel_values"])
    t = pd.to_datetime(df[tc], unit=lcfg["timestamp_unit"], errors="coerce") if lcfg.get("timestamp_unit") \
        else pd.to_datetime(df[tc], errors="coerce")
    return t.dropna()


def eset_check(path):
    if not os.path.exists(path):
        return None
    d = pd.read_csv(path, sep=";", decimal=",", encoding="utf-8-sig")
    lc = next((c for c in d.columns if "CET" in c), None)
    uc = next((c for c in d.columns if "UTC" in c), None)
    out = {"file": path}
    if lc:
        out.update({f"local column {k}": v for k, v in
                    dst_verdict(pd.to_datetime(d[lc], format="%d.%m.%Y/%H:%M")).items()})
    if uc:
        u = pd.to_datetime(d[uc], format="%d.%m.%Y/%H:%M")
        out["UTC column duplicates"] = int(u.duplicated().sum())
        out["UTC column first stamp"] = str(u.min())
    return out


def main():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import lpc_11 as L
    lcfg = L.CONFIG
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df = L.read_comparison(lcfg)
    if df is None:
        sys.exit("site_comparison.csv not found -- run from the data folder.")
    pvcol = df["pv_flag"].astype(str).str.lower().isin(["true", "1", "1.0"]) if "pv_flag" in df else None
    rows = []
    for i, r in enumerate(df.to_dict("records")):
        sid = str(r[L.SITE_KEY])
        name = L.site_label(sid)
        path = L.find_meter_file(r, lcfg)
        row = {"site": f"Site {name}" if not name.startswith("Site ") else name, "pv_flag": bool(pvcol.iloc[i])
               if pvcol is not None else None}
        if path is None:
            rows.append(dict(row, note="meter file not found"))
            continue
        try:
            row.update(dst_verdict(raw_stamps(L, path, lcfg)))
        except Exception as e:  # noqa: BLE001
            row["note"] = f"raw read failed: {e}"
        if row.get("pv_flag"):
            try:
                net, _ = L.load_net_series(dict(lcfg, csv_path=path, show_plot=False))
                h, why = solar_noon(net)
                row.update(solar_noon_h=round(h, 2) if np.isfinite(h) else None,
                           solar_noon_clock=nearest_clock(h), solar_note=why)
            except Exception as e:  # noqa: BLE001
                row["solar_note"] = f"failed: {e}"
        rows.append(row)
    res = pd.DataFrame(rows)
    res.to_csv(os.path.join(OUTPUT_DIR, "clock_check.csv"), sep=";", decimal=",", index=False, encoding="utf-8-sig")
    spring, autumn = dst_days(YEAR)
    vc = res["dst_verdict"].value_counts().to_dict() if "dst_verdict" in res else {}
    sol = res["solar_noon_clock"].dropna().str.split(" \\(").str[0].value_counts().to_dict() \
        if "solar_noon_clock" in res else {}
    lines = [f"Clock check ({YEAR}; DST days {spring.date()} and {autumn.date()})",
             f"Meter time column: {lcfg['timestamp_col']!r}",
             f"DST-day test, sites per verdict: {vc}",
             f"Solar-noon test (PV sites, June), sites per clock: {sol or 'no PV site tested'}"]
    clocks = set(vc) | set(sol)
    if len(vc) == 1 and next(iter(vc)).startswith("summer time") and (not sol or set(sol) == {
            "summer time (local wall clock)"}):
        concl, pt = "meter data follow summer time (local wall clock)", "local_wallclock"
    elif len(vc) == 1 and next(iter(vc)).startswith("fixed") and sol and len(sol) == 1:
        k = next(iter(sol))
        concl, pt = f"meter data use a fixed clock: {k}", "cet" if k.startswith("CET") else "utc"
    else:
        concl, pt = f"not unanimous -- inspect clock_check.csv ({sorted(clocks)})", None
    lines.append(f"Conclusion: {concl}" + (f"  ->  set POOL_TIME = {pt!r} in subscription_value.py" if pt else ""))
    e = eset_check(SE4_PATH)
    if e:
        lines.append(f"eSett {os.path.basename(SE4_PATH)}: local column -> {e.get('local column dst_verdict')}; "
                     f"UTC column duplicates {e.get('UTC column duplicates')}, first stamp {e.get('UTC column first stamp')}; "
                     f"subscription_value.py reads the UTC column, so eSett needs no assumption.")
    with open(os.path.join(OUTPUT_DIR, "clock_check.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(res.to_string(index=False))


if __name__ == "__main__":
    main()
