"""
value_percentile_range.py -- value of the cold-store pool across a range of
percentiles (task_value_percentile_range.md).

The pool's monthly level L_m^(x) is the x-th percentile of the hourly pool
series X_h. A higher level saves more on the subscription but falls short
more often; a shortfall in the (unknown) peak hour is charged as an overrun
at 2 x p_sub. With the peak equally likely in any hour of the month:

  S_m = p_sub * L_m                                   saving if always delivered
  C_m = 2 p_sub * (1/n_m) * sum_h max(0, L_m - X_h)    expected overrun cost
  N_m = S_m - C_m                                     expected net saving
  q_m = share of hours with X_h < L_m                 shortfall probability
  P(>=1 shortfall per year) = 1 - prod_m (1 - q_m)    (months independent)

Definitions exactly as the brief:
  hourly load  L(s,h) = mean of the four 15-min values in clock hour h; hours
               with a missing quarter-hour are dropped (counted per site).
  base load    L_base(s, m) = P5 of the site's hourly load in calendar month m
               (BASE_PERIOD "month", the default; "season" = per season, with
               the shared definition winter Nov-Feb, summer Jun-Aug, shoulder
               the rest -- the brief's original choice, kept as an option).
  flexible     P(s,h) = f * max(0, L(s,h) - L_base)
  pool         X_h = sum over sites of P(s,h), summed BEFORE any percentile.
Data are NET withdrawal as metered; no PV correction (midday solar lowering
X_h in summer is part of the result). No grid or substation data are used.

Check of the theory: dN_m/dL = p_sub (1 - 2 F_m(L)), so N_m is largest at the
month's median. Checked two ways on a 1 kW grid: (a) the best level per
month vs its P50; (b) the best single level for the whole year (the curve
in Figure 1), which in theory is where the mean of the monthly F_m is 0.5.

Outputs (OUTPUT_DIR): table1_main.csv/.tex, table2_monthly.csv/.tex (P10 and
P50), table3_sensitivity.csv/.tex, fig1_net_vs_level.pdf/.png,
pool_hourly_2025.csv, grid_check_monthly.csv, note.md, and the fixed input
snapshot input_snapshot_hourly_sites.csv (+ sha256 in note.md). Rerun from
the snapshot with  python value_percentile_range.py --from-snapshot
Deterministic.
"""
import hashlib
import math
import os
import sys

import numpy as np
import pandas as pd


def lpc_seasons(default):
    """The season definition shared by every script: lpc_11 CONFIG["seasons"]
    (winter Nov-Feb, summer Jun-Aug, shoulder Mar-May + Sep-Oct). Seasons
    only SUMMARISE results; every calculation is per month or per hour."""
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import lpc_11
        return {k: list(v) for k, v in lpc_11.CONFIG["seasons"].items()}
    except Exception:
        return default

# ======================================================================
# CONFIG
# ======================================================================
SITES = ["A", "B", "C", "D", "E", "F", "H", "I", "J", "L", "M", "N", "O", "P", "Q", "R"]
YEAR = 2025
BASE_PERIOD = "month"                        # base load per "month" (default) or "season"
F_MAIN = 0.5
P_SUB_MAIN = 40.0
OVERRUN_FACTOR = 2.0
BASE_PCT = 5
PERCENTILES = [5, 10, 25, 50]               # plus the mean
SENS = [("f = 0.3", dict(f=0.3)), ("f = 1.0", dict(f=1.0)),
        ("without E", dict(drop=["E"])), ("p_sub = 16", dict(p_sub=16.0))]
REQUIRE_ALL_SITES = False                   # True: X_h only in hours where every site has data
GRID_STEP_KW = 1.0
PV_SITES = ["C", "D", "F", "H", "I", "M", "O", "P", "R"]   # for the note only; no correction
OUTPUT_DIR = "value_percentile_out"
CSV_SEP, CSV_DEC = ";", ","
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
SEASONS = lpc_seasons({"winter": [11, 12, 1, 2], "summer": [6, 7, 8], "shoulder": [3, 4, 5, 9, 10]})   # shared definition, summer Jun-Aug
# ======================================================================

W = dict(sep=CSV_SEP, decimal=CSV_DEC, index=False, encoding="utf-8-sig")


# ---------------------------------------------------------------- input
def load_sites_from_meters():
    """Hourly load per site from the meter files, via lpc_11 (same reading as
    the RQ1 scripts). Returns (wide DataFrame hour x site, notes, file hashes)."""
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import lpc_11 as L
    lcfg = L.CONFIG
    df = L.read_comparison(lcfg)
    if df is None:
        sys.exit("site_comparison.csv not found -- run from the data folder (run_all.py does this).")
    byname = {L.site_label(s): r for s, r in zip(df[L.SITE_KEY].astype(str), df.to_dict("records"))}
    cols, notes, hashes = {}, {}, {}
    for s in SITES:
        r = byname.get(s)
        if r is None:
            notes[s] = "not in site_comparison.csv"
            continue
        path = L.find_meter_file(r, lcfg)
        if path is None:
            notes[s] = "meter file not found"
            continue
        hashes[s] = (os.path.basename(path), sha256(path))
        net, _info = L.load_net_series(dict(lcfg, csv_path=path, show_plot=False))
        q = net[(net.index.year == YEAR)]
        hourly, dropped, total = clock_hours(q)
        cols[s] = hourly
        notes[s] = f"{dropped} of {total} hours dropped (missing quarter-hour)"
    if not cols:
        sys.exit("No site could be read.")
    wide = pd.DataFrame(cols).sort_index()
    return wide, notes, hashes


def clock_hours(q):
    """Mean of the four quarter-hours of each clock hour; hours with fewer
    than four valid values are dropped. Returns (series, dropped, total)."""
    g = q.resample("1h")
    m, n = g.mean(), g.count()
    full = pd.date_range(f"{YEAR}-01-01", f"{YEAR}-12-31 23:00", freq="h", tz=q.index.tz)
    total = len(full)
    keep = m[n >= 4]
    keep = keep[keep.index.year == YEAR]
    return keep, total - len(keep), total


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


# ---------------------------------------------------------------- model
def season_of(idx):
    m2s = {m: s for s, ms in SEASONS.items() for m in ms}
    return pd.Series(idx.month, index=idx).map(m2s)


def period_key(idx):
    return np.asarray(idx.month) if BASE_PERIOD == "month" else season_of(idx).to_numpy()


def base_loads(wide):
    """P5 of each site's hourly load within each month (or season)."""
    return wide.groupby(period_key(wide.index)).quantile(BASE_PCT / 100)   # period x site


def pool_series(wide, base, f, drop=()):
    sites = [s for s in wide.columns if s not in set(drop)]
    b = base.loc[period_key(wide.index), sites].to_numpy()
    P = f * np.maximum(0.0, wide[sites].to_numpy() - b)
    P = np.where(np.isnan(wide[sites].to_numpy()), np.nan, P)
    n = np.sum(~np.isnan(P), axis=1)
    X = np.nansum(P, axis=1)
    ok = (n == len(sites)) if REQUIRE_ALL_SITES else (n > 0)
    return pd.DataFrame({"X_kW": X, "n_sites": n}, index=wide.index)[ok], sites


def month_stats(X, level_fn, p_sub):
    """Per month: level, S, C, N, q. level_fn(values) -> level in kW."""
    rows = []
    for m, g in X.groupby(X.index.month):
        v = g.to_numpy()
        Lm = float(level_fn(v))
        short = np.maximum(0.0, Lm - v)
        S = p_sub * Lm
        C = OVERRUN_FACTOR * p_sub * short.mean()
        rows.append(dict(month=m, n_hours=len(v), L_kW=Lm, saving_SEK=S, overrun_SEK=C, net_SEK=S - C,
                         q=float((v < Lm).mean())))
    return pd.DataFrame(rows)


def level_fns():
    out = [(f"P{x}", (lambda x: lambda v: np.percentile(v, x))(x)) for x in PERCENTILES]
    out.append(("mean", lambda v: float(np.mean(v))))
    return out


def summarise(ms):
    return dict(mean_L_kW=ms["L_kW"].mean(), saving_SEK=ms["saving_SEK"].sum(), overrun_SEK=ms["overrun_SEK"].sum(),
                net_SEK=ms["net_SEK"].sum(), mean_q=ms["q"].mean(),
                p_any_shortfall=1 - float(np.prod(1 - ms["q"].to_numpy())), months=len(ms))


def net_constant_level(X, level, p_sub):
    """Yearly sum of N_m when the same level applies in every month."""
    tot = 0.0
    for _, g in X.groupby(X.index.month):
        v = g.to_numpy()
        tot += p_sub * level - OVERRUN_FACTOR * p_sub * np.maximum(0.0, level - v).mean()
    return tot


def grid_check(X, p_sub):
    """(a) best level per month on the grid vs the month's P50;
    (b) best single yearly level vs the level where mean_m F_m(L) = 0.5."""
    rows = []
    for m, g in X.groupby(X.index.month):
        v = g.to_numpy()
        grid = np.arange(0.0, v.max() + GRID_STEP_KW, GRID_STEP_KW)
        N = np.array([p_sub * L - OVERRUN_FACTOR * p_sub * np.maximum(0.0, L - v).mean() for L in grid])
        i = int(np.argmax(N))
        med = float(np.median(v))
        Nmed = p_sub * med - OVERRUN_FACTOR * p_sub * np.maximum(0.0, med - v).mean()
        rows.append(dict(month=MONTHS[m - 1], best_level_kW=grid[i], P50_kW=med, diff_kW=grid[i] - med,
                         N_best_SEK=N[i], N_at_P50_SEK=Nmed, diff_SEK=N[i] - Nmed))
    monthly = pd.DataFrame(rows)
    grid = np.arange(0.0, X.max() + GRID_STEP_KW, GRID_STEP_KW)
    Ny = np.array([net_constant_level(X, L, p_sub) for L in grid])
    # theory for one yearly level: mean over months of F_m(L) = 0.5
    Fbar = np.array([np.mean([(g.to_numpy() < L).mean() for _, g in X.groupby(X.index.month)]) for L in grid])
    theory = float(grid[int(np.argmin(np.abs(Fbar - 0.5)))])
    return monthly, grid, Ny, float(grid[int(np.argmax(Ny))]), theory


# ---------------------------------------------------------------- output
def fmt(x, d=0):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "--"
    return f"{x:,.{d}f}".replace(",", r"\,")


def tex(path, caption, label, colspec, head, body):
    t = [r"\begin{table}[htbp]", r"\centering", r"\small", rf"\caption{{{caption}}}", rf"\label{{tab:{label}}}",
         rf"\begin{{tabular}}{{{colspec}}}", r"\toprule", head, r"\midrule", *body, r"\bottomrule",
         r"\end{tabular}", r"\end{table}"]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(t) + "\n")


HEAD1 = (r"Percentile & Mean $L_m$ (kW) & Saving if always delivered (SEK/yr) & Expected overrun cost (SEK/yr) & "
         r"Expected net saving (SEK/yr) & Mean $q_m$ & P($\geq$1 shortfall/yr) \\")


def row1(name, s):
    return (f"{name} & {fmt(s['mean_L_kW'], 1)} & {fmt(s['saving_SEK'])} & {fmt(s['overrun_SEK'])} & "
            f"{fmt(s['net_SEK'])} & {s['mean_q']:.3f} & {s['p_any_shortfall']:.3f} \\\\")


def figure(path, grid, Ny, marks, best, sites_n):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    ax.plot(grid, Ny / 1000, color="k", lw=1.6, label="same level every month")
    ax.axhline(0, color="0.6", lw=0.8)
    styles = {"P5": "v", "P10": "s", "P25": "D", "P50": "o"}
    for name, (x, y) in marks.items():
        ax.plot(x, y / 1000, marker=styles.get(name, "^"), ms=7, mfc="white", mec="k", ls="none",
                label=f"{name} each month (x = mean level)")
    ax.axvline(best, color="k", ls=":", lw=1)
    ax.text(best, ax.get_ylim()[1], f" best {best:.0f} kW", va="top", fontsize=8)
    ax.set_xlabel("subscription reduction level (kW)")
    ax.set_ylabel("expected net saving (kSEK/yr)")
    ax.set_title(f"Expected net saving vs level, {sites_n} sites, f = {F_MAIN:g}, "
                 f"p_sub = {P_SUB_MAIN:g} SEK/kW/month", fontsize=9)
    ax.legend(frameon=False, fontsize=7.5, loc="lower left")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path + ".pdf")
    fig.savefig(path + ".png", dpi=200)
    plt.close(fig)


# ---------------------------------------------------------------- main
def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    snap = os.path.join(OUTPUT_DIR, "input_snapshot_hourly_sites.csv")
    if "--from-snapshot" in sys.argv:
        wide = pd.read_csv(snap, sep=CSV_SEP, decimal=CSV_DEC, encoding="utf-8-sig", index_col=0)
        wide.index = pd.to_datetime(wide.index)
        notes = {s: f"{int(wide[s].isna().sum())} hours missing in the snapshot" for s in wide.columns}
        hashes = {}
        source = f"snapshot {snap} (sha256 {sha256(snap)})"
    else:
        wide, notes, hashes = load_sites_from_meters()
        wide.to_csv(snap, sep=CSV_SEP, decimal=CSV_DEC, encoding="utf-8-sig")
        source = "meter files via lpc_11 (snapshot written)"
    missing_sites = [s for s in SITES if s not in wide.columns]
    base = base_loads(wide)
    zero_base = [(s, se) for s in base.columns for se in base.index if not base.loc[se, s] > 0]

    # ---- main case
    X, sites = pool_series(wide, base, F_MAIN)
    pd.DataFrame({"timestamp": X.index, "X_kW": X["X_kW"].round(3), "n_sites": X["n_sites"]}).to_csv(
        os.path.join(OUTPUT_DIR, "pool_hourly_2025.csv"), **W)
    Xs = X["X_kW"]
    t1, monthly = [], {}
    for name, fn in level_fns():
        ms = month_stats(Xs, fn, P_SUB_MAIN)
        monthly[name] = ms
        t1.append(dict(percentile=name, **summarise(ms)))
    t1 = pd.DataFrame(t1)
    t1.round(4).to_csv(os.path.join(OUTPUT_DIR, "table1_main.csv"), **W)
    tex(os.path.join(OUTPUT_DIR, "table1_main.tex"),
        rf"Value of the pool's flexibility as a lower subscription, by percentile of the hourly pool series, "
        rf"{YEAR}, {len(sites)} sites, $f={F_MAIN:g}$, $p_{{\mathrm{{sub}}}}={P_SUB_MAIN:g}$\,SEK/kW per month, "
        rf"overrun charged at $2p_{{\mathrm{{sub}}}}$ with the monthly peak equally likely in any hour.",
        "value_percentiles", "lrrrrrr", HEAD1, [row1(r["percentile"], r) for r in t1.to_dict("records")])

    # ---- table 2: monthly P10 and P50
    t2 = []
    for name in ("P10", "P50"):
        ms = monthly[name].copy()
        ms.insert(0, "percentile", name)
        ms.insert(2, "month_name", [MONTHS[m - 1] for m in ms["month"]])
        t2.append(ms)
    t2 = pd.concat(t2, ignore_index=True)
    t2.round(4).to_csv(os.path.join(OUTPUT_DIR, "table2_monthly.csv"), **W)
    body = []
    for name in ("P10", "P50"):
        body.append(rf"\multicolumn{{6}}{{l}}{{\textit{{{name}}}}} \\")
        for r in t2[t2["percentile"] == name].to_dict("records"):
            body.append(f"{r['month_name']} & {fmt(r['L_kW'], 1)} & {fmt(r['saving_SEK'])} & {fmt(r['overrun_SEK'])} & "
                        f"{fmt(r['net_SEK'])} & {r['q']:.3f} \\\\")
        s = summarise(monthly[name])
        body.append(rf"Year & {fmt(s['mean_L_kW'], 1)} (mean) & {fmt(s['saving_SEK'])} & {fmt(s['overrun_SEK'])} & "
                    rf"{fmt(s['net_SEK'])} & {s['mean_q']:.3f} \\")
        if name == "P10":
            body.append(r"\midrule")
    tex(os.path.join(OUTPUT_DIR, "table2_monthly.tex"),
        rf"Monthly level, saving, expected overrun cost and net saving at P10 and P50 (SEK), $f={F_MAIN:g}$, "
        rf"$p_{{\mathrm{{sub}}}}={P_SUB_MAIN:g}$\,SEK/kW per month. $q_m$: share of hours below the level.",
        "value_percentiles_monthly", "lrrrrr",
        r"Month & $L_m$ (kW) & Saving & Overrun cost & Net saving & $q_m$ \\", body)

    # ---- table 3: sensitivity
    cases = [("main", dict())] + SENS
    t3 = {}
    for cname, spec in cases:
        f, p, drop = spec.get("f", F_MAIN), spec.get("p_sub", P_SUB_MAIN), spec.get("drop", [])
        Xc, sc = pool_series(wide, base, f, drop)
        t3[cname] = {name: summarise(month_stats(Xc["X_kW"], fn, p))["net_SEK"] for name, fn in level_fns()}
    t3 = pd.DataFrame(t3)
    t3.index.name = "percentile"
    t3.round(0).reset_index().to_csv(os.path.join(OUTPUT_DIR, "table3_sensitivity.csv"), **W)
    tex(os.path.join(OUTPUT_DIR, "table3_sensitivity.tex"),
        rf"Expected net saving (SEK/yr) by percentile; each case varies one input from the main case "
        rf"($f={F_MAIN:g}$, all {len(sites)} sites, $p_{{\mathrm{{sub}}}}={P_SUB_MAIN:g}$).",
        "value_percentiles_sensitivity", "l" + "r" * len(t3.columns),
        "Percentile & " + " & ".join(c.replace("p_sub", r"$p_{\mathrm{sub}}$").replace("f =", r"$f$ =")
                                     for c in t3.columns) + r" \\",
        [f"{i} & " + " & ".join(fmt(v) for v in r) + r" \\" for i, r in t3.iterrows()])

    # ---- theory check and figure
    gm, grid, Ny, best, theory = grid_check(Xs, P_SUB_MAIN)
    gm.round(3).to_csv(os.path.join(OUTPUT_DIR, "grid_check_monthly.csv"), **W)
    marks = {r["percentile"]: (r["mean_L_kW"], r["net_SEK"]) for r in t1.to_dict("records") if r["percentile"] != "mean"}
    figure(os.path.join(OUTPUT_DIR, "fig1_net_vs_level"), grid, Ny, marks, best, len(sites))
    best_pct = t1.loc[t1["net_SEK"].idxmax(), "percentile"]

    # ---- checks
    checks = []
    for name in ("P5", "P10", "P25", "P50"):
        x = int(name[1:]) / 100
        dev = float((monthly[name]["q"] - x).abs().max())
        checks.append(f"q_m vs {name}: largest monthly deviation {dev:.3f} (q_m should be close to {x:.2f})")
    s0 = summarise(monthly["P10"])
    checks.append("net = saving - overrun (P10, year): "
                  + ("ok" if np.isclose(s0["net_SEK"], s0["saving_SEK"] - s0["overrun_SEK"]) else "FAILED"))
    checks.append("X_h >= 0 everywhere: " + ("ok" if (Xs >= 0).all() else "FAILED"))

    # ---- note
    held = bool((gm["diff_kW"].abs() <= GRID_STEP_KW).all())
    hrs_partial = int((X["n_sites"] < len(sites)).sum())
    lines = [f"# Value of the pool across percentiles -- note ({YEAR})", "",
             f"- Input: {source}. Sites: {', '.join(sites)} ({len(sites)})."
             + (f" **Missing: {', '.join(missing_sites)}.**" if missing_sites else ""),
             f"- Pool hours: {len(X)}; hours where not all sites had data: {hrs_partial}"
             + ("." if not hrs_partial else
                f" ({'excluded' if REQUIRE_ALL_SITES else 'kept, summed over the sites with data -- X_h is then understated in those hours'})."),
             "- Hours dropped per site (a missing quarter-hour drops the hour):"]
    lines += [f"  - {s}: {notes.get(s, 'not read')}" for s in SITES]
    if hashes:
        lines += ["- Input files (sha256):"] + [f"  - {s}: {fn} {h}" for s, (fn, h) in hashes.items()]
    lines += [f"- Base load (P5 of hourly load per {BASE_PERIOD}, kW):", "",
              base.round(1).T.to_markdown() if hasattr(base, "to_markdown") else base.round(1).T.to_string(), "",
              "- Sites whose base load came out as 0 or below: "
              + (", ".join(f"{s} ({se})" for s, se in zip_sorted(zero_base)) if zero_base else "none")
              + ". A base of 0 makes the whole load count as flexible for that site and season.",
              f"- Median result: best level per month on a {GRID_STEP_KW:g} kW grid vs the month's P50: "
              + ("held in every month (within one grid step)." if held else
                 f"did NOT hold in every month: largest difference {gm['diff_kW'].abs().max():.1f} kW "
                 f"/ {gm['diff_SEK'].abs().max():.0f} SEK (see grid_check_monthly.csv)."),
              f"- One level for the whole year (Figure 1): best at {best:.0f} kW; theory (mean of monthly "
              f"F_m = 0.5) gives {theory:.0f} kW. Among the percentile strategies, the highest net saving is "
              f"{best_pct}.",
              f"- P(>=1 shortfall per year) assumes the months are independent; with q_m near the percentile it "
              f"is close to 1 for every percentile above a few per cent -- read it as 'a shortfall will happen', "
              f"and the expected cost as what it costs on average.",
              f"- PV: {', '.join(PV_SITES)} have solar panels; the net data are used as they are (no correction).",
              "- Checks:"] + [f"  - {c}" for c in checks]
    warn = []
    if missing_sites:
        warn.append(f"sites missing from the input: {', '.join(missing_sites)}")
    if zero_base:
        warn.append("one or more base loads are 0 or negative (export hours in the P5)")
    if hrs_partial:
        warn.append(f"{hrs_partial} hours with not all sites present")
    lines += ["- Things that look wrong: " + ("; ".join(warn) if warn else "nothing flagged by the checks")]
    with open(os.path.join(OUTPUT_DIR, "note.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    pd.set_option("display.width", 200)
    print(t1.round(3).to_string(index=False))
    print()
    print(t3.round(0).to_string())
    print()
    print("\n".join(lines))
    print(f"\n[value-percentile] outputs in {os.path.abspath(OUTPUT_DIR)}")


def zip_sorted(pairs):
    return sorted(pairs)


if __name__ == "__main__":
    main()
