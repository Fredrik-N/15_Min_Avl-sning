"""
subscription_value.py (v3) -- value of a lower subscription level from the
RQ1 pool, with SE4 consumption as the timing signal
(task_superposition_se4_v3.md; v2 = task_subscription_value_v2.md).

No grid data for Öresundskraft are used. SE4 consumption (eSett Oy, open
data, consumption SE4, 2025) shows WHEN the regional load is high; it is
never scaled to MW. The value still rests only on the pool's firm level and
the subscription price, as in v2 (FlexAbility delrapport 3).

  L_m   firm level of the pool in month m (kW), PERCENTILE of the pool's hourly
        block series (F_SHARE, BLOCK_H, POOL, DAYS) over
          L_MODE "all_hours":     all hours of the month (= v2, checked), or
          L_MODE "top_se4_hours": the month's TOP_N highest SE4 hours.
  V_m   = P_SUB * L_m                              (SEK)
  Net_m = P_SUB*L_m - pi_a*(L_m/1000)*H_a - pi_r*(L_m/1000)*H_r
        every activated hour counted as a full hour at L_m (cautious).
  Break-even: H_a* = 1000*P_SUB/pi_a,  pi_r* = 1000*P_SUB/H_r.
  Risk figure: break-even share of failed months = P_SUB / (2*P_SUB) = 0.5.

Superposition (se4_superposition.py): SE4 to hourly local time, normalised
per month; figure 1 = monthly average daily profiles of SE4 and the pool,
figure 2 = heatmap of the pool's median flexibility with each month's TOP_N
SE4 hours marked, table = P10 over all hours vs over the top SE4 hours.

Outputs in subscription_value_out/v3/ (config tag in every config-dependent
file name, e.g. f0.5_P10_1h_all_selected_psub40_allhours, so runs never
overwrite each other): se4_hourly_clean.csv, fig_superposition_profiles.pdf,
fig_superposition_heatmap_top<N>.pdf, superposition_table_top<N>.tex,
value_monthly_<tag>.csv, value_table_<tag>.tex, breakeven_hours_psub<P>.csv,
breakeven_table_psub40.tex, net_value_grid_<tag>.csv, fig_net_value_<tag>.pdf,
sensitivity_v3_<tag>.csv, header_<tag>.txt. The v2 outputs in
subscription_value_out/ are moved to subscription_value_out/archive/v2/.
Deterministic. The config is Fredrik's choice -- do not tune it to the result.
"""
import datetime as dt
import os
import shutil
import sys

import numpy as np
import pandas as pd

# ======================================================================
# CONFIG
# ======================================================================
RQ1_SOURCE = os.path.join("offerable_flex_out", "pool_levels.csv")   # path to the RQ1 output
F_SHARE = 0.5          # controllable share f: 0.3, 0.5, 0.7, 1.0
PERCENTILE = "P10"     # firm level: "P5", "P10", "P20" (or "P50" for the typical level)
BLOCK_H = 1            # block length: 1, 2 or 4
DAYS = "all"           # "all", "weekday" or "weekend"
POOL = "selected"      # site set of the RQ1 run: "selected" or a pool variant (e.g. "without_D")
P_SUB = 40.0           # SEK per kW and month

# ---- v3: timing signal
CONSTRAINT_SOURCE = "SE4_esett_2025"
SE4_PATH = os.environ.get("EXJOBB_SE4") or os.path.join("data", "external", "SE4_consumption_2025.csv")
                                # eSett export; run_all.py sets it (its SE4 setting)
YEAR = 2025
TOP_N = 10                      # highest SE4 hours per month; sensitivity 5 and 20
TOP_N_SENS = [5, 10, 20]
L_MODE = "all_hours"            # "all_hours" (v2) | "top_se4_hours" (P over the month's TOP_N SE4 hours)
POOL_TIME = "local_wallclock"   # clock of the pool series: "local_wallclock" (summer time) | "cet" | "utc"
HEATMAP_VMAX = 200              # kW, colour scale of the superposition heatmap (match the pool tables); None = auto

ROOT_DIR = "subscription_value_out"
OUTPUT_DIR = os.path.join(ROOT_DIR, "v3")
CSV_SEP, CSV_DEC = ";", ","
H_A = [0, 1, 2, 4, 6, 8, 12]                 # activated hours per month
PI_A = [0, 3300, 10000]                      # activation price, SEK/MWh
RES_GRID = dict(pi_r=[200, 1000], H_r=[20, 60, 120, 730], H_a=2, pi_a=3300)
BE_PI_A = [1000, 3300, 5000, 10000, 16000]   # break-even lists
BE_H_R = [10, 20, 60, 120, 730]
SENS = dict(P_SUB=[16, 30, 40, 50], F_SHARE=[0.3, 0.5, 1.0], PERCENTILE=["P5", "P10", "P20"], BLOCK_H=[1, 2, 4])
SENS_POINT = dict(H_a=4, pi_a=3300)          # net value reported in the sensitivity table
V1_FILES = ["subscription_value_table_e250.tex", "subscription_value_limits.csv",
            "fig_need_energy.pdf", "fig_need_energy.png", "fig_breakeven.pdf", "fig_breakeven.png"]
V2_PREFIX = ("value_monthly_", "breakeven_hours_", "net_value_grid_", "sensitivity_v2_", "value_table_",
             "breakeven_table_", "fig_net_value_", "header_")
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
# ======================================================================


def read(path):
    d = pd.read_csv(path, sep=CSV_SEP, decimal=CSV_DEC, encoding="utf-8-sig")
    if "f" in d:
        d["f"] = pd.to_numeric(d["f"], errors="coerce")
    return d


class Pools:
    """The pool's hourly block series for every (pool, f, block). "selected"
    = pool_hourly.csv (the RQ1 pool); other names = pool_variants_hourly.csv
    (its variant "all" is the same pool as "selected" and is not listed twice)."""

    def __init__(self, source):
        folder = os.path.dirname(source) or "."
        self.files = {}
        parts = []
        p = os.path.join(folder, "pool_hourly.csv")
        if os.path.exists(p):
            d = read(p)
            d["pool"] = "selected"
            parts.append(d)
            self.files["selected"] = p
        p = os.path.join(folder, "pool_variants_hourly.csv")
        if os.path.exists(p):
            d = read(p)
            d = d[d["variant"] != "all"].rename(columns={"variant": "pool"})
            parts.append(d)
            for name in d["pool"].unique():
                self.files[name] = p
        if not parts:
            sys.exit(f"No pool_hourly.csv in {folder!r} (next to RQ1_SOURCE {source!r}). Run offerable_flex.py first.")
        d = pd.concat(parts, ignore_index=True)
        d["hour"] = pd.to_datetime(d["hour"])
        self.d = d
        self.combos = d.groupby(["pool", "f", "block_h"]).size().reset_index()[["pool", "f", "block_h"]]
        self.source_kind = self._source_kind(source)

    @staticmethod
    def _source_kind(source):
        if not os.path.exists(source):
            return f"{source} not found; L_m computed from the pool's hourly block series"
        cols = pd.read_csv(source, sep=CSV_SEP, nrows=0, encoding="utf-8-sig").columns
        if "hour_of_day" in cols:
            return (f"{os.path.basename(source)} holds only month x hour-of-day slices, so L_m is recomputed "
                    f"from the pool's hourly block series (all hours of the month)")
        return f"{os.path.basename(source)} read; L_m recomputed from the pool's hourly block series"

    def series(self, pool, f, block, days):
        s = self.d[(self.d["pool"] == pool) & np.isclose(self.d["f"], f) & (self.d["block_h"] == block)]
        if s.empty:
            have = "\n  ".join(f"POOL={r.pool!r}, F_SHARE={r.f:g}, BLOCK_H={r.block_h}" for r in self.combos.itertuples())
            raise LookupError(f"The RQ1 output has no POOL={pool!r}, F_SHARE={f:g}, BLOCK_H={block}. "
                              f"Combinations that exist:\n  {have}")
        s = s.set_index("hour")["pool_kw"].dropna()
        if days == "weekday":
            s = s[s.index.dayofweek < 5]
        elif days == "weekend":
            s = s[s.index.dayofweek >= 5]
        elif days != "all":
            raise LookupError(f"DAYS must be 'all', 'weekday' or 'weekend', not {days!r}")
        return s

    def n_sites(self, pool, f, block):
        s = self.d[(self.d["pool"] == pool) & np.isclose(self.d["f"], f) & (self.d["block_h"] == block)]
        return int(s["n_sites"].iloc[0]) if len(s) and "n_sites" in s else None


def pct_value(pct):
    try:
        q = float(str(pct).upper().lstrip("P"))
    except ValueError:
        raise LookupError(f"PERCENTILE must look like 'P10', not {pct!r}")
    if not 0 <= q <= 100:
        raise LookupError(f"PERCENTILE out of range: {pct!r}")
    return q / 100


def monthly_level(pools, pool, f, block, pct, days, mode="all_hours", tops=None):
    """L_m per month. mode "all_hours": over all (DAYS) hours of the month;
    "top_se4_hours": over the hours in tops[month] (the TOP_N SE4 hours) for
    which the pool has a value."""
    s = pools.series(pool, f, block, days)
    q = pct_value(pct)
    if mode == "top_se4_hours":
        if tops is None:
            raise LookupError("L_MODE top_se4_hours needs the SE4 top hours")
        keep = pd.DatetimeIndex(sorted(set().union(*[set(v) for v in tops.values()]))) if tops else pd.DatetimeIndex([])
        s = s.reindex(keep).dropna()
    elif mode != "all_hours":
        raise LookupError(f"L_MODE must be 'all_hours' or 'top_se4_hours', not {mode!r}")
    g = s.groupby(s.index.month)
    L = g.quantile(q).clip(lower=0)
    n = g.size()
    out = pd.DataFrame({"month": range(1, 13)})
    out["n_hours"] = out["month"].map(n).fillna(0).astype(int)
    out["L_kW"] = out["month"].map(L)
    return out


def tag(f, pct, block, days, pool, p_sub, mode="all_hours", n=None):
    m = "allhours" if mode == "all_hours" else f"topse4N{n}"
    return f"f{f:g}_{pct}_{block}h_{days}_{pool}_psub{p_sub:g}_{m}"


def net(L_kw, p_sub, H_a, pi_a, H_r, pi_r):
    return p_sub * L_kw - pi_a * (L_kw / 1000) * H_a - pi_r * (L_kw / 1000) * H_r


def net_grid(L, p_sub):
    rows = []
    cases = [(ha, pa, 0, 0) for pa in PI_A for ha in H_A]
    cases += [(RES_GRID["H_a"], RES_GRID["pi_a"], hr, pr) for pr in RES_GRID["pi_r"] for hr in RES_GRID["H_r"]]
    for ha, pa, hr, pr in cases:
        nm = net(L["L_kW"], p_sub, ha, pa, hr, pr)
        for m, x in zip(L["month"], nm):
            rows.append(dict(month=MONTHS[m - 1], H_a=ha, pi_a_SEK_MWh=pa, H_r=hr, pi_r_SEK_MW_h=pr, net_SEK=x))
        rows.append(dict(month="Year", H_a=ha, pi_a_SEK_MWh=pa, H_r=hr, pi_r_SEK_MW_h=pr,
                         net_SEK=nm.sum(min_count=1)))
    return pd.DataFrame(rows)


def breakeven(p_sub):
    s = 1000 * p_sub
    a = [dict(kind="activation only", assumption=f"{pa} SEK/MWh", breakeven=round(s / pa, 2),
              unit="activated hours per month") for pa in BE_PI_A]
    r = [dict(kind="availability only", assumption=f"{h} h reserved per month", breakeven=round(s / h, 1),
              unit="SEK per MW and hour") for h in BE_H_R]
    out = pd.DataFrame(a + r)
    out["P_SUB"] = p_sub
    out["saving_SEK_per_MW_month"] = s
    return out


def annual(L, p_sub):
    return (float((p_sub * L["L_kW"]).sum(min_count=1)),
            float(net(L["L_kW"], p_sub, SENS_POINT["H_a"], SENS_POINT["pi_a"], 0, 0).sum(min_count=1)))


def sensitivity(pools, base, tops_by_n=None):
    """v3: TOP_N (5/10/20) x L_MODE first, then the v2 one-at-a-time cases
    at the configured L_MODE / TOP_N."""
    rows = []
    tops_by_n = tops_by_n or {}

    def add(param, value, cfg):
        try:
            L = monthly_level(pools, cfg["POOL"], cfg["F_SHARE"], cfg["BLOCK_H"], cfg["PERCENTILE"], cfg["DAYS"],
                              cfg.get("L_MODE", "all_hours"), tops_by_n.get(cfg.get("TOP_N")))
        except LookupError:
            rows.append(dict(parameter=param, value=value, annual_value_SEK=np.nan, annual_net_SEK=np.nan,
                             note="not in the RQ1 output"))
            return
        v, n_ = annual(L, cfg["P_SUB"])
        rows.append(dict(parameter=param, value=value, L_MODE=cfg.get("L_MODE"), TOP_N=cfg.get("TOP_N")
                         if cfg.get("L_MODE") == "top_se4_hours" else None, annual_value_SEK=round(v),
                         annual_net_SEK=round(n_), months_with_level=int(L["L_kW"].notna().sum()), note=""))

    add("base", "config", base)
    add("L_MODE x TOP_N", "all_hours", dict(base, L_MODE="all_hours"))
    for n in sorted(tops_by_n):
        add("L_MODE x TOP_N", f"top_se4_hours, N={n}", dict(base, L_MODE="top_se4_hours", TOP_N=n))
    for param, vals in SENS.items():
        for v in vals:
            if param == "F_SHARE" and not np.isclose(pools.d["f"], v).any():
                continue
            add(param, v, dict(base, **{param: v}))
    for p in sorted(pools.d["pool"].unique()):
        add("POOL", p, dict(base, POOL=p))
    out = pd.DataFrame(rows)
    out["net_at"] = f"H_a={SENS_POINT['H_a']} h/month, pi_a={SENS_POINT['pi_a']} SEK/MWh, no reservation"
    return out


def fmt(x, d=0):
    return "--" if pd.isna(x) else f"{x:,.{d}f}".replace(",", r"\,")


def write_tex(path, caption, label, colspec, head, body):
    t = [r"\begin{table}[htbp]", r"\centering", rf"\caption{{{caption}}}", rf"\label{{tab:{label}}}",
         rf"\begin{{tabular}}{{{colspec}}}", r"\toprule", head, r"\midrule", *body, r"\bottomrule",
         r"\end{tabular}", r"\end{table}"]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(t) + "\n")


def value_table(path, L, cfg, n_sites, t):
    V = cfg["P_SUB"] * L["L_kW"]
    body = [f"{MONTHS[m - 1]} & {fmt(l)} & {fmt(x)} \\\\" for m, l, x in zip(L["month"], L["L_kW"], V)]
    body += [r"\midrule", rf"Year & {fmt(L['L_kW'].mean())} (mean) & {fmt(V.sum(min_count=1))} \\"]
    days = {"all": "all days", "weekday": "weekdays", "weekend": "weekends"}[cfg["DAYS"]]
    pool = cfg["POOL"].replace("_", " ") + (f", {n_sites} sites" if n_sites else "")
    write_tex(path, rf"Value of lowering the subscription by the pool's firm level $L_m$ ({cfg['PERCENTILE']} over "
                    rf"all hours of the month, {days}), $f={cfg['F_SHARE']:g}$, {cfg['BLOCK_H']}-hour blocks, pool: "
                    rf"{pool}; $V_m = p_{{\mathrm{{sub}}}} L_m$ with $p_{{\mathrm{{sub}}}} = {cfg['P_SUB']:g}$\,SEK/kW "
                    r"per month. Gross value, before the cost of delivered energy.",
              f"subscription_value_{t.replace('.', '')}", "lrr", r"Month & $L_m$ (kW) & $V_m$ (SEK) \\", body)


def breakeven_table(path, p_sub):
    s = 1000 * p_sub
    body = [rf"Activation only & 3\,300\,SEK/MWh & {s / 3300:.1f}\,h activated per month \\",
            rf"Activation only & 10\,000\,SEK/MWh & {s / 10000:.1f}\,h activated per month \\",
            r"\midrule"]
    body += [rf"Availability only & {h}\,h reserved per month & {fmt(s / h)}\,SEK per MW and hour \\"
             for h in (20, 60, 730)]
    write_tex(path, rf"Break-even of a lower subscription level: the saving is {fmt(s)}\,SEK per MW and month "
                    rf"($p_{{\mathrm{{sub}}}} = {p_sub:g}$\,SEK/kW per month). Beyond the break-even, paying for "
                    r"the activated or reserved flexibility costs more than the saving.",
              "subscription_breakeven", "llr", r"Case & Assumption & Break-even \\", body)


def figure(path_stem, L, cfg):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    ha = np.arange(0, 13)
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for pa, ls in zip(PI_A, ["-", "--", ":"]):
        y = [net(L["L_kW"], cfg["P_SUB"], h, pa, 0, 0).sum(min_count=1) / 1000 for h in ha]
        ax.plot(ha, y, color="k", ls=ls, lw=1.6, label=f"{pa:,} SEK/MWh".replace(",", " "))
    ax.axhline(0, color="0.5", lw=0.8)
    ax.set_xlabel("activated hours per month")
    ax.set_ylabel("annual net value (kSEK)")
    ax.set_title(f"Net value of a lower subscription level: pool {cfg['POOL'].replace('_', ' ')}, "
                 f"f = {cfg['F_SHARE']:g}, {cfg['PERCENTILE']}, {cfg['BLOCK_H']} h, {cfg['DAYS']}", fontsize=9)
    ax.legend(title="activation price", frameon=False, fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    for ext in ("pdf", "png"):
        fig.savefig(f"{path_stem}.{ext}", dpi=200)
    plt.close(fig)


def archive_v2(root):
    """Move the v2 outputs lying in subscription_value_out/ to archive/v2/."""
    arch = os.path.join(root, "archive", "v2")
    moved = []
    if not os.path.isdir(root):
        return moved
    for f in sorted(os.listdir(root)):
        p = os.path.join(root, f)
        if os.path.isfile(p):
            os.makedirs(arch, exist_ok=True)
            shutil.move(p, os.path.join(arch, f))
            moved.append(f)
    return moved


def archive_v1(out):
    """Move the v1 outputs (and any other file that is not a v2 output) to archive_v1/."""
    arch = os.path.join(out, "archive_v1")
    moved = []
    for f in sorted(os.listdir(out)):
        p = os.path.join(out, f)
        if os.path.isfile(p) and (f in V1_FILES or not f.startswith(V2_PREFIX)):
            os.makedirs(arch, exist_ok=True)
            shutil.move(p, os.path.join(arch, f))
            moved.append(f)
    return moved


def checks(L, grid, p_sub, out):
    res = [("L_m >= 0 for every month", bool((L["L_kW"].dropna() >= 0).all()))]
    V = p_sub * L["L_kW"]
    res.append(("annual value = sum of monthly values",
                bool(np.isclose(V.sum(min_count=1), sum(x for x in V if pd.notna(x))))))
    g0 = grid[(grid["H_a"] == 0) & (grid["H_r"] == 0) & (grid["pi_a_SEK_MWh"] == 0) & (grid["month"] == "Year")]
    res.append(("net at H_a = 0 and H_r = 0 equals the gross value",
                bool(np.isclose(g0["net_SEK"].iloc[0], V.sum(min_count=1), equal_nan=True))))
    res.append(("break-even at P_SUB = 40: 12.1 h at 3 300 and 4.0 h at 10 000 SEK/MWh",
                round(40000 / 3300, 1) == 12.1 and round(40000 / 10000, 1) == 4.0))
    bad = []
    for f in os.listdir(out):
        p = os.path.join(out, f)
        if os.path.isfile(p) and f.endswith((".csv", ".tex", ".txt")):
            txt = open(p, encoding="utf-8", errors="ignore").read().lower()
            if any(w in txt for w in _BANNED):
                bad.append(f)
    for f in ("subscription_value.py", "se4_superposition.py"):
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), f)
        if os.path.exists(p) and any(w in open(p, encoding="utf-8").read().lower() for w in _BANNED):
            bad.append(f)
    res.append(("no reference to the area grid series in the v3 code or outputs"
                + (f" (found in {bad})" if bad else ""), not bad))
    return res


_BANNED = ("sub" + "station",)


def v2_reference(L, cfg, pools):
    """L_MODE all_hours vs v2: (1) the archived v2 engine, (2) the archived v2
    CSV of the same config, if it exists."""
    import subscription_value_v2 as V2
    out = []
    try:
        p2 = V2.Pools(RQ1_SOURCE)
        L2 = V2.monthly_level(p2, cfg["POOL"], cfg["F_SHARE"], cfg["BLOCK_H"], cfg["PERCENTILE"], cfg["DAYS"])
        same = np.allclose(L["L_kW"].to_numpy(float), L2["L_kW"].to_numpy(float), equal_nan=True) and \
            (L["n_hours"].to_numpy() == L2["n_hours"].to_numpy()).all()
        out.append(("v2 reproduced with L_MODE = all_hours (v2 engine, same RQ1 output)", bool(same)))
    except Exception as e:  # noqa: BLE001
        out.append((f"v2 engine could not be run: {e}", False))
    t2 = V2.tag(cfg["F_SHARE"], cfg["PERCENTILE"], cfg["BLOCK_H"], cfg["DAYS"], cfg["POOL"], cfg["P_SUB"])
    f2 = os.path.join(ROOT_DIR, "archive", "v2", f"value_monthly_{t2}.csv")
    if os.path.exists(f2):
        old = read(f2)
        old = old[old["month"] != "Year"]
        same = np.allclose(old["L_kW"].to_numpy(float), L["L_kW"].round(2).to_numpy(float), equal_nan=True)
        out.append((f"v2 reproduced against the archived v2 file {os.path.basename(f2)} (may differ only if the RQ1 "
                    f"run changed since)", bool(same)))
    else:
        out.append(("no archived v2 file of this config to compare with (engine check above applies)", True))
    return out


def main():
    import se4_superposition as S
    cfg = dict(F_SHARE=F_SHARE, PERCENTILE=PERCENTILE, BLOCK_H=BLOCK_H, DAYS=DAYS, POOL=POOL, P_SUB=P_SUB,
               L_MODE=L_MODE, TOP_N=TOP_N)
    pools = Pools(RQ1_SOURCE)
    moved = archive_v2(ROOT_DIR) if os.path.isdir(ROOT_DIR) else []
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    w = dict(sep=CSV_SEP, decimal=CSV_DEC, index=False, encoding="utf-8-sig")

    # ---- step 1: SE4
    se4, rep = S.load_se4(SE4_PATH, YEAR)
    c = se4.reset_index()
    c["local_hour"] = c["local_hour"].astype(str)
    c["utc_hour"] = c["utc_hour"].astype(str)
    c.to_csv(os.path.join(OUTPUT_DIR, "se4_hourly_clean.csv"), **w)
    se4c = S.se4_on_pool_clock(se4, POOL_TIME)
    tops_by_n = {n: S.top_hours(se4c, n, DAYS) for n in sorted(set(TOP_N_SENS) | {TOP_N})}
    tops = tops_by_n[TOP_N]
    wrong_month = sum(int((idx.month != m).sum()) for m, idx in tops.items())

    # ---- step 2: superposition (pool series at F_SHARE, BLOCK_H, POOL, all days)
    try:
        pool = pools.series(POOL, F_SHARE, BLOCK_H, "all")
        L = monthly_level(pools, POOL, F_SHARE, BLOCK_H, PERCENTILE, DAYS, L_MODE, tops)
    except LookupError as e:
        sys.exit(f"[subscription v3] {e}")
    j = S.joined(pool, se4c)
    S.fig_profiles(os.path.join(OUTPUT_DIR, "fig_superposition_profiles.pdf"), j)
    hm_max = S.fig_heatmap(os.path.join(OUTPUT_DIR, f"fig_superposition_heatmap_top{TOP_N}.pdf"), j, tops, TOP_N,
                           HEATMAP_VMAX)
    pct_num = int(round(pct_value(PERCENTILE) * 100))
    st = S.table(os.path.join(OUTPUT_DIR, f"superposition_table_top{TOP_N}.tex"), j, tops, TOP_N, pct_num)
    st.to_csv(os.path.join(OUTPUT_DIR, f"superposition_table_top{TOP_N}.csv"), **w)
    joined_hours = int(j[["pool_kW", "se4_MW"]].notna().all(axis=1).sum())

    # ---- step 3: value
    t = tag(F_SHARE, PERCENTILE, BLOCK_H, DAYS, POOL, P_SUB, L_MODE, TOP_N)
    n_sites = pools.n_sites(POOL, F_SHARE, BLOCK_H)
    vm = pd.DataFrame({"month": [MONTHS[m - 1] for m in L["month"]], "n_hours": L["n_hours"],
                       "L_kW": L["L_kW"].round(2), "V_SEK": (P_SUB * L["L_kW"]).round(0)})
    year = dict(month="Year", n_hours=int(L["n_hours"].sum()), L_kW=np.nan,
                V_SEK=round((P_SUB * L["L_kW"]).sum(min_count=1)), L_mean_kW=round(L["L_kW"].mean(), 2),
                L_min_kW=round(L["L_kW"].min(), 2), L_max_kW=round(L["L_kW"].max(), 2))
    vm = pd.concat([vm, pd.DataFrame([year])], ignore_index=True)
    for k_, x in cfg.items():
        vm[k_] = x
    vm["CONSTRAINT_SOURCE"] = CONSTRAINT_SOURCE if L_MODE == "top_se4_hours" else None
    vm.to_csv(os.path.join(OUTPUT_DIR, f"value_monthly_{t}.csv"), **w)
    breakeven(P_SUB).to_csv(os.path.join(OUTPUT_DIR, f"breakeven_hours_psub{P_SUB:g}.csv"), **w)
    grid = net_grid(L, P_SUB)
    g = grid.copy()
    g["net_SEK"] = g["net_SEK"].round(0)
    g.to_csv(os.path.join(OUTPUT_DIR, f"net_value_grid_{t}.csv"), **w)
    sensitivity(pools, cfg, tops_by_n).to_csv(os.path.join(OUTPUT_DIR, f"sensitivity_v3_{t}.csv"), **w)
    value_table(os.path.join(OUTPUT_DIR, f"value_table_{t}.tex"), L, cfg, n_sites, t)
    breakeven_table(os.path.join(OUTPUT_DIR, "breakeven_table_psub40.tex"), 40.0)
    figure(os.path.join(OUTPUT_DIR, f"fig_net_value_{t}"), L, cfg)

    # ---- checks
    L_all = L if L_MODE == "all_hours" else monthly_level(pools, POOL, F_SHARE, BLOCK_H, PERCENTILE, DAYS)
    ck = checks(L, grid, P_SUB, OUTPUT_DIR)
    ck += v2_reference(L_all, cfg, pools)
    ck.append((f"SE4: {rep['hours_with_data']} of {rep['hours_expected']} local hours of {YEAR} have data",
               rep["hours_with_data"] == rep["hours_expected"]))
    ck.append((f"top SE4 hours fall in their own month after the time-zone conversion ({wrong_month} wrong)",
               wrong_month == 0))
    clock_lines = _clock_info()
    ck.append((f"POOL_TIME = {POOL_TIME!r} agrees with clock_check.py (not run = not checked)",
               not _clock_conflict(clock_lines, POOL_TIME)))
    sites = _pool_sites(pools)
    ck.append(("sites named only 'Site X'", all(str(x).startswith("Site ") for x in sites) if sites else True))

    # ---- header
    src = pools.files[POOL]
    when = dt.datetime.fromtimestamp(os.path.getmtime(src)).strftime("%Y-%m-%d %H:%M")
    base = _base_info()
    sens = read(os.path.join(OUTPUT_DIR, f"sensitivity_v3_{t}.csv"))
    sx = sens[sens["parameter"] == "L_MODE x TOP_N"]
    hdr = [f"subscription_value v3 -- config {t}",
           f"F_SHARE={F_SHARE:g}  PERCENTILE={PERCENTILE}  BLOCK_H={BLOCK_H}  DAYS={DAYS}  POOL={POOL}"
           + (f" ({n_sites} sites)" if n_sites else "") + f"  P_SUB={P_SUB:g} SEK/kW per month",
           f"L_MODE={L_MODE}  TOP_N={TOP_N}  CONSTRAINT_SOURCE={CONSTRAINT_SOURCE}  POOL_TIME={POOL_TIME}",
           "",
           "Sources",
           f"  RQ1 pool: {src} (file date {when}); sites: {', '.join(sites) or 'not listed'}",
           f"  Base load of the RQ1 run: {base}",
           f"  SE4: eSett Oy, open data, consumption SE4, {YEAR}; file {SE4_PATH}",
           "",
           "Time zone and data",
           f"  SE4 time stamps read from the UTC column and converted to {S.TZ}; first local hour "
           f"{rep['first_local']} (UTC {rep['first_utc']}), last {rep['last_local']} (UTC {rep['last_utc']}).",
           f"  Row intervals seen (min): {rep['interval_minutes_seen']}; energy summed per hour -> mean MW.",
           f"  DST changes at: {', '.join(rep['dst_days'])}. Pool clock {POOL_TIME}: the repeated autumn hour is "
           f"averaged; the missing spring hour has no SE4 value.",
           f"  Gaps: {rep['hours_missing_or_partial']} local hours missing or partial (not filled)"
           + (f": {rep['missing_or_partial_hours_local']}" if rep['hours_missing_or_partial'] else "") + "; "
           f"{rep['duplicate_stamps']} duplicate time stamps.",
           f"  Hours with both pool and SE4: {joined_hours}.",
           "",
           "Result",
           f"  Annual gross value: {(P_SUB * L['L_kW']).sum(min_count=1):,.0f} SEK; L_m mean {L['L_kW'].mean():.1f}, "
           f"min {L['L_kW'].min():.1f}, max {L['L_kW'].max():.1f} kW ({L_MODE}).",
           "  L_MODE x TOP_N (annual value / net at H_a=4 h, 3 300 SEK/MWh):"]
    hdr += [f"    {r.value}: {r.annual_value_SEK:,.0f} / {r.annual_net_SEK:,.0f} SEK" for r in sx.itertuples()]
    clock = _clock_info()
    hdr[hdr.index("Result"):hdr.index("Result")] = [
        "Clock check (clock_check.py)"] + [f"  {x}" for x in clock] + [
        f"  POOL_TIME used here: {POOL_TIME}" + (
            "  <-- does NOT match the clock check" if _clock_conflict(clock, POOL_TIME) else ""),
        "", "Base load", f"  {_base_sentence()}", ""]
    hdr += [f"  Heatmap colour scale 0-{HEATMAP_VMAX} kW; highest median cell {hm_max:.0f} kW"
            + (" (above the scale: shown as the top colour)" if HEATMAP_VMAX and hm_max > HEATMAP_VMAX else ""),
            f"  Risk figure: break-even share of months with a failed delivery = {P_SUB:g} / {2 * P_SUB:g} = 0.50.",
            "  Activated hours counted as full hours at L_m (cautious).",
            f"  v2 outputs moved to {os.path.join(ROOT_DIR, 'archive', 'v2')}: {len(moved)} file(s)",
            "",
            "Limitations",
            "  - SE4 is a proxy for timing; Öresundskraft's own peak hours may differ.",
            f"  - One year ({YEAR}).",
            "  - eSett consumption includes estimated unmetered production, so sunny summer hours are partly estimated.",
            "  - In June-August SE4's highest hours fall at midday, when the solar panels lower the sites' net load; "
            "the flexibility in those hours is therefore a lower bound.",
            f"  - With TOP_N = {TOP_N}, the {PERCENTILE} over the top hours rests on {TOP_N} values per month.",
            "",
            "Checks:"] + [f"  [{'ok' if ok else 'FAILED'}] {name}" for name, ok in ck]
    with open(os.path.join(OUTPUT_DIR, f"header_{t}.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(hdr) + "\n")
    print("\n".join(hdr))
    print(f"\n[subscription v3] outputs in {os.path.abspath(OUTPUT_DIR)}")
    if not all(ok for _, ok in ck):
        sys.exit(1)


def _clock_info():
    p = os.path.join("clock_check_out", "clock_check.txt")
    if not os.path.exists(p):
        return ["clock_check_out/clock_check.txt not found -- run clock_check.py (run_all.py --only clock)"]
    return [x for x in open(p, encoding="utf-8").read().splitlines() if x.strip()]


def _clock_conflict(lines, pool_time):
    c = next((x for x in lines if x.startswith("Conclusion")), "")
    if "POOL_TIME = " not in c:
        return False
    return f"POOL_TIME = '{pool_time}'" not in c


def _base_sentence():
    p = os.path.join("reducible_power_out", "base_hours_summary.txt")
    return open(p, encoding="utf-8").read().strip() if os.path.exists(p) else \
        "reducible_power_out/base_hours_summary.txt not found -- rerun reducible_power.py"


def _pool_sites(pools):
    p = os.path.join(os.path.dirname(RQ1_SOURCE) or ".", "pool_monthly.csv")
    if not os.path.exists(p):
        return []
    d = read(p)
    if "sites" not in d:
        return []
    names = sorted({x for v in d["sites"].dropna().astype(str) for x in v.split()})
    return [n if n.startswith("Site ") else f"Site {n}" for n in names]


def _base_info():
    p = os.path.join("reducible_power_out", "reducible_power.csv")
    if not os.path.exists(p):
        return "reducible_power.csv not found"
    d = pd.read_csv(p, sep=CSV_SEP, decimal=CSV_DEC, encoding="utf-8-sig",
                    usecols=lambda c: c in ("base_period", "base_hours", "pv_flag", "site", "source"))
    parts = []
    for c in ("base_period", "base_hours"):
        if c in d:
            parts.append(f"{c} {sorted(d[c].dropna().astype(str).unique())}")
    if "pv_flag" in d:
        pv = sorted(d.loc[d["pv_flag"].astype(str).str.lower().isin(["true", "1"]), "site"].astype(str).unique())
        parts.append(f"PV sites {pv}")
    return "; ".join(parts) or "not recorded"


if __name__ == "__main__":
    main()
