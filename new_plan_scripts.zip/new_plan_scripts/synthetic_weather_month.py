"""
synthetic_weather_month.py -- a month of synthetic 1 s P+Q data with planted
weather behaviour, to test unilm_fhmm.py's weather models.

    python synthetic_weather_month.py winter syn_winter.pkl
    python synthetic_weather_month.py summer syn_summer.pkl
    python unilm_fhmm.py syn_winter.pkl --out out_winter --evaluate

Planted truth (the test checks the script finds it):
  Z1  40 kW  air-cooled with a head-pressure floor: step = 40 (1 + 0.02 max(0, Tdry - 12))
             run time ALSO driven by humidity (infiltration / frost)
  Z2  55 kW  evaporative condenser: step = 55 (1 + 0.015 (Twet - 5)); run time follows T only
  Z3  33 kW  constant step; run time follows T only
Each zone is a cold room with a thermostat (on above set + 0.5 K, off below
set - 0.5 K); its heat gain rises with outdoor T, with door traffic in the
working day and, for Z1, with the outdoor humidity ratio. Weather: hourly
dry-bulb with a daily cycle and day-to-day swings, relative humidity with
its own day-to-day swings (so humidity is not just a copy of T).
Deterministic (seed). Columns as the earlier synthetic files.
"""
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from unilm_fhmm import humidity_ratio_gkg, wet_bulb_c   # noqa: E402

DAYS, DT = 30, 10                     # thermal model step 10 s
SEASON = {"winter": dict(T_mean=2.0, T_day=3.0, RH_mean=86.0, RH_day=6.0, t0="2026-01-05"),
          "summer": dict(T_mean=17.0, T_day=5.0, RH_mean=68.0, RH_day=14.0, t0="2026-07-06")}


def ar1(n, sd, rho, rng):
    x = np.zeros(n)
    e = rng.normal(0, sd * np.sqrt(1 - rho ** 2), n)
    for i in range(1, n):
        x[i] = rho * x[i - 1] + e[i]
    return x


def weather(season, rng):
    s = SEASON[season]
    nh = DAYS * 24 + 1
    h = np.arange(nh)
    diurnal = np.sin(2 * np.pi * (h - 9) / 24)               # warmest ~15:00
    T = s["T_mean"] + s["T_day"] * diurnal + ar1(nh, 3.0, 0.97, rng)
    RH = s["RH_mean"] - s["RH_day"] * diurnal + ar1(nh, 9.0, 0.95, rng)
    RH = np.clip(RH, 25, 100)
    t = np.arange(DAYS * 86400)
    return np.interp(t / 3600, h, T), np.interp(t / 3600, h, RH)


def zone(Td_10, w_10, hod_10, gain, rng, set_c=-20.0, cap=1.0, lat=0.0, mean_w=5.0):
    """Thermostat on/off on the 10 s grid."""
    n = len(Td_10)
    th = set_c + rng.uniform(-0.4, 0.4)
    on = np.zeros(n, bool)
    state, since = False, 0
    door = np.where((hod_10 >= 6) & (hod_10 < 18), 0.35, 0.0)
    for i in range(n):
        q = gain * (1 + 0.025 * (Td_10[i] - 5)) + door[i] * gain + lat * (w_10[i] - mean_w)
        th += DT / 3600 * (q - (cap if state else 0.0)) * 6.0
        since += DT
        if state and th < set_c - 0.5 and since >= 240:
            state, since = False, 0
        elif not state and th > set_c + 0.5 and since >= 180:
            state, since = True, 0
        on[i] = state
    return on


def main(season, out, seed=7):
    rng = np.random.default_rng(seed)
    Td, RH = weather(season, rng)
    Tw = wet_bulb_c(Td, RH)
    w = humidity_ratio_gkg(Td, RH)
    n = len(Td)
    t0 = int(pd.Timestamp(SEASON[season]["t0"], tz="Europe/Stockholm").timestamp())
    hod = ((t0 + np.arange(n)) // 3600 + 1) % 24                 # CET hour, close enough for door traffic
    idx10 = np.arange(0, n, DT)
    gt = {}
    P = 15.0 + ar1(n // 60 + 1, 1.0, 0.99, rng).repeat(60)[:n]
    Q = 7.0 + 0.3 * (P - 15.0)
    gt["gt_base_kW"] = P.copy()
    zones = [("Z1", 40.0, 0.62, 0.36, 0.06), ("Z2", 55.0, 0.58, 0.34, 0.0), ("Z3", 33.0, 0.55, 0.30, 0.0)]
    mean_w = float(w.mean())
    for k, (name, p0, qp, gain, lat) in enumerate(zones):
        on10 = zone(Td[idx10], w[idx10], hod[idx10], gain, rng, set_c=-20 + 2 * k, lat=lat, mean_w=mean_w)
        on = np.repeat(on10, DT)[:n]
        if name == "Z1":
            step = p0 * (1 + 0.02 * np.maximum(0.0, Td - 12.0))
        elif name == "Z2":
            step = p0 * (1 + 0.015 * (Tw - 5.0))
        else:
            step = np.full(n, p0)
        pw = np.where(on, step, 0.0)
        P += pw
        Q += pw * qp
        gt[f"gt_{name}_state"] = on.astype(int)
        gt[f"gt_{name}_power_kW"] = pw
    P += rng.normal(0, 0.3, n)
    Q += rng.normal(0, 0.2, n)
    df = pd.DataFrame({"Time": t0 + np.arange(n), "Aggregate_kW": P, "Aggregate_kvar": Q,
                       "Ambient_C": Td, "RH_pct": RH, "gt_vfd_kW": 0.0, **gt})
    df.to_pickle(out)
    print(f"{out}: {season}, {DAYS} days, dry-bulb {np.percentile(Td, 5):.1f}..{np.percentile(Td, 95):.1f} C, "
          f"wet-bulb depression {np.percentile(Td - Tw, 5):.1f}..{np.percentile(Td - Tw, 95):.1f} K, "
          f"duty " + ", ".join(f"{z[0]} {df[f'gt_{z[0]}_state'].mean():.2f}" for z in zones))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
