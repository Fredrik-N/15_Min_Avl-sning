"""
se4_superposition.py -- SE4 consumption as a TIMING signal for the pool's
flexibility (task_superposition_se4_v3.md). Used by subscription_value.py (v3).

SE4 shows WHEN the load is high, not how much to bid: it is never scaled to
MW at Öresundskraft. Source: eSett Oy, open data, consumption SE4, 2025.

Preparation
  * Time: the file's "Date/Time UTC" column is used (the CET/CEST column is
    ambiguous on the autumn DST day). UTC -> Europe/Stockholm.
  * Hourly values: energy (MWh) summed per UTC hour, divided by the hour ->
    mean MW. Works whether a row covers 15 min or 60 min (the interval is
    read from the time stamps), so a switch from hourly to 15-min data during
    the year is handled. Consumption is negative in the file (withdrawal);
    its absolute value is used.
  * Checks: 8 760 local hours of the year, duplicates, hours with less than
    60 min of data (reported, never filled).
  * se4_norm = SE4 / max(SE4 in that local month).
Joining with the pool: the RQ1 pool series has naive local clock hours
(POOL_TIME "local_wallclock"): on the autumn DST day the two 02:00 hours of
SE4 are averaged, and in spring SE4 has no 02:00 hour. "cet" (UTC+1 all
year) and "utc" are options if the meter data turn out not to follow
summer time.
"""
import os

import numpy as np
import pandas as pd

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
TZ = "Europe/Stockholm"


def load_se4(path, year):
    """Hourly SE4 consumption. Returns (DataFrame indexed by local aware
    hour with se4_MW, minutes_of_data, utc_hour; report dict)."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"SE4 file not found: {path} (put the eSett export in data/external/)")
    d = pd.read_csv(path, sep=";", decimal=",", encoding="utf-8-sig")
    tcol = next((c for c in d.columns if "UTC" in c), None)
    vcol = next((c for c in d.columns if c.lower().startswith("consumption total")), None)
    if tcol is None or vcol is None:
        raise ValueError(f"SE4 file: need a 'Date/Time UTC' and a 'Consumption Total' column, got {list(d.columns)}")
    if "MBA" in d and set(d["MBA"].dropna().unique()) - {"SE4"}:
        raise ValueError(f"SE4 file holds other areas: {sorted(d['MBA'].unique())}")
    t = pd.to_datetime(d[tcol], format="%d.%m.%Y/%H:%M").dt.tz_localize("UTC")
    rep = {"rows": len(d), "duplicate_stamps": int(t.duplicated().sum())}
    d = pd.DataFrame({"t": t, "mwh": pd.to_numeric(d[vcol], errors="coerce").abs()}).drop_duplicates("t")
    d = d.sort_values("t").reset_index(drop=True)
    step = d["t"].diff().shift(-1)
    step.iloc[-1] = step.iloc[-2] if len(step) > 1 else pd.Timedelta("15min")
    d["minutes"] = step.dt.total_seconds() / 60
    rep["interval_minutes_seen"] = sorted(int(x) for x in d["minutes"].unique())
    d["utc_hour"] = d["t"].dt.floor("h")
    g = d.groupby("utc_hour").agg(mwh=("mwh", "sum"), minutes=("minutes", "sum"), n_rows=("mwh", "count"),
                                  n_nan=("mwh", lambda x: int(x.isna().sum())))
    start = pd.Timestamp(f"{year}-01-01 00:00", tz=TZ).tz_convert("UTC")
    end = pd.Timestamp(f"{year}-12-31 23:00", tz=TZ).tz_convert("UTC")
    full = pd.date_range(start, end, freq="h")
    g = g.reindex(full)
    rep["hours_expected"] = len(full)
    rep["hours_with_data"] = int(g["mwh"].notna().sum())
    partial = g[(g["minutes"].fillna(0) < 60) | (g["n_nan"].fillna(0) > 0)]
    rep["hours_missing_or_partial"] = len(partial)
    rep["missing_or_partial_hours_local"] = [str(x.tz_convert(TZ)) for x in partial.index[:20]]
    mw = (g["mwh"] / (g["minutes"] / 60)).where(g["minutes"] >= 60 - 1e-9)   # mean MW; partial hours -> NaN
    out = pd.DataFrame({"se4_MW": mw.to_numpy(), "minutes_of_data": g["minutes"].fillna(0).to_numpy(),
                        "utc_hour": full}, index=full.tz_convert(TZ))
    out.index.name = "local_hour"
    m = out.index.month
    out["se4_norm"] = out["se4_MW"] / out.groupby(m)["se4_MW"].transform("max")
    rep["months_with_hours"] = dict(pd.Series(m).value_counts().sort_index())
    rep["first_local"], rep["last_local"] = str(out.index[0]), str(out.index[-1])
    rep["first_utc"], rep["last_utc"] = str(full[0]), str(full[-1])
    rep["dst_days"] = [str(x.date()) for x in out.index[1:][np.diff(np.asarray([o.utcoffset().total_seconds()
                                                                              for o in out.index])) != 0]]
    return out, rep


def pool_key(se4, pool_time):
    """Naive time stamps on the clock the pool series uses."""
    if pool_time == "local_wallclock":
        return se4.index.tz_localize(None)
    if pool_time == "cet":
        return (se4["utc_hour"] + pd.Timedelta(hours=1)).dt.tz_localize(None).to_numpy()
    if pool_time == "utc":
        return se4["utc_hour"].dt.tz_localize(None).to_numpy()
    raise ValueError(f"POOL_TIME must be local_wallclock, cet or utc, not {pool_time!r}")


def se4_on_pool_clock(se4, pool_time):
    """SE4 on the pool's clock: one row per naive hour (the repeated autumn
    hour averaged). Columns se4_MW, se4_norm, month."""
    k = pd.DatetimeIndex(pool_key(se4, pool_time))
    s = se4[["se4_MW"]].set_index(k).groupby(level=0).mean()
    s["month"] = s.index.month
    s["se4_norm"] = s["se4_MW"] / s.groupby("month")["se4_MW"].transform("max")
    return s


def top_hours(se4c, n, days="all"):
    """{month: DatetimeIndex of the month's n highest SE4 hours} (pool clock)."""
    s = se4c.dropna(subset=["se4_MW"])
    if days == "weekday":
        s = s[s.index.dayofweek < 5]
    elif days == "weekend":
        s = s[s.index.dayofweek >= 5]
    out = {}
    for m, g in s.groupby("month"):
        out[m] = g["se4_MW"].sort_values(ascending=False, kind="mergesort").index[:n]
    return out


def joined(pool, se4c):
    """Pool hourly series (naive index, kW) joined with SE4 on the hour."""
    pool = pool.copy()
    pool.index = pd.DatetimeIndex(pool.index).rename(None)
    se4c = se4c.copy()
    se4c.index = se4c.index.rename(None)
    j = pd.DataFrame({"pool_kW": pool}).join(se4c.drop(columns="month"), how="outer")
    j["month"] = j.index.month
    j["hour"] = j.index.hour
    return j


# ------------------------------------------------------------------ figures
def fig_profiles(path, j, pct_band=(10, 90)):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(3, 4, figsize=(13, 8.5), sharex=True)
    ymax = np.nanpercentile(j["pool_kW"], 99) * 1.05 if j["pool_kW"].notna().any() else 1
    for m, ax in zip(range(1, 13), axes.flat):
        g = j[j["month"] == m]
        s = g.groupby("hour")["se4_norm"].mean().reindex(range(24))
        p = g.groupby("hour")["pool_kW"]
        lo, med, hi = p.quantile(pct_band[0] / 100), p.median(), p.quantile(pct_band[1] / 100)
        ax2 = ax.twinx()
        ax2.fill_between(range(24), lo.reindex(range(24)), hi.reindex(range(24)), color="0.85", lw=0,
                         label=f"pool P{pct_band[0]}-P{pct_band[1]}")
        ax2.plot(range(24), med.reindex(range(24)), color="0.45", lw=1.4, ls="--", label="pool median")
        ax.plot(range(24), s, color="k", lw=1.6, label="SE4 (normalised)")
        ax.set_zorder(ax2.get_zorder() + 1)
        ax.patch.set_visible(False)
        ax.set_ylim(0, 1.05)
        ax2.set_ylim(0, ymax)
        ax.set_title(MONTHS[m - 1], fontsize=9)
        ax.set_xticks(range(0, 24, 6))
        ax.tick_params(labelsize=7)
        ax2.tick_params(labelsize=7)
        if m in (1, 5, 9):
            ax.set_ylabel("SE4 / monthly max", fontsize=8)
        if m in (4, 8, 12):
            ax2.set_ylabel("pool flexibility (kW)", fontsize=8)
        if m > 8:
            ax.set_xlabel("hour of day", fontsize=8)
        if m == 1:
            h1, l1 = ax.get_legend_handles_labels()
            h2, l2 = ax2.get_legend_handles_labels()
    fig.legend(h1 + h2, l1 + l2, loc="lower center", ncol=3, frameon=False, fontsize=9)
    fig.suptitle("Average daily profile per month: SE4 consumption (normalised, left) and the pool's flexibility "
                 "above base (right)", fontsize=10)
    fig.tight_layout(rect=(0, 0.04, 1, 0.97))
    fig.savefig(path)
    fig.savefig(path.replace(".pdf", ".png"), dpi=200)
    plt.close(fig)


def fig_heatmap(path, j, tops, n, vmax):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    grid = j.pivot_table(index="hour", columns="month", values="pool_kW", aggfunc="median") \
        .reindex(index=range(24), columns=range(1, 13))
    fig, ax = plt.subplots(figsize=(8, 6.2))
    vmax_used = vmax if vmax else float(np.nanmax(grid.values))
    im = ax.imshow(grid.values, aspect="auto", origin="lower", cmap="Greys", vmin=0, vmax=vmax_used,
                   extent=[0.5, 12.5, -0.5, 23.5])
    over = bool(vmax) and np.nanmax(grid.values) > vmax
    fig.colorbar(im, ax=ax, label="pool median flexibility (kW)", extend="max" if over else "neither")
    for m, idx in tops.items():
        cnt = pd.Series(idx.hour).value_counts()
        for h, c in cnt.items():
            ax.scatter(m, h, s=18 + 14 * c, marker="o", facecolors="white", edgecolors="k", linewidths=1.0, zorder=3)
            if c > 1:
                ax.text(m + 0.28, h, str(c), fontsize=6, va="center", zorder=4)
    ax.scatter([], [], s=40, marker="o", facecolors="white", edgecolors="k",
               label=f"month's {n} highest SE4 hours (number = days at that hour)")
    ax.set_xticks(range(1, 13))
    ax.set_xticklabels(MONTHS, fontsize=8)
    ax.set_yticks(range(0, 24, 3))
    ax.set_xlabel("month")
    ax.set_ylabel("hour of day")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.1), frameon=False, fontsize=8)
    ax.set_title("Pool median flexibility by hour and month, with the highest SE4 hours", fontsize=10)
    fig.tight_layout()
    fig.savefig(path)
    fig.savefig(path.replace(".pdf", ".png"), dpi=200)
    plt.close(fig)
    return float(np.nanmax(grid.values)) if np.isfinite(grid.values).any() else np.nan


def table(path, j, tops, n, pct=10, pv_note=True):
    """Per month: P<pct> over all hours, P<pct> in the n highest SE4 hours, ratio."""
    rows = []
    for m in range(1, 13):
        a = j.loc[j["month"] == m, "pool_kW"].dropna()
        idx = tops.get(m, pd.DatetimeIndex([]))
        t = j["pool_kW"].reindex(idx).dropna()
        pa = float(np.percentile(a, pct)) if len(a) else np.nan
        pt = float(np.percentile(t, pct)) if len(t) else np.nan
        rows.append(dict(month=MONTHS[m - 1], P_all_kW=pa, P_top_kW=pt, ratio=pt / pa if pa else np.nan,
                         top_hours_with_pool=len(t), top_hours=len(idx)))
    df = pd.DataFrame(rows)

    def f(x, d=0):
        return "--" if not np.isfinite(x) else f"{x:,.{d}f}".replace(",", r"\,")
    mark = {"Jun", "Jul", "Aug"} if pv_note else set()
    body = [f"{r.month}{'$^{a}$' if r.month in mark else ''} & {f(r.P_all_kW)} & {f(r.P_top_kW)} & "
            f"{f(r.ratio, 2)} \\\\" for r in df.itertuples()]
    tex = [r"\begin{table}[htbp]", r"\centering",
           rf"\caption{{The pool's firm level (P{pct}) per month over all hours and over the month's {n} highest "
           r"SE4 consumption hours (kW), and their ratio. SE4 (eSett open data, 2025) is used only for timing.}",
           r"\label{tab:superposition_se4}", r"\begin{tabular}{lrrr}", r"\toprule",
           rf"Month & P{pct} all hours & P{pct} top-{n} SE4 hours & Ratio \\", r"\midrule", *body,
           r"\bottomrule", r"\end{tabular}"]
    if pv_note:
        tex += [r"\par\smallskip\footnotesize $^{a}$ June--August: SE4's highest hours fall at midday, when the "
                r"solar panels lower the net load of the PV sites; the pool's flexibility in these hours is a "
                r"lower bound."]
    tex += [r"\end{table}"]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(tex) + "\n")
    return df
