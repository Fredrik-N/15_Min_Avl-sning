"""
run_all.py -- runs the whole chain, in order.

    python run_all.py                  everything
    python run_all.py --dry-run        only print what would run
    python run_all.py --from offer     start at the step whose name contains "offer"
    python run_all.py --only figures   run one step
    python run_all.py --skip unilm,ladder   leave steps out
    python run_all.py --keep-going     continue after a step fails (default: stop)

Folders: the scripts sit in their own folder (e.g. workspace/new_plan_scripts/)
and the data in DATA_DIR (default: the folder above the scripts). Every step
runs WITH DATA_DIR AS ITS WORKING FOLDER, so meter files, weather files and
the *_out folders are found and written there, while the scripts are taken
from the scripts folder (never an old copy lying in the data folder).

Edit the settings block below. The other settings of each script stay in it.
"""
import os
import subprocess
import sys
import time

# ======================================================================
# SETTINGS
# ======================================================================
SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.dirname(SCRIPTS_DIR)      # folder with the meter files etc.; e.g. r"C:\Users\...\Exjobb"

# Weather (SMHI exports, UTC). Paths relative to DATA_DIR, or absolute.
WEATHER = "smhi_helsingborg_2025.csv"        # Lufttemperatur: 15-min screening, alt_filter AND the 1 s decomposition
HUMIDITY = None                              # Relativ Luftfuktighet (1 s decomposition only), e.g. "smhi_helsingborg_rh_2025.csv"
COVARIATE = "dry_bulb"                       # "dry_bulb" | "wet_bulb" | "enthalpy" (the last two need HUMIDITY)

# 1 s sites: (meter file, site name, output folder). Leave [] if none.
# The output folder is what reducible_power.py / resolution_ladder.py are set to read.
ONE_SECOND_SITES = [
    # ("B_1s.csv", "B", "results_B"),
]

# Hourly load series of the DSO's subscription point, for the subscription step.
# None = the subscription step is skipped (no grid-consumption file is needed anywhere).
SUBSCRIPTION_SERIES = None                   # e.g. "subscription_point_hourly.csv" (columns: time; load_kw)

# ======================================================================
PY = sys.executable


def script(name):
    return os.path.join(SCRIPTS_DIR, name)


UNILM_ARGS = (["--weather", WEATHER] if WEATHER else []) \
    + (["--humidity", HUMIDITY] if HUMIDITY else []) + ["--covariate", COVARIATE]

STEPS = [
    ("lpc rerun",    [PY, script("lpc_11.py"), "--rerun-all"]),   # screening of every site, writes site_comparison.csv
]
STEPS += [(f"unilm {code}", [PY, script("unilm_fhmm.py"), meter, "--out", out, "--site", code] + UNILM_ARGS)
          for meter, code, out in ONE_SECOND_SITES]
STEPS += [
    ("sensitivity",  [PY, script("filter_sensitivity.py")]),       # 81 threshold combinations
    ("altfilter",    [PY, script("alt_filter.py")]),               # exploratory comparison
    ("reducible",    [PY, script("reducible_power.py")]),
    ("offer",        [PY, script("offerable_flex.py")]),
]
if SUBSCRIPTION_SERIES:
    STEPS += [("subscription", [PY, script("subscription_lowering.py")])]
STEPS += [
] + ([("ladder", [PY, script("resolution_ladder.py")])] if ONE_SECOND_SITES else []) + [   # needs 1 s sites
    ("baseline",     [PY, script("baseline_test.py")]),
    ("figures",      [PY, script("figures.py")]),
    ("rq1",          [PY, script("rq1_results.py")]),              # RQ1 check, numbers and tables
    ("tables",       [PY, script("thesis_tables.py")]),            # last: reads everything above
]


def arg(name):
    return sys.argv[sys.argv.index(name) + 1] if name in sys.argv else None


def environment():
    env = dict(os.environ)
    if WEATHER:
        env["EXJOBB_WEATHER"] = WEATHER
    if SUBSCRIPTION_SERIES:
        env["EXJOBB_SUBSCRIPTION_SERIES"] = SUBSCRIPTION_SERIES
    env["PYTHONIOENCODING"] = "utf-8"            # å/ä/ö in site names on the Windows console
    return env


def check_paths():
    problems = []
    if not os.path.isdir(DATA_DIR):
        problems.append(f"DATA_DIR does not exist: {DATA_DIR}")
    for label, p in (("WEATHER", WEATHER), ("HUMIDITY", HUMIDITY), ("SUBSCRIPTION_SERIES", SUBSCRIPTION_SERIES)):
        if p and not os.path.exists(os.path.join(DATA_DIR, p)):
            problems.append(f"{label} not found: {os.path.join(DATA_DIR, p)}")
    for meter, _, _ in ONE_SECOND_SITES:
        if not os.path.exists(os.path.join(DATA_DIR, meter)):
            problems.append(f"1 s meter file not found: {os.path.join(DATA_DIR, meter)}")
    if os.path.abspath(DATA_DIR) != SCRIPTS_DIR:
        old = [f for f in ("lpc_11.py", "reducible_power.py", "offerable_flex.py")
               if os.path.exists(os.path.join(DATA_DIR, f))]
        if old:
            print(f"note: old copies in the data folder are NOT used: {old}")
    return problems


def main():
    only, start, skip = arg("--only"), arg("--from"), (arg("--skip") or "").split(",")
    steps = list(STEPS)
    if only:
        steps = [s for s in steps if only in s[0]]
    if start:
        i = next((k for k, s in enumerate(steps) if start in s[0]), None)
        if i is None:
            sys.exit(f"no step contains {start!r}: {[s[0] for s in steps]}")
        steps = steps[i:]
    steps = [s for s in steps if not any(k and k in s[0] for k in skip)]
    print(f"scripts: {SCRIPTS_DIR}\ndata:    {os.path.abspath(DATA_DIR)}\nweather: {WEATHER}; humidity: {HUMIDITY}; "
          f"covariate: {COVARIATE}\nsubscription series: {SUBSCRIPTION_SERIES or 'none (step skipped)'}")
    problems = check_paths()
    if "--dry-run" in sys.argv:
        for p in problems:
            print("!! " + p)
        for name, cmd in steps:
            print(f"{name:14s} {os.path.basename(cmd[1])} {' '.join(cmd[2:])}")
        return
    if problems:
        sys.exit("\n".join("!! " + p for p in problems))
    env = environment()
    results = []
    for name, cmd in steps:
        print(f"\n{'=' * 70}\n>> {name}: {os.path.basename(cmd[1])} {' '.join(cmd[2:])}\n{'=' * 70}", flush=True)
        t0 = time.time()
        rc = subprocess.call(cmd, cwd=DATA_DIR, env=env)
        results.append((name, rc, time.time() - t0))
        if rc != 0 and "--keep-going" not in sys.argv:
            print(f"\n!! {name} failed (exit {rc}); stopping. Fix it and run  python run_all.py --from {name.split()[0]}")
            break
    print("\nsummary")
    for name, rc, sec in results:
        print(f"  {'ok    ' if rc == 0 else 'FAILED'}  {name:14s} {sec:6.0f} s")
    if any(rc != 0 for _, rc, _ in results):
        sys.exit(1)


if __name__ == "__main__":
    main()
